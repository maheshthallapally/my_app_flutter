package com.cardprime.eauth.apiservice.models.esign

import com.google.gson.annotations.SerializedName

data class ESignSaveTxnRequest(
    @SerializedName("sroCode") val sroCode: Int,
    @SerializedName("bookNo") val bookNo: Int,
    @SerializedName("documentNo") val documentNo: Int,
    @SerializedName("registedYear") val registedYear: Int,
    @SerializedName("code") val code: String,
    @SerializedName("ec_number") val ec_number: Int,
    @SerializedName("authmode") val authmode: Int,
    @SerializedName("name") val name: String,
    @SerializedName("location") val location: String,
    @SerializedName("igrsEsign") val igrsEsign: Boolean,
    @SerializedName("applicationId") val applicationId: String,
    @SerializedName("txnid") val txnid: Long,
)
