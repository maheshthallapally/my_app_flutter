package com.cardprime.eauth.activities

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.utils.QRScanEKycData
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pos.foodservicespos.apiservice.models.login.EMPL_Data
import com.pos.foodservicespos.apiservice.models.login.EncryptedPasswordResponse
import com.pos.foodservicespos.apiservice.models.login.LoginRequest
import com.pos.foodservicespos.apiservice.models.login.LoginResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.EmployeeData
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarData
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarEmployeeListResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarEmployeeListResponseDecrypt
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarListResponse
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.utils.Utilities.calculateDistanceInMeters
import com.pos.foodservicespos.widgets.EditTextCustom
import com.pos.foodservicespos.widgets.TextViewCustom
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginActivity : ParentActivity() {


        private lateinit var spinnerOffice: Spinner
        private lateinit var spinnerEmployee: Spinner
        private lateinit var txtPassword: EditTextCustom
        private lateinit var lblErrorEmailMsg: TextViewCustom
        private lateinit var lblErrorPasswordMsg: TextViewCustom
        private lateinit var lblErrorOffice: TextViewCustom
        private lateinit var lblErrorEmployee: TextViewCustom
        private lateinit var labelOffice: TextViewCustom
        private lateinit var labelEmployee: TextViewCustom
        private lateinit var lblPassword: TextViewCustom
        private lateinit var lblSignIn: TextViewCustom
        private lateinit var ll_view_password: LinearLayout
        private lateinit var img_view_password: ImageView
        private lateinit var cbRememberMe: CheckBox
        private lateinit var applicationPreferences: ApplicationPreferences
        private lateinit var ll_logo: LinearLayout
        private lateinit var sc_login: ScrollView

        private lateinit var sharedPreferences: SharedPreferences
        private lateinit var activity: Activity

        private lateinit var employeeListData: List<EmployeeData>
        private var selectedEmployee: EmployeeData? = null
        private var init_selectedEmployee = 0

        private lateinit var subRegistrarData: List<SubRegistrarData>
        private var selectedSRO: SubRegistrarData? = null
        private var init_selectedSRO = 0

        lateinit var dialog: AlertDialog

        companion object {
            const val LOCATION_PERMISSION_REQUEST_CODE = 1001
        }

        private lateinit var fusedLocationClient: FusedLocationProviderClient

        private fun getLastKnownLocation() {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // Permission not granted
                return
            }

            try {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location: Location? ->
                        location?.let {
                            val latitude = it.latitude
                            val longitude = it.longitude
                            Utilities.logI("Distance Lat: $latitude, Lng: $longitude")

                            /*val distanceMeters =
                                ApplicationPreferences.getLatitude(thisActivity)?.let { it1 ->
                                    ApplicationPreferences.getLongitude(thisActivity)?.let { it2 ->
                                        *//*Utilities.logI("Distance: latitude $it1")
                                Utilities.logI("Distance: longitude $it2")
                                calculateDistanceInMeters(
                                    lat1 = latitude, lon1 = longitude,   // My Location
                                    lat2 = it1, lon2 = it2
                                    *//**//*lat2 = 17.4131632, lon2 = 78.3409748    // My Office*//**//*
                                )*//*
                                    }
                                }*/

                            /*Utilities.logI("Distance: %.2f meters".format(distanceMeters))*/

                        } ?: run {
                            Utilities.logI("Location is null")
                        }
                    }
                    .addOnFailureListener {
                        Utilities.logI("Failed to get location: ${it.message}")
                    }
            }catch (e: Exception){}
        }

        // Handle permission result
        override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
        ) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)

            if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getLastKnownLocation()
                } else {
                    //Utilities.showAlertAndOpenAppSettingsforLocation(thisActivity, "Location permission denied. Please enable it in settings.", packageName)
                    Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
                }
            }
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            applicationPreferences = ApplicationPreferences

            // Retrieve saved theme and apply
            applyTheme(applicationPreferences.getThemeMode(this))

            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_login)
            activity = this

            /*Log.i("LoginActivity", "encodeToBase64 : "+Utilities.encodeToBase64("858633410612"))*/

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )

            /*val distanceMeters = calculateDistanceInMeters(
                lat1 = 12.9716, lon1 = 77.5946,   // Bangalore
                lat2 = 28.7041, lon2 = 77.1025    // Delhi
            )
            Utilities.logI("Distance: %.2f meters".format(distanceMeters))

            ApplicationPreferences.setLatitude(thisActivity, "28.7041")
            ApplicationPreferences.setLongitude(thisActivity, "77.1025")*/

            fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
            getLastKnownLocation()

            // Initialize views
            spinnerOffice = findViewById(R.id.spinnerOffice)
            spinnerEmployee = findViewById(R.id.spinnerEmployee)
            txtPassword = findViewById(R.id.txtPassword)
            lblErrorEmailMsg = findViewById(R.id.lblErrorEmailMsg)
            lblErrorPasswordMsg = findViewById(R.id.lblErrorPasswordMsg)
            lblErrorOffice = findViewById(R.id.lblErrorOffice)
            lblErrorEmployee = findViewById(R.id.lblErrorEmployee)
            lblSignIn = findViewById(R.id.lblSignIn)
            ll_view_password = findViewById(R.id.ll_view_password)
            img_view_password = findViewById(R.id.img_view_password)
            cbRememberMe = findViewById(R.id.cb_remember_me)
            labelOffice = findViewById(R.id.labelOffice)
            labelEmployee = findViewById(R.id.labelEmployee)
            lblPassword = findViewById(R.id.lblPassword)
            ll_logo = findViewById(R.id.ll_logo)
            sc_login = findViewById(R.id.sc_login)

            Utilities.setLabelWithAsterisk(thisActivity,labelOffice,getString(R.string.office_location))
            Utilities.setLabelWithAsterisk(thisActivity,labelEmployee,getString(R.string.employee_name))
            Utilities.setLabelWithAsterisk(thisActivity,lblPassword,getString(R.string.password))

            try {
                val packageInfo = packageManager.getPackageInfo(packageName, 0)
                val versionName = packageInfo.versionName
                (findViewById<TextView>(R.id.lblVersion)).text = "v ${versionName}"
            }catch (e: Exception){
                e.printStackTrace()
            }


            cbRememberMe.isChecked = true;

            // Initialize SharedPreferences
            sharedPreferences = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)

            // Load saved credentials (if any)
            loadSavedCredentials()

            // Handle Sign In Button Click
            lblSignIn.setOnClickListener {
                //Utilities.logI("init_selectedEmployee2 "+Utilities.decryptDatas("GeF7hZwRV1cWbGqf6gHDEmijO2vlOlLSPqI1xhJcy+DS8AzDvrgiWpYm0BMkdWpC","!Gr$@SeCApP&"))
                validateAndLogin()
            }

            ll_view_password.setOnClickListener{
                var tag = img_view_password.getTag().toString();
                if(tag.equals("show")){
                    txtPassword.inputType = InputType.TYPE_CLASS_TEXT
                    txtPassword.transformationMethod = null
                    img_view_password.tag = "hide"
                    img_view_password.setBackgroundResource(R.drawable.eye_hide)
                }else{
                    txtPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    txtPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                    img_view_password.tag = "show"
                    img_view_password.setBackgroundResource(R.drawable.eye_show)
                }
            }

            /*ll_logo.visibility = View.VISIBLE
            sc_login.visibility = View.GONE*/


            getSROOfficesList()


            spinnerOffice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {

                    Utilities.logI("init_selectedSRO "+init_selectedSRO)

                    if(init_selectedSRO > 0) {
                        selectedSRO = subRegistrarData[position]

                        init_selectedEmployee = 0
                        loadSpinnerEmpty(spinnerEmployee, thisActivity)

                        if (selectedSRO?.srCd == 0) {
                            lblErrorOffice.visibility = View.VISIBLE
                            lblErrorOffice.text = getString(R.string.select_office)
                        } else {
                            lblErrorOffice.visibility = View.GONE
                            //selectedSRO?.srCd?.let { getSROEmployeeList(it.toString()) }
                            selectedSRO?.srCd?.let { getEncryptedSRONo(it.toString()) }
                        }
                    }

                    init_selectedSRO = init_selectedSRO + 1
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // Optional
                }
            }


            spinnerEmployee.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {

                    Utilities.logI("init_selectedEmployee "+init_selectedEmployee)

                    try {
                        if (init_selectedEmployee > 0) {
                            selectedEmployee = employeeListData[position]

                            if (selectedEmployee?.srCode == 0) {
                                lblErrorEmployee.visibility = View.VISIBLE
                                lblErrorEmployee.text = getString(R.string.select_employee)
                            } else {
                                lblErrorEmployee.visibility = View.GONE
                            }
                        }
                        init_selectedEmployee = init_selectedEmployee + 1
                    }catch (e:Exception){}
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // Optional
                }
            }


//            loadSpinnerEmpty(spinnerOffice, thisActivity)
//            loadSpinnerEmpty(spinnerEmployee, thisActivity)
//            init_selectedSRO = 0
//            init_selectedEmployee = 0

            txtPassword.setOnEditorActionListener { v12: TextView?, actionId: Int, event: KeyEvent? ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    lblSignIn.performClick()
                }
                false
            }


        }

        private fun validateAndLogin() {
            val email = "jijij"
            val password = txtPassword.text.toString().trim()

            var isValid = true

            // Validate Office
            if(selectedSRO == null || selectedSRO?.srCd == 0){
                lblErrorOffice.text = getString(R.string.select_office)
                lblErrorOffice.visibility = View.VISIBLE
                isValid = false
            }else{
                lblErrorOffice.visibility = View.GONE

                // Validate Employee
                if(selectedEmployee == null || selectedEmployee?.srCode == 0){
                    lblErrorEmployee.text = getString(R.string.select_employee)
                    lblErrorEmployee.visibility = View.VISIBLE
                    isValid = false
                }else{
                    lblErrorEmployee.visibility = View.GONE

                    // Validate Password
                    if (password.isEmpty()) {
                        lblErrorPasswordMsg.text = getString(R.string.error_password_required)
                        lblErrorPasswordMsg.visibility = View.VISIBLE
                        isValid = false
                    }else {
                        lblErrorPasswordMsg.visibility = View.GONE
                    }
                }
            }



            // If both are valid, proceed with sign-in logic
            if (isValid) {
                performLogin(email, password)
            }
        }

        private fun performLogin(email: String, password: String) {

            // Get the root layout (full screen)
            val rootLayout = findViewById<ViewGroup>(android.R.id.content)

            // Create a FrameLayout to overlay the screen
            val overlayLayout = FrameLayout(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
            }

            // Create ProgressBar dynamically
            val progressBar = ProgressBar(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER  // Centers it in the overlay
                )
            }

            // Add ProgressBar to the overlay layout
            overlayLayout.addView(progressBar)

            // Add overlay (with ProgressBar) to the root layout
            rootLayout.addView(overlayLayout)

            // Show the ProgressBar
            progressBar.visibility = View.VISIBLE


            if (cbRememberMe.isChecked) {
                Utilities.saveCredentials(email, password, applicationContext)
            } else {
                Utilities.clearCredentials(applicationContext)
            }

//            startActivity(Intent(applicationContext, ESignActivity::class.java))
//            finish()
//            return;


            // Handle login API call or authentication logic
            val apiServicePwd = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

            apiServicePwd.getEncryptedPassword(password).enqueue(object : Callback<EncryptedPasswordResponse> {
                override fun onResponse(
                    call: Call<EncryptedPasswordResponse>,
                    response: Response<EncryptedPasswordResponse>
                ) {

                    if (response.isSuccessful) {

                        var enc_password = response.body()?.data

                        if (enc_password != null) {
                            callLoginAPI(progressBar, rootLayout, overlayLayout, email, enc_password)
                        }else{
                            progressBar.visibility = View.GONE
                            rootLayout.removeView(overlayLayout)
                            Utilities.showAlert(thisActivity, getString(R.string.login_error)+"  dskjf")
                        }

                    } else {
                        val errorJson = response.errorBody()?.string() ?: "{}"
                        progressBar.visibility = View.GONE
                        rootLayout.removeView(overlayLayout)
                        Utilities.showAlert(thisActivity, getString(R.string.login_error))

                        //remove mahesh
                        //callLoginAPI(progressBar, rootLayout, overlayLayout, email, "U2FsdGVkX1+2uIpyI4F+VyKD0L7BaHWtmNRvmaye0VQ=")
                        //callLoginAPI(progressBar, rootLayout, overlayLayout, email, "1")
                    }
                }

                override fun onFailure(call: Call<EncryptedPasswordResponse>, t: Throwable) {

                    // Hide ProgressBar
                    progressBar.visibility = View.GONE
                    rootLayout.removeView(overlayLayout)
                    Utilities.showAlert(thisActivity, getString(R.string.login_error))
                    // Handle failure
                    Utilities.logI("getEncryptedPassword failed: ${t.message}")

                }
            })

        }

    fun callLoginAPI(progressBar: ProgressBar, rootLayout: ViewGroup, overlayLayout: FrameLayout, email: String, password: String) {
        val role = "SRO"
        val SRO_CODE = selectedSRO?.srCd
        val SR_NAME = selectedSRO?.srName
        val EMPL_ID = selectedEmployee?.emplId
        val EMPL_NAME = selectedEmployee?.emplName
        val VILLAGE_NAME = ""
        val VILLAGE_CODE = ""
        val PASSWRD =  password //"U2FsdGVkX1/4HM1DwfQ0wetnFeBdx3rAeibTpap6STQ="

        val EMPL_Data =  EMPL_Data (selectedEmployee?.emplId, selectedEmployee?.emplName, null)

        // Handle login API call or authentication logic
        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))
        val loginRequest = EMPL_ID?.let {
            LoginRequest(role, SRO_CODE, SR_NAME,
                it, EMPL_NAME, VILLAGE_NAME, VILLAGE_CODE, PASSWRD, EMPL_Data)
        }

        // Make the login call
        if (loginRequest != null) {
            apiService.login(loginRequest).enqueue(object : Callback<LoginResponse> {
                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {

                    // Hide ProgressBar
                    progressBar.visibility = View.GONE
                    rootLayout.removeView(overlayLayout)


                    try{ val request = call.request()
                        Utilities.logI("lo3 Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}

                    try{
                        Utilities.logI("response : ${response.isSuccessful}     ${response.body()}")
                    }catch (e:Exception){}

                    if (response.isSuccessful) {
                        // Successful login
                        val loginResponse = response.body()
                        val token = loginResponse?.data?.accessToken?.token
                        Utilities.logI("Login successful, ,") // token: $token")
                        ApplicationPreferences.setToken(applicationContext, "Bearer "+token)
                        ApplicationPreferences.setLoginTime(thisActivity, System.currentTimeMillis())

                        ApplicationPreferences.setSROCode(thisActivity, selectedSRO?.srCd.toString())

                        getValue(selectedSRO?.LATITUDE.toString())
                        getValue2(selectedSRO?.LONGITUDE.toString())

                        /*ApplicationPreferences.setLatitude(thisActivity, selectedSRO?.LATITUDE.toString())
                        ApplicationPreferences.setLongitude(thisActivity, selectedSRO?.LONGITUDE.toString())*/

                        ApplicationPreferences.setEmployeeName(thisActivity, selectedEmployee?.emplName)

                        if (loginResponse != null) {
                            ApplicationPreferences.saveLoginResponse(applicationContext, loginResponse)
                        }

                        val loginResponse2 = ApplicationPreferences.getLoginResponse(applicationContext)
                        //Utilities.logI("Login getLoginResponse, , getLoginResponse: ${loginResponse2?.data}")

                        if (cbRememberMe.isChecked) {
                            Utilities.saveCredentials(email, password, applicationContext)
                        } else {
                            Utilities.clearCredentials(applicationContext)
                        }

                        startActivity(Intent(applicationContext, SelectServiceActivity::class.java))
                        finish()

                    } else {

                        val errorJson = response.errorBody()?.string() ?: "{}"
                        var errorMessage = parseErrorJson(errorJson)

                        if(errorMessage.isEmpty()){
                            errorMessage = getString(R.string.get_sro_error)
                        }
                        Utilities.showAlert(thisActivity, errorMessage)


                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {

                    // Hide ProgressBar
                    progressBar.visibility = View.GONE
                    rootLayout.removeView(overlayLayout)

                    // Handle failure
                    Utilities.logI("Login failed:callLoginAPI1 ${t.message}")
                    /*Toast.makeText(applicationContext, "Login failed: ${t.message}", Toast.LENGTH_SHORT).show()*/
                    lblErrorEmailMsg.text = "Login failed: ${t.message}"
                    lblErrorEmailMsg.visibility = View.VISIBLE

                    Utilities.showAlert(thisActivity, "Login failed: ${t.message}")

                }
            })
        }
    }

    private fun getSROOfficesList(){
        // Get the root layout (full screen)
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        // Create a FrameLayout to overlay the screen
        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        // Create ProgressBar dynamically
        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // Add ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // Add overlay (with ProgressBar) to the root layout
        rootLayout.addView(overlayLayout)

        // Show the ProgressBar
        progressBar.visibility = View.VISIBLE

        // Handle login API call or authentication logic
        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))
        apiService.getSROOfficesList().enqueue(object : Callback<SubRegistrarListResponse> {
            override fun onResponse(
                call: Call<SubRegistrarListResponse>,
                response: Response<SubRegistrarListResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("lo1 Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}

                ll_logo.visibility = View.GONE
                sc_login.visibility = View.VISIBLE

                if (response.isSuccessful) {
                    response.body()?.data?.let {
                        applicationPreferences.saveSubRegistrarList(thisActivity,
                            it
                        )
                    }

                    response.body()?.data?.let { loadSROListToSpinner(it, spinnerOffice, thisActivity) }

                    //response.body()?.data?.let { getSROListDecrypt(response.body()?.data.toString(), spinnerOffice, thisActivity) }

                } else {
                    /*val errorJson = response.errorBody()?.string() ?: "{}"
                    val errorMessage = parseErrorJson(errorJson)*/

                    try{
                        val subRegistrarList: List<SubRegistrarData> = applicationPreferences.getSubRegistrarList(
                            thisActivity)
                        Utilities.logI("subRegistrarList ${subRegistrarList.size}")
                        if(subRegistrarList.size > 0) {
                            loadSROListToSpinner(subRegistrarList, spinnerOffice, thisActivity)
                        }else{
                            loadSpinnerEmpty(spinnerOffice, thisActivity)
                        }
                    }catch (e: Exception){
                        loadSpinnerEmpty(spinnerOffice, thisActivity)
                    }

                }
            }

            override fun onFailure(call: Call<SubRegistrarListResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Handle failure
                Utilities.logI("Login failed:getSROOfficesList ${t.message}")

                try{
                    val subRegistrarList: List<SubRegistrarData> = applicationPreferences.getSubRegistrarList(
                        thisActivity)
                    Utilities.logI("subRegistrarList ${subRegistrarList.size}")
                    if(subRegistrarList.size > 0) {
                        loadSROListToSpinner(subRegistrarList, spinnerOffice, thisActivity)
                    }else{
                        loadSpinnerEmpty(spinnerOffice, thisActivity)
                    }
                }catch (e: Exception){
                    loadSpinnerEmpty(spinnerOffice, thisActivity)
                }

                ll_logo.visibility = View.GONE
                sc_login.visibility = View.VISIBLE
            }
        })
    }


    private fun getEncryptedSRONo(srCode: String) {

        // Get the root layout (full screen)
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        // Create a FrameLayout to overlay the screen
        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        // Create ProgressBar dynamically
        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // Add ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // Add overlay (with ProgressBar) to the root layout
        rootLayout.addView(overlayLayout)

        // Show the ProgressBar
        progressBar.visibility = View.VISIBLE


        // Handle login API call or authentication logic
        val apiServicePwd = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro_2))

        apiServicePwd.getEncryptedValue(srCode).enqueue(object : Callback<EncryptedPasswordResponse> {
            override fun onResponse(
                call: Call<EncryptedPasswordResponse>,
                response: Response<EncryptedPasswordResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("getEnSNo Request ${request.method} ${request.url.encodedPath.split("ryption/")[0]} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                //try{Utilities.logI("getEnSNo Response ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}
                try{Utilities.logI("getEnSNo Response ${response.isSuccessful} : response code ${response.isSuccessful}")}catch (e:Exception){}

                if (response.isSuccessful) {

                    var sroCodeEncrypted = response.body()?.data

                    if (sroCodeEncrypted != null) {

                        if(sroCodeEncrypted.length > 0){
                            try{Utilities.logI("getEnSNo ${response.isSuccessful} : ${sroCodeEncrypted} ")}catch (e:Exception){}
                            getSROEmployeeList(sroCodeEncrypted)
                        }else{
                            Utilities.showAlert(thisActivity, "Failed to get the Employees list. Please try again.")
                            loadSpinnerEmpty(spinnerEmployee, thisActivity)
                        }

                    }else{
                        progressBar.visibility = View.GONE
                        rootLayout.removeView(overlayLayout)
                        Utilities.showAlert(thisActivity, "Failed to get the Employees list.\nPlease try again")
                        loadSpinnerEmpty(spinnerEmployee, thisActivity)
                    }

                } else {
                    progressBar.visibility = View.GONE
                    rootLayout.removeView(overlayLayout)
                    Utilities.showAlert(thisActivity, "Failed to get the Employees list.\nPlease try again.")
                    loadSpinnerEmpty(spinnerEmployee, thisActivity)
                }
            }

            override fun onFailure(call: Call<EncryptedPasswordResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)
                Utilities.showAlert(thisActivity, "Failed to get the Employees list. Please try again..")
                loadSpinnerEmpty(spinnerEmployee, thisActivity)
                // Handle failure
                Utilities.logI("getEncryptedSRONo failed: ${t.message}")

            }
        })

    }


    private fun getSROEmployeeList(srCode: String){
        // Get the root layout (full screen)
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        // Create a FrameLayout to overlay the screen
        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        // Create ProgressBar dynamically
        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // Add ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // Add overlay (with ProgressBar) to the root layout
        rootLayout.addView(overlayLayout)

        // Show the ProgressBar
        progressBar.visibility = View.VISIBLE

        // Handle login API call or authentication logic
        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro_2))
        val srCode = srCode  // or any dynamic value
        apiService.getSROEmployeesList(srCode).enqueue(object : Callback<SubRegistrarEmployeeListResponse> {
            override fun onResponse(
                call: Call<SubRegistrarEmployeeListResponse>,
                response: Response<SubRegistrarEmployeeListResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("lo2 Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    init_selectedEmployee = 0
                    //response.body()?.data?.let { loadEmployeeListToSpinner(it, spinnerEmployee, thisActivity) }
                    response.body()?.data?.let { getEmployeeDetailsDecrypt(response.body()?.data.toString(), spinnerEmployee, thisActivity) }
                } else {
                    val errorJson = response.errorBody()?.string() ?: "{}"
                    val errorMessage = parseErrorJson(errorJson)
                    Utilities.showAlert(thisActivity, "Failed to get the Employees list. Please try again")
                    loadSpinnerEmpty(spinnerEmployee, thisActivity)
                }
            }

            override fun onFailure(call: Call<SubRegistrarEmployeeListResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Handle failure
                Utilities.logI("Login failed:getSROOfficesList2 ${t.message}")
                Utilities.showAlert(thisActivity, "Failed to get the Employees list.\nPlease try again")
                loadSpinnerEmpty(spinnerEmployee, thisActivity)
            }
        })
    }


    private fun getEmployeeDetailsDecrypt(employeeDataEncrypt: String, spinner: Spinner, context: Context) {

        // Get the root layout (full screen)
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        // Create a FrameLayout to overlay the screen
        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        // Create ProgressBar dynamically
        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // Add ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // Add overlay (with ProgressBar) to the root layout
        rootLayout.addView(overlayLayout)

        // Show the ProgressBar
        progressBar.visibility = View.VISIBLE


        // Handle login API call or authentication logic
        val apiServicePwd = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        apiServicePwd.getEmployeeListDecrypt(employeeDataEncrypt).enqueue(object : Callback<SubRegistrarEmployeeListResponseDecrypt> {
            override fun onResponse(
                call: Call<SubRegistrarEmployeeListResponseDecrypt>,
                response: Response<SubRegistrarEmployeeListResponseDecrypt>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("getEmployeeDetails Request ${request.method} ${request.url.encodedPath.split("ue/")[0]} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                //try{Utilities.logI("getEmployeeDetails Response ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}
                try{Utilities.logI("getEmployeeDetails Response ${response.isSuccessful} : response code ${response.isSuccessful}")}catch (e:Exception){}

                if (response.isSuccessful) {

                    val gson = Gson()
                    val employeeList: List<EmployeeData> =
                        gson.fromJson(response.body()?.data, object : TypeToken<List<EmployeeData>>() {}.type)
                    try{Utilities.logI("getEmployeeDetails Response  employeeList length ${employeeList.size}")}catch (e:Exception){}

                    loadEmployeeListToSpinner(employeeList, spinnerEmployee, thisActivity)

                    /*use this below code when the data is an array with employee list*/
                    //response.body()?.data?.let { loadEmployeeListToSpinner(it, spinnerEmployee, thisActivity) }
                } else {
                    progressBar.visibility = View.GONE
                    rootLayout.removeView(overlayLayout)
                    Utilities.showAlert(thisActivity, "Failed to get the Employees list. Please try again.")
                }
            }

            override fun onFailure(call: Call<SubRegistrarEmployeeListResponseDecrypt>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)
                Utilities.showAlert(thisActivity, "Failed to get the Employees list.\nPlease try again.")
                // Handle failure
                Utilities.logI("getEmployeeDetailsDecrypt  failed: ${t.message}")

            }
        })

    }


    fun loadSpinnerEmpty(spinner: Spinner, context: Context){
        val modifiedList = mutableListOf(
            EmployeeData(
                srCode = 0,
                emplId = 0L,
                cfmsId = 0L,
                aadhar = "",
                mobileNo = null,
                emplName = "--SELECT--", // Display label
                designation = "",
                proceedingNo = null,
                proceedingDate = null,
                fromDate = null,
                toDate = null,
                empStatus = null,
                lastLogin = "",
                password = "",
                villCode = null,
                verifyStatus = "",
                pastDesignation = null
            )
        )

        // Extract employee names
        val employeeNames = modifiedList.map { it.emplName }

        // Create ArrayAdapter
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, employeeNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Set adapter to spinner
        spinner.adapter = adapter
    }

    // Sample function to load data into Spinner
    fun loadEmployeeListToSpinner(employeeList: List<EmployeeData>, spinner: Spinner, context: Context){

        val sortedList = employeeList.sortedBy { it.emplName }

        val modifiedList = mutableListOf(
            EmployeeData(
                srCode = 0,
                emplId = 0L,
                cfmsId = 0L,
                aadhar = "",
                mobileNo = null,
                emplName = "--SELECT--", // Display label
                designation = "",
                proceedingNo = null,
                proceedingDate = null,
                fromDate = null,
                toDate = null,
                empStatus = null,
                lastLogin = "",
                password = "",
                villCode = null,
                verifyStatus = "",
                pastDesignation = null
            )
        )

        // Add the actual employee data
        modifiedList.addAll(sortedList)


        employeeListData = modifiedList
        // Extract employee names
        val employeeNames = modifiedList.map { it.emplName }

        // Create ArrayAdapter
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, employeeNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Set adapter to spinner
        spinner.adapter = adapter
    }


    fun loadSROListToSpinner(sroList: List<SubRegistrarData>, spinner: Spinner, context: Context){

        val sortedList = sroList.sortedBy { it.srName }

        val modifiedList = mutableListOf(
            SubRegistrarData(
                srCd = 0,
                srName = "--SELECT--",
                srEmail = "",
                drCd = "",
                digCd = "",
                ipAddress = "",
                ipFrom = "0",
                ipTo = "0",
                subindexCreate = "",
                stateCd = "",
                adrCd = 0,
                stampVerify = "",
                phoneNo = 0,
                LONGITUDE = "0",
                LATITUDE = "0"
            )
        )

        // Add the actual employee data
        modifiedList.addAll(sortedList)

        subRegistrarData = modifiedList
        // Extract employee names
        val employeeNames = modifiedList.map { it.srName }

        // Create ArrayAdapter
        val adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, employeeNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Set adapter to spinner
        spinner.adapter = adapter



        spinnerOffice.setOnTouchListener { _, _ ->
            showSearchableSpinnerDialog(this, spinnerOffice, subRegistrarData)
            true // consume touch
        }

    }




    private fun loadSavedCredentials() {
        val savedEmail = sharedPreferences.getString("EMAIL", "")
        val savedPassword = sharedPreferences.getString("PASSWORD", "")
        val isRemembered = sharedPreferences.getBoolean("REMEMBER_ME", false)

        if (isRemembered) {
            txtPassword.setText(savedPassword)
            cbRememberMe.isChecked = true
        }else{
            txtPassword.setText("")
            cbRememberMe.isChecked = false
        }
    }

    private fun applyTheme(mode: String?) {
        when (mode) {
            "cool" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                setTheme(R.style.AppCoolTheme)
            }
            "dark" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                setTheme(R.style.AppDarkTheme)
            }
            "system" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            else -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                setTheme(R.style.AppCoolTheme) // Default to cool theme
            }
        }
    }

    fun parseErrorJson(jsonString: String): String {
        try {
            // Create a JSONObject from the JSON string
            val jsonObject = JSONObject(jsonString)

            // Manually extract the "error" field
            if(jsonObject.has("error")) {
                return jsonObject.getString("error") // Returns "Invalid Credentials"
            }else if(jsonObject.has("message")) {
                // Manually parse the 'message' array
                val messageArray = jsonObject.getString("message")
                return  messageArray
            }else{
                return "Login error"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return "Error parsing JSON"
        }
    }


    fun showSearchableSpinnerDialog(
        context: Context,
        spinner: Spinner,
        dataList: List<SubRegistrarData>
    ) {

        try {
            if ( dialog != null && dialog.isShowing == true)
                return;
        }catch (e: Exception){}


        Utilities.logI("showSearchableSpinnerDialogshowSearchableSpinnerDialog")

        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_search_spinner, null)
        dialog = AlertDialog.Builder(context).setView(dialogView).create()

        val editTextSearch = dialogView.findViewById<EditText>(R.id.editTextSearch)
        val listViewItems = dialogView.findViewById<ListView>(R.id.listViewItems)

        val originalNames = dataList.map { it.srName }
        val filteredList = originalNames.toMutableList()

        val adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, filteredList)
        listViewItems.adapter = adapter

        // Filter logic
        editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString()
                val matchedNames = dataList.filter { it.srName.contains(query, ignoreCase = true) }.map { it.srName }
                filteredList.clear()
                filteredList.addAll(matchedNames)
                adapter.notifyDataSetChanged()
            }
        })

        // Handle item click
        listViewItems.setOnItemClickListener { _, _, position, _ ->
            val selectedName = filteredList[position]
            val indexInOriginalList = dataList.indexOfFirst { it.srName == selectedName }

            if (indexInOriginalList != -1) {
                spinner.setSelection(indexInOriginalList)
            }

            dialog.dismiss() // ✅ Dismiss the dialog after selection
        }

        dialog.show()
    }


    fun showSearchableSpinnerDialog2(
        context: Context,
        spinner: Spinner,
        employeeList: List<SubRegistrarData>
    ) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_search_spinner, null)
        val dialog = AlertDialog.Builder(context).setView(dialogView).create()

        val editTextSearch = dialogView.findViewById<EditText>(R.id.editTextSearch)
        val listViewItems = dialogView.findViewById<ListView>(R.id.listViewItems)

        val adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, employeeList.map { it.srName ?: "" }.toMutableList())
        listViewItems.adapter = adapter

        editTextSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val filtered = employeeList
                    .filter { it.srName?.contains(s.toString(), ignoreCase = true) == true }
                    .map { it.srName ?: "" }
                adapter.clear()
                adapter.addAll(filtered)
            }
        })

        listViewItems.setOnItemClickListener { _, _, position, _ ->
            val selectedName = adapter.getItem(position)
            val positionInList = employeeList.indexOfFirst { it.srName == selectedName }

            if (positionInList >= 0) {
                spinner.setSelection(positionInList)
            }

            dialog.dismiss()
        }

        dialog.show()
    }


    private fun getValue(value: String) {

        val apiServicePwd = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))
        apiServicePwd.getDecryptedAadharNo(value).enqueue(object : Callback<EncryptedPasswordResponse> {
            override fun onResponse(
                call: Call<EncryptedPasswordResponse>,
                response: Response<EncryptedPasswordResponse>
            ) {

                /*try{ val request = call.request()
                    Utilities.logI("getValue Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}*/
                try{Utilities.logI("getValue1 Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    var value = response.body()?.data
                    if (value != null) {

                        if(value.length > 0){
                            ApplicationPreferences.setLatitude(thisActivity, value)
                        }
                    }
                }
            }
            override fun onFailure(call: Call<EncryptedPasswordResponse>, t: Throwable) {
                Utilities.logI("getValue failed: ${t.message}")
            }
        })

    }

    private fun getValue2(value: String) {

        val apiServicePwd = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))
        apiServicePwd.getDecryptedAadharNo(value).enqueue(object : Callback<EncryptedPasswordResponse> {
            override fun onResponse(
                call: Call<EncryptedPasswordResponse>,
                response: Response<EncryptedPasswordResponse>
            ) {

                /*try{ val request = call.request()
                    Utilities.logI("getValue2 Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}*/
                try{Utilities.logI("getValue2 Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    var value = response.body()?.data
                    if (value != null) {

                        if(value.length > 0){
                            ApplicationPreferences.setLongitude(thisActivity, value)
                        }
                    }
                }
            }
            override fun onFailure(call: Call<EncryptedPasswordResponse>, t: Throwable) {
                Utilities.logI("getValue failed: ${t.message}")
            }
        })

    }


}
