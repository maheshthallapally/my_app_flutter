package com.cardprime.eauth.apiservice.apis

import android.content.Context
import androidx.multidex.BuildConfig
import com.cardprime.eauth.R
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    private var baseUrl: String? = null

    fun initialize(context: Context) {
        baseUrl = context.getString(R.string.base_url) // Set from strings.xml
    }

    private fun getAuthToken(context: Context): String {
        return ApplicationPreferences.getToken(context) ?: ""
    }

    private fun getAuthInterceptor(context: Context) = Interceptor { chain ->
        val token = getAuthToken(context)
        val request = chain.request().newBuilder()
            .addHeader("Authorization", token) // Attach Bearer token dynamically
            .build()
        chain.proceed(request)
    }

    fun createApiService(context: Context, url: String): ApiService {
        baseUrl = url
        if (baseUrl == null) {
            initialize(context) // Ensure baseUrl is set
        }

        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.NONE // Level.BODY Logs only in debug builds
            } else {
                HttpLoggingInterceptor.Level.NONE // No logs in release builds
            }
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(45, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .addInterceptor(getAuthInterceptor(context))
            .addInterceptor(loggingInterceptor)
            /*.addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY // Enable logging for debugging
            })*/
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl ?: throw IllegalStateException("RetrofitClient not initialized"))
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
