package com.pos.foodservicespos.widgets

import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import com.cardprime.eauth.R
import com.pos.foodservicespos.utils.Utilities

class TextViewCustom : androidx.appcompat.widget.AppCompatTextView {

    var addStrike = false

    constructor(context: Context) : super(context) {
        applyAttributes(context, null, 0, 0)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        applyAttributes(context, attrs, 0, 0)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyle: Int) : super(context, attrs, defStyle) {
        applyAttributes(context, attrs, defStyle, 0)
    }

    /*@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(context: Context, attrs: AttributeSet?, defStyle: Int, defStyleRes: Int) : super(context, attrs, defStyle, defStyleRes) {
        applyAttributes(context, attrs, defStyle, defStyleRes)
    }*/

    private fun applyAttributes(context: Context, attrs: AttributeSet?, defStyle: Int, defStyleRes: Int) {
        val typedArray: TypedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomTextView, defStyle, defStyleRes)
        for (i in 0 until typedArray.indexCount) {
            when (val attr = typedArray.getIndex(i)) {
                R.styleable.CustomTextView_typeface -> {
                    try {
                        typeface = getTypeFace(context, "fonts/${typedArray.getString(attr)}")
                    } catch (e: RuntimeException) {
                        e.printStackTrace()
                    }
                }
            }
        }
        typedArray.recycle()
    }

    private fun getTypeFace(context: Context, fileName: String): Typeface {
        return Utilities.sTypeFaces[fileName] ?: run {
            /*Utilities.logEwithoutLogStore("Font path: $fileName")*/
            val typeface = Typeface.createFromAsset(resources.assets, fileName)
            Utilities.sTypeFaces[fileName] = typeface
            typeface
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (addStrike) {
            val paint = Paint().apply {
                color = Color.RED
                strokeWidth = resources.displayMetrics.density * 1
            }
            canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, paint)
        }
    }
}
