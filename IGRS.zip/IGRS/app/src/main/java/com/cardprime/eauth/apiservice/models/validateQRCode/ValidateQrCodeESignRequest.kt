package com.cardprime.eauth.apiservice.models.validateQRCode

import com.google.gson.annotations.SerializedName

data class ValidateQrCodeESignRequest(
    @SerializedName("SR_CODE")  val srCode: Int,
    @SerializedName("BOOK_NO")  val bookNo: Int,
    @SerializedName("DOCT_NO")  val doctNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("name")     val name: String?,
    @SerializedName("applicationId")val applicationId: String,
    @SerializedName("ec_number")   val ec_number: Int,
    @SerializedName("txnid")   val txnid: String,
    @SerializedName("code")   val code: String,
)
//{"SR_CODE":615,"BOOK_NO":1,"DOCT_NO":13,"REG_YEAR":2025,"name":"Ilaiah","applicationId":"2506151749820140","ec_number":1,"txnid":36313940801304300,"code":"EX-999"}