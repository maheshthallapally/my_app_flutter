package com.cardprime.eauth.utils

import com.google.gson.annotations.SerializedName

data class QRScanDocumentHandoverData(
    @SerializedName("SR_CODE")  val srCode: Int,
    @SerializedName("BOOK_NO")  val bookNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("DOCT_NO")  val doctNo: Int,
    @SerializedName("AADHAR")   val aadhar: String,
    @SerializedName("EMPL_NAME") val EMPL_NAME: String,
)

// {"SR_CODE":818,"BOOK_NO":1,"REG_YEAR":2023,"DOCT_NO":13,"AADHAR":"256420535621","EMPL_NAME":"NALLAGANGULA RAJU"}