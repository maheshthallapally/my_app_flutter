package com.cardprime.eauth.apiservice.models.esign

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object ESignOptionsBuilder {
    fun build(txnId: String, auaCode: String, callbackUrl: String, jwtToken: String): String {

        val currentTime = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss")
        val formattedTime = currentTime.format(formatter)

        //return buildEsignXml2(formattedTime, txnId)

        return """<?xml version="1.0" encoding="UTF-8" standalone="no"?><Esign AuthMode="4" aspId="ASPRASAPUAT007152" ekycId="" ekycIdType="A" responseSigType="pkcs7" responseUrl="http://127.0.0.1:9080/igrs-esign-service/igrsESignResponse" sc="Y" ts="2025-06-16T16:15:16" txn="Test-1750070710059" ver="2.1"><Docs><InputHash docInfo="Document for eSign" hashAlgorithm="SHA256" id="1">8d82d0f609ea995ddb49bd535533cbfe27bec3b684dd3d835231abea21df0fb5</InputHash></Docs><Signature xmlns="http://www.w3.org/2000/09/xmldsig#"><SignedInfo><CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/><SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/><Reference URI=""><Transforms><Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/></Transforms><DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/><DigestValue>cRzn4DHZ6tCgGk43/76FNFKoT5I=</DigestValue></Reference></SignedInfo><SignatureValue>FjDcLOL1596EhGU/Qfh/4lST1/Iqk3l67mkGi8oBE/l9Cn2HoVrIFGdS4nKJ+ChdK1rJdMU24i/W&#13;
GunEc4s/GCN2yIX+q1GLyIMIBmlYjkQi84yS56txe911KaIL+Os+Anr2Gm6mF75JEgq+C4Hp59fW&#13;
O2o9b7HgcD7YFRkzl2aL0tiM0CuOrR062aontH96qOuTkFSJYmD4zFZMNvbTW8lnt+R0rEPXB9IQ&#13;
OyXd5ZV0KMFgXsjszSyLiI2vjCLNKX32W/k3/L8/IKFFgVqt00+Wax6LqhKHguUNVD1d73OTVwOY&#13;
QtnCocabqCkw7SOLjYPo9LMGIbCOB4Kl40/55w==</SignatureValue><KeyInfo><X509Data><X509SubjectName>CN=DS Registration and stamps Andhra Pradesh 01,2.5.4.51=#0c325620537175617265204275696c64696e6720204b5352205061726b20526f61642057617264206e6f2d322020546164657061,STREET=Guntur,ST=Andhra Pradesh,2.5.4.17=#0c06353232353031,OU=Registration and stamps A.P,O=Registration and stamps Andhra Pradesh,C=IN</X509SubjectName><X509Certificate>MIIG4jCCBcqgAwIBAgIFMMJflz4wDQYJKoZIhvcNAQELBQAwgZMxCzAJBgNVBAYTAklOMS0wKwYD&#13;
VQQKEyRDYXByaWNvcm4gSWRlbnRpdHkgU2VydmljZXMgUHZ0IEx0ZC4xHTAbBgNVBAsTFENlcnRp&#13;
ZnlpbmcgQXV0aG9yaXR5MTYwNAYDVQQDEy1DYXByaWNvcm4gU3ViIENBIGZvciBEb2N1bWVudCBT&#13;
aWduZXIgRFNDIDIwMjIwHhcNMjMwODI5MTAyNDIyWhcNMjUwODI5MTAyNDIyWjCCARMxCzAJBgNV&#13;
BAYTAklOMS8wLQYDVQQKDCZSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaDEk&#13;
MCIGA1UECwwbUmVnaXN0cmF0aW9uIGFuZCBzdGFtcHMgQS5QMQ8wDQYDVQQRDAY1MjI1MDExFzAV&#13;
BgNVBAgMDkFuZGhyYSBQcmFkZXNoMQ8wDQYDVQQJDAZHdW50dXIxOzA5BgNVBDMMMlYgU3F1YXJl&#13;
IEJ1aWxkaW5nICBLU1IgUGFyayBSb2FkIFdhcmQgbm8tMiAgVGFkZXBhMTUwMwYDVQQDDCxEUyBS&#13;
ZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaCAwMTCCASIwDQYJKoZIhvcNAQEB&#13;
BQADggEPADCCAQoCggEBALmfwetib/CCujy+EMWE5bRZG9BsKLvVWcqi777D8mnHMiW9so8awtC7&#13;
T7OKFEqMpVH9ZJWt/vGyybMqhO5g6rd0FAlygnPfynh5wBUcOeigiu186dP2/ibqhOWcYzjmdKmL&#13;
nDHcYrfypqChyJzr2ksyvaY59Wq+c2DzbtsCwAQq5WvMSiiLT0rkF5YPKzWND8pT++1TndHgmDDg&#13;
u1Bn9HJkqkLemDuxIJCH6JMVUw5DSe36dvIhstxizJdWvPbt0AAo5LrQrJTHLJz/WBqpDWdOhC5J&#13;
4A1WcYTuO0zrl7qXRQi5/WA17XvPfjjmrMgkDwn63LYHYyW3US17yhGKpr0CAwEAAaOCArgwggK0&#13;
MDQGA1UdJQQtMCsGCCsGAQUFBwMEBggrBgEFBQcDAgYKKwYBBAGCNwoDDAYJKoZIhvcvAQEFMB8G&#13;
A1UdIwQYMBaAFPJ+3f2kiz2mTEzy/e9TMxcKyn7JMIGfBggrBgEFBQcBAQSBkjCBjzArBggrBgEF&#13;
BQcwAYYfaHR0cDovL29jc3AuY2VydGlmaWNhdGUuZGlnaXRhbDBgBggrBgEFBQcwAoZUaHR0cDov&#13;
L3d3dy5jZXJ0aWZpY2F0ZS5kaWdpdGFsL3JlcG9zaXRvcnkvQ2Fwcmljb3JuU3ViQ0Fmb3JEb2N1&#13;
bWVudFNpZ25lckRTQzIwMjIuY2VyMIH3BgNVHSAEge8wgewwVgYGYIJkZAIDMEwwSgYIKwYBBQUH&#13;
AgIwPho8Q2xhc3MgMyBDZXJ0aWZpY2F0ZSBpc3N1ZWQgYnkgQ2Fwcmljb3JuIENlcnRpZnlpbmcg&#13;
QXV0aG9yaXR5MEQGBmCCZGQKATA6MDgGCCsGAQUFBwICMCwaKk9yZ2FuaXphdGlvbmFsIERvY3Vt&#13;
ZW50IFNpZ25lciBDZXJ0aWZpY2F0ZTBMBgdggmRkAQoCMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93&#13;
d3cuY2VydGlmaWNhdGUuZGlnaXRhbC9yZXBvc2l0b3J5L2Nwc3YxLnBkZjBeBgNVHR8EVzBVMFOg&#13;
UaBPhk1odHRwOi8vd3d3LmNlcnRpZmljYXRlLmRpZ2l0YWwvY3JsL0NhcHJpY29yblN1YkNBZm9y&#13;
RG9jdW1lbnRTaWduZXJEU0MyMDIyLmNybDAdBgNVHQ4EFgQUG6Vd7+JpCpFMKNsAS7lPzlHZOAsw&#13;
IgYDVR0RBBswGYEXYWlnLmNhcmRAaWdycy5hcC5nb3YuaW4wDAYDVR0TAQH/BAIwADAOBgNVHQ8B&#13;
Af8EBAMCBsAwDQYJKoZIhvcNAQELBQADggEBADl5Mcra+Ymyo+b4pyVRIXU1fAZdIku5QXrsMTBe&#13;
s6y/0ORjQvL+rK303C9hgBoxIEuXPS0j3colfgZz3q+FDF5Xd0z6nwLL1SKan37UVjXTSjXBhbnq&#13;
Tal5ZYYnOoGz9OC3kmHdAPEHh9GeVpKNbU9tgzxXDJmlI4QWIL4aaFrlH48QNi4ZJ8aBE9tH4MLZ&#13;
mc4VKKDbdbh/xajOMipO1JQgzAqVmDIZcICuuSaw++H422heh8n/0+jiJ3/nWD6tvtLPml+I20Ra&#13;
LosaomP7GA0jZlVnGXH83P9IIldIQNykQqurB6v+V4/rJsMZTxtTsMONWMmA3ZEF4nWv2QUGK5k=</X509Certificate></X509Data></KeyInfo></Signature></Esign>""".trimIndent()
    }


    fun buildEsignXml(formattedTime: String, txnId: String): String {
        val raw = """
        <?xml version="1.0" encoding="UTF-8" standalone="no"?>
        <Esign AuthMode="4" aspId="ASPRASAPUAT007152" ekycId="858633410612" ekycIdType="A"
               responseSigType="pkcs7" responseUrl="com.cardprime.eauth" sc="Y"
               ts="$formattedTime" txn="TXN-$txnId" ver="2.1">
            <Docs>
                <InputHash docInfo="Document for eSign" hashAlgorithm="SHA256" id="1">
                    671ad5d3fe7de06dde824939b8d6658030bdf3df1c4408a37d1e73e581bff21f
                </InputHash>
            </Docs>
            <Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
                <SignedInfo>
                    <CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
                    <SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
                    <Reference URI="">
                        <Transforms>
                            <Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
                        </Transforms>
                        <DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
                        <DigestValue>R0YMsGnFTj8QWcj1hbuW3pyBx7U=</DigestValue>
                    </Reference>
                </SignedInfo>
                <SignatureValue>
                    n/TZhKyAIjz/r5Tinlm5ALYs5rd+Q4hSLkyK/b7pUpoHHtSj2uyxLnzMLieAr+PARBLHaYRZaZHl2o2QKH1tT0ZBB5YE0cLpB4C45Nw49l6Bz8Vj8gZZ52b5R3j4WaYzUDwjWaJiDE2rgs4TYnHd/75E1X68dB2wNUfjL/DUGGrnOiPUdaWxshIQyLXWb0dBekGGnBAu3BmMsteCVv6HKCEchiBJUk2iaV32qw2sZ39OH3DKeWamMLPAuWQWrcCBvPuSaMEUb8W+FRGijdMCdktO+cE8pmk+OGFX2KJNdSLJ4/7KgV1EkHBmzwUPWqdW0pdne977lsqT2alkBX5nsg==
                </SignatureValue>
                <KeyInfo>
                    <X509Data>
                        <X509SubjectName>
                            CN=DS Registration and stamps Andhra Pradesh 01…IN
                        </X509SubjectName>
                        <X509Certificate>MIIG4jCCBcqgAwIBAgIFMMJflz4wDQYJKoZIhvcNAQELBQAwgZMxCzAJBgNVBAYTAklOMS0wKwYDVQQKEyRDYXByaWNvcm4gSWRlbnRpdHkgU2VydmljZXMgUHZ0IEx0ZC4xHTAbBgNVBAsTFENlcnRpZnlpbmcgQXV0aG9yaXR5MTYwNAYDVQQDEy1DYXByaWNvcm4gU3ViIENBIGZvciBEb2N1bWVudCBTaWduZXIgRFNDIDIwMjIwHhcNMjMwODI5MTAyNDIyWhcNMjUwODI5MTAyNDIyWjCCARMxCzAJBgNVBAYTAklOMS8wLQYDVQQKDCZSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaDEkMCIGA1UECwwbUmVnaXN0cmF0aW9uIGFuZCBzdGFtcHMgQS5QMQ8wDQYDVQQRDAY1MjI1MDExFzAVBgNVBAgMDkFuZGhyYSBQcmFkZXNoMQ8wDQYDVQQJDAZHdW50dXIxOzA5BgNVBDMMMlYgU3F1YXJlIEJ1aWxkaW5nICBLU1IgUGFyayBSb2FkIFdhcmQgbm8tMiAgVGFkZXBhMTUwMwYDVQQDDCxEUyBSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaCAwMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALmfwetib/CCujy+EMWE5bRZG9BsKLvVWcqi777D8mnHMiW9so8awtC7T7OKFEqMpVH9ZJWt/vGyybMqhO5g6rd0FAlygnPfynh5wBUcOeigiu186dP2/ibqhOWcYzjmdKmLnDHcYrfypqChyJzr2ksyvaY59Wq+c2DzbtsCwAQq5WvMSiiLT0rkF5YPKzWND8pT++1TndHgmDDgu1Bn9HJkqkLemDuxIJCH6JMVUw5DSe36dvIhstxizJdWvPbt0AAo5LrQrJTHLJz/WBqpDWdOhC5J4A1WcYTuO0zrl7qXRQi5/WA17XvPfjjmrMgkDwn63LYHYyW3US17yhGKpr0CAwEAAaOCArgwggK0MDQGA1UdJQQtMCsGCCsGAQUFBwMEBggrBgEFBQcDAgYKKwYBBAGCNwoDDAYJKoZIhvcvAQEFMB8GA1UdIwQYMBaAFPJ+3f2kiz2mTEzy/e9TMxcKyn7JMIGfBggrBgEFBQcBAQSBkjCBjzArBggrBgEFBQcwAYYfaHR0cDovL29jc3AuY2VydGlmaWNhdGUuZGlnaXRhbDBgBggrBgEFBQcwAoZUaHR0cDovL3d3dy5jZXJ0aWZpY2F0ZS5kaWdpdGFsL3JlcG9zaXRvcnkvQ2Fwcmljb3JuU3ViQ0Fmb3JEb2N1bWVudFNpZ25lckRTQzIwMjIuY2VyMIH3BgNVHSAEge8wgewwVgYGYIJkZAIDMEwwSgYIKwYBBQUHAgIwPho8Q2xhc3MgMyBDZXJ0aWZpY2F0ZSBpc3N1ZWQgYnkgQ2Fwcmljb3JuIENlcnRpZnlpbmcgQXV0aG9yaXR5MEQGBmCCZGQKATA6MDgGCCsGAQUFBwICMCwaKk9yZ2FuaXphdGlvbmFsIERvY3VtZW50IFNpZ25lciBDZXJ0aWZpY2F0ZTBMBgdggmRkAQoCMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cuY2VydGlmaWNhdGUuZGlnaXRhbC9yZXBvc2l0b3J5L2Nwc3YxLnBkZjBeBgNVHR8EVzBVMFOgUaBPhk1odHRwOi8vd3d3LmNlcnRpZmljYXRlLmRpZ2l0YWwvY3JsL0NhcHJpY29yblN1YkNBZm9yRG9jdW1lbnRTaWduZXJEU0MyMDIyLmNybDAdBgNVHQ4EFgQUG6Vd7+JpCpFMKNsAS7lPzlHZOAswIgYDVR0RBBswGYEXYWlnLmNhcmRAaWdycy5hcC5nb3YuaW4wDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCBsAwDQYJKoZIhvcNAQELBQADggEBADl5Mcra+Ymyo+b4pyVRIXU1fAZdIku5QXrsMTBes6y/0ORjQvL+rK303C9hgBoxIEuXPS0j3colfgZz3q+FDF5Xd0z6nwLL1SKan37UVjXTSjXBhbnqTal5ZYYnOoGz9OC3kmHdAPEHh9GeVpKNbU9tgzxXDJmlI4QWIL4aaFrlH48QNi4ZJ8aBE9tH4MLZmc4VKKDbdbh/xajOMipO1JQgzAqVmDIZcICuuSaw++H422heh8n/0+jiJ3/nWD6tvtLPml+I20RaLosaomP7GA0jZlVnGXH83P9IIldIQNykQqurB6v+V4/rJsMZTxtTsMONWMmA3ZEF4nWv2QUGK5k=</X509Certificate>

                    </X509Data>
                </KeyInfo>
            </Signature>
        </Esign>
    """.trimIndent()

        // strip out all CR/LF so it becomes one continuous line
        return raw.replace(Regex("[\r\n]"), "")
    }


    fun buildEsignXml2(formattedTime: String, txnId: String): String {
        val raw = """
        <?xml version="1.0" encoding="UTF-8" standalone="no"?>
        <Esign AuthMode="4" aspId="ASPRASAPUAT007152" ekycId="858633410612" ekycIdType="A"
               responseSigType="pkcs7" responseUrl="com.cardprime.eauth" sc="Y"
               ts="$formattedTime" txn="TXN-$txnId" ver="2.1">
            <Docs>
                <InputHash docInfo="Document for eSign" hashAlgorithm="SHA256" id="1">
                    671ad5d3fe7de06dde824939b8d6658030bdf3df1c4408a37d1e73e581bff21f
                </InputHash>
            </Docs>
            <Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
                <SignedInfo>
                    <CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
                    <SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
                    <Reference URI="">
                        <Transforms>
                            <Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>
                        </Transforms>
                        <DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
                        <DigestValue>R0YMsGnFTj8QWcj1hbuW3pyBx7U=</DigestValue>
                    </Reference>
                </SignedInfo>
                <SignatureValue>
                    n/TZhKyAIjz/r5Tinlm5ALYs5rd+Q4hSLkyK/b7pUpoHHtSj2uyxLnzMLieAr+PARBLHaYRZaZHl2o2QKH1tT0ZBB5YE0cLpB4C45Nw49l6Bz8Vj8gZZ52b5R3j4WaYzUDwjWaJiDE2rgs4TYnHd/75E1X68dB2wNUfjL/DUGGrnOiPUdaWxshIQyLXWb0dBekGGnBAu3BmMsteCVv6HKCEchiBJUk2iaV32qw2sZ39OH3DKeWamMLPAuWQWrcCBvPuSaMEUb8W+FRGijdMCdktO+cE8pmk+OGFX2KJNdSLJ4/7KgV1EkHBmzwUPWqdW0pdne977lsqT2alkBX5nsg==
                </SignatureValue>
                <KeyInfo>
                    <X509Data>
                        <X509SubjectName>CN=DS Registration and stamps Andhra Pradesh 01…IN</X509SubjectName>
                        <X509Certificate>MIIG4jCCBcqgAwIBAgIFMMJflz4wDQYJKoZIhvcNAQELBQAwgZMxCzAJBgNVBAYTAklOMS0wKwYDVQQKEyRDYXByaWNvcm4gSWRlbnRpdHkgU2VydmljZXMgUHZ0IEx0ZC4xHTAbBgNVBAsTFENlcnRpZnlpbmcgQXV0aG9yaXR5MTYwNAYDVQQDEy1DYXByaWNvcm4gU3ViIENBIGZvciBEb2N1bWVudCBTaWduZXIgRFNDIDIwMjIwHhcNMjMwODI5MTAyNDIyWhcNMjUwODI5MTAyNDIyWjCCARMxCzAJBgNVBAYTAklOMS8wLQYDVQQKDCZSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaDEkMCIGA1UECwwbUmVnaXN0cmF0aW9uIGFuZCBzdGFtcHMgQS5QMQ8wDQYDVQQRDAY1MjI1MDExFzAVBgNVBAgMDkFuZGhyYSBQcmFkZXNoMQ8wDQYDVQQJDAZHdW50dXIxOzA5BgNVBDMMMlYgU3F1YXJlIEJ1aWxkaW5nICBLU1IgUGFyayBSb2FkIFdhcmQgbm8tMiAgVGFkZXBhMTUwMwYDVQQDDCxEUyBSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaCAwMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALmfwetib/CCujy+EMWE5bRZG9BsKLvVWcqi777D8mnHMiW9so8awtC7T7OKFEqMpVH9ZJWt/vGyybMqhO5g6rd0FAlygnPfynh5wBUcOeigiu186dP2/ibqhOWcYzjmdKmLnDHcYrfypqChyJzr2ksyvaY59Wq+c2DzbtsCwAQq5WvMSiiLT0rkF5YPKzWND8pT++1TndHgmDDgu1Bn9HJkqkLemDuxIJCH6JMVUw5DSe36dvIhstxizJdWvPbt0AAo5LrQrJTHLJz/WBqpDWdOhC5J4A1WcYTuO0zrl7qXRQi5/WA17XvPfjjmrMgkDwn63LYHYyW3US17yhGKpr0CAwEAAaOCArgwggK0MDQGA1UdJQQtMCsGCCsGAQUFBwMEBggrBgEFBQcDAgYKKwYBBAGCNwoDDAYJKoZIhvcvAQEFMB8GA1UdIwQYMBaAFPJ+3f2kiz2mTEzy/e9TMxcKyn7JMIGfBggrBgEFBQcBAQSBkjCBjzArBggrBgEFBQcwAYYfaHR0cDovL29jc3AuY2VydGlmaWNhdGUuZGlnaXRhbDBgBggrBgEFBQcwAoZUaHR0cDovL3d3dy5jZXJ0aWZpY2F0ZS5kaWdpdGFsL3JlcG9zaXRvcnkvQ2Fwcmljb3JuU3ViQ0Fmb3JEb2N1bWVudFNpZ25lckRTQzIwMjIuY2VyMIH3BgNVHSAEge8wgewwVgYGYIJkZAIDMEwwSgYIKwYBBQUHAgIwPho8Q2xhc3MgMyBDZXJ0aWZpY2F0ZSBpc3N1ZWQgYnkgQ2Fwcmljb3JuIENlcnRpZnlpbmcgQXV0aG9yaXR5MEQGBmCCZGQKATA6MDgGCCsGAQUFBwICMCwaKk9yZ2FuaXphdGlvbmFsIERvY3VtZW50IFNpZ25lciBDZXJ0aWZpY2F0ZTBMBgdggmRkAQoCMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cuY2VydGlmaWNhdGUuZGlnaXRhbC9yZXBvc2l0b3J5L2Nwc3YxLnBkZjBeBgNVHR8EVzBVMFOgUaBPhk1odHRwOi8vd3d3LmNlcnRpZmljYXRlLmRpZ2l0YWwvY3JsL0NhcHJpY29yblN1YkNBZm9yRG9jdW1lbnRTaWduZXJEU0MyMDIyLmNybDAdBgNVHQ4EFgQUG6Vd7+JpCpFMKNsAS7lPzlHZOAswIgYDVR0RBBswGYEXYWlnLmNhcmRAaWdycy5hcC5nb3YuaW4wDAYDVR0TAQH/BAIwADAOBgNVHQ8BAf8EBAMCBsAwDQYJKoZIhvcNAQELBQADggEBADl5Mcra+Ymyo+b4pyVRIXU1fAZdIku5QXrsMTBes6y/0ORjQvL+rK303C9hgBoxIEuXPS0j3colfgZz3q+FDF5Xd0z6nwLL1SKan37UVjXTSjXBhbnqTal5ZYYnOoGz9OC3kmHdAPEHh9GeVpKNbU9tgzxXDJmlI4QWIL4aaFrlH48QNi4ZJ8aBE9tH4MLZmc4VKKDbdbh/xajOMipO1JQgzAqVmDIZcICuuSaw++H422heh8n/0+jiJ3/nWD6tvtLPml+I20RaLosaomP7GA0jZlVnGXH83P9IIldIQNykQqurB6v+V4/rJsMZTxtTsMONWMmA3ZEF4nWv2QUGK5k=</X509Certificate>
                    </X509Data>
                </KeyInfo>
            </Signature>
        </Esign>
    """.trimIndent()

        return raw.replace(Regex("[\r\n]"), "")
    }



//    <?xml version='1.0' encoding='UTF-8'?>
//    <Esign ver="2.1" sc="Y" ts="2025-06-09T17:45:00" txn="$txnId" ekycId="123456789012" aspId="YourASPId" authMode="1" responseSigType="pkcs7" responseUrl="https://yourdomain.com/esign-response">
//    <Docs>
//    <InputHash id="1" hashAlgorithm="SHA256" docInfo="Test Document">
//    qTjvTGi67zLk7lUmtjrwI1Oe3qS5HxDeICgjE5L4JD4=
//    </InputHash>
//    </Docs>
//    </Esign>

//    <Param name='cameraUsage' value='F'/>
//    <Param name='auaCode' value='$auaCode'/>
//    <Param name='callBackUrl' value='$callbackUrl'/>
//    <Param name='auaAuthToken' value='$jwtToken'/>
}