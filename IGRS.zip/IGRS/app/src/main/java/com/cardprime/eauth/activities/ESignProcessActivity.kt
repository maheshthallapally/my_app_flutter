package com.cardprime.eauth.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.apiservice.models.esign.ESignSaveTxnRequest
import com.cardprime.eauth.apiservice.models.esign.ESignSaveTxnResponse
import com.cardprime.eauth.apiservice.models.esign.ESignXMLvalidateRequest
import com.cardprime.eauth.apiservice.models.esign.ESignXMLvalidateResponse
import com.cardprime.eauth.utils.QRScanESignData
import com.google.gson.Gson
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.widgets.TextViewCustom
import org.w3c.dom.Document
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import javax.xml.parsers.DocumentBuilderFactory


class ESignProcessActivity : ParentActivity() {

    private lateinit var iv_error: ImageView
    private lateinit var lblTitle2: TextViewCustom
    private lateinit var lblResponse: TextViewCustom
    private lateinit var lblErrorResponse: TextViewCustom
    private lateinit var lblTryAgian: TextViewCustom
    private lateinit var ll_mainScreen: RelativeLayout
    private lateinit var ll_success: RelativeLayout
    private lateinit var lblDetails: TextViewCustom
    private lateinit var lblOK: TextViewCustom
    private lateinit var myImageView: ImageView
    private lateinit var lblSuccessMessage: TextViewCustom

    private lateinit var applicationPreferences: ApplicationPreferences
    private lateinit var activity: Activity

    var eSignXMLvalidateRequestRetry = 0
    var eSignSaveTxnRequestRetry = 0
    var esign_type: String = "esign"

    override fun onCreate(savedInstanceState: Bundle?) {
        applicationPreferences = ApplicationPreferences
        // Retrieve saved theme and apply
        activity = this
        Utilities.applyTheme(applicationPreferences.getThemeMode(this), activity)
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_ekyc_esign_process)

        esign_type = intent.getStringExtra("type").toString()

        iv_error = findViewById(R.id.iv_error)
        lblTitle2 = findViewById(R.id.lblTitle2)
        lblResponse = findViewById(R.id.lblResponse)
        lblErrorResponse = findViewById(R.id.lblErrorResponse)
        lblTryAgian = findViewById(R.id.lblTryAgian)
        ll_mainScreen =findViewById(R.id.ll_mainScreen)
        ll_success = findViewById(R.id.ll_success)
        lblDetails = findViewById(R.id.lblDetails)
        lblOK = findViewById(R.id.lblOK)
        myImageView = findViewById(R.id.myImageView)
        lblSuccessMessage = findViewById(R.id.lblSuccessMessage)
        lblSuccessMessage.visibility = View.GONE

        if(esign_type.equals("esign")){
            lblTitle2.text = getText(R.string.e_sign)
        }else{
            lblTitle2.text = getText(R.string.refusal_e_sign)
        }

        //lblTitle2.text = thisActivity.getString(R.string.e_sign)

        /*lblResponse.setOnClickListener {
            val textToCopy = lblResponse.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Copied Text", textToCopy)
            clipboard.setPrimaryClip(clip)
        }*/

        openFaceScan()

        lblTryAgian.visibility = View.VISIBLE
        lblTryAgian.setOnClickListener(){
            lblErrorResponse.text = ""
            iv_error.visibility = View.GONE
            lblResponse.visibility = View.GONE
            lblTryAgian.visibility = View.GONE
            /*openFaceScan()*/
            finish()
        }

        lblOK.setOnClickListener(){
            finish()
        }

    }

    fun openFaceScan(){

        /*var requestMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><Esign AuthMode=\"4\" aspId=\"ASPRASAPUAT007152\" ekycId=\"\" ekycIdType=\"A\" responseSigType=\"pkcs7\" responseUrl=\"http://127.0.0.1:9080/igrs-esign-service/igrsESignResponse\" sc=\"Y\" ts=\"2025-06-16T17:07:31\" txn=\"Test-1750073845347\" ver=\"2.1\"><Docs><InputHash docInfo=\"Document for eSign\" hashAlgorithm=\"SHA256\" id=\"1\">02d9d5ce4bfd338151581584b1353dc7dc23cff496af211e3b4cb08eb28619b8</InputHash></Docs><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/><Reference URI=\"\"><Transforms><Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/><DigestValue>bfCAsJ0z8ic9rfEyvHzaK45RsTY=</DigestValue></Reference></SignedInfo><SignatureValue>kusi1Tvzt1H7LHk9uEVqMAVGCLUHB2TL8GZlaV0Z6gkRuFZpiiWHSO2wlZvW5F7fAb3WuiWdl+D8&#13;\n" +
                "zgPVZo+HCZRDsjjeGrQPymWPkBJdRSiQPsxJpHFIyCws33qo0SrjmbgJpaVMDBg/qAOZDZLWower&#13;\n" +
                "ebP7s5b2wcWO6Sb2nx0q5Dr5wSTmD8p8oZjdEJW1mOhTdGPnPUrRcA2SMbS+8HoHGFun3F5s5ktg&#13;\n" +
                "V9Xx8L/5Pa4tW9bqWemW8Wc062Z3TdZyu3L2GFGWGo/j0NoOdwZYgkW9i84boYqoHzBwFhs0M06N&#13;\n" +
                "KGtRquMsxINqIbc0ROZneJ01kej7omj41gp4ZQ==</SignatureValue><KeyInfo><X509Data><X509SubjectName>CN=DS Registration and stamps Andhra Pradesh 01,2.5.4.51=#0c325620537175617265204275696c64696e6720204b5352205061726b20526f61642057617264206e6f2d322020546164657061,STREET=Guntur,ST=Andhra Pradesh,2.5.4.17=#0c06353232353031,OU=Registration and stamps A.P,O=Registration and stamps Andhra Pradesh,C=IN</X509SubjectName><X509Certificate>MIIG4jCCBcqgAwIBAgIFMMJflz4wDQYJKoZIhvcNAQELBQAwgZMxCzAJBgNVBAYTAklOMS0wKwYD&#13;\n" +
                "VQQKEyRDYXByaWNvcm4gSWRlbnRpdHkgU2VydmljZXMgUHZ0IEx0ZC4xHTAbBgNVBAsTFENlcnRp&#13;\n" +
                "ZnlpbmcgQXV0aG9yaXR5MTYwNAYDVQQDEy1DYXByaWNvcm4gU3ViIENBIGZvciBEb2N1bWVudCBT&#13;\n" +
                "aWduZXIgRFNDIDIwMjIwHhcNMjMwODI5MTAyNDIyWhcNMjUwODI5MTAyNDIyWjCCARMxCzAJBgNV&#13;\n" +
                "BAYTAklOMS8wLQYDVQQKDCZSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaDEk&#13;\n" +
                "MCIGA1UECwwbUmVnaXN0cmF0aW9uIGFuZCBzdGFtcHMgQS5QMQ8wDQYDVQQRDAY1MjI1MDExFzAV&#13;\n" +
                "BgNVBAgMDkFuZGhyYSBQcmFkZXNoMQ8wDQYDVQQJDAZHdW50dXIxOzA5BgNVBDMMMlYgU3F1YXJl&#13;\n" +
                "IEJ1aWxkaW5nICBLU1IgUGFyayBSb2FkIFdhcmQgbm8tMiAgVGFkZXBhMTUwMwYDVQQDDCxEUyBS&#13;\n" +
                "ZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaCAwMTCCASIwDQYJKoZIhvcNAQEB&#13;\n" +
                "BQADggEPADCCAQoCggEBALmfwetib/CCujy+EMWE5bRZG9BsKLvVWcqi777D8mnHMiW9so8awtC7&#13;\n" +
                "T7OKFEqMpVH9ZJWt/vGyybMqhO5g6rd0FAlygnPfynh5wBUcOeigiu186dP2/ibqhOWcYzjmdKmL&#13;\n" +
                "nDHcYrfypqChyJzr2ksyvaY59Wq+c2DzbtsCwAQq5WvMSiiLT0rkF5YPKzWND8pT++1TndHgmDDg&#13;\n" +
                "u1Bn9HJkqkLemDuxIJCH6JMVUw5DSe36dvIhstxizJdWvPbt0AAo5LrQrJTHLJz/WBqpDWdOhC5J&#13;\n" +
                "4A1WcYTuO0zrl7qXRQi5/WA17XvPfjjmrMgkDwn63LYHYyW3US17yhGKpr0CAwEAAaOCArgwggK0&#13;\n" +
                "MDQGA1UdJQQtMCsGCCsGAQUFBwMEBggrBgEFBQcDAgYKKwYBBAGCNwoDDAYJKoZIhvcvAQEFMB8G&#13;\n" +
                "A1UdIwQYMBaAFPJ+3f2kiz2mTEzy/e9TMxcKyn7JMIGfBggrBgEFBQcBAQSBkjCBjzArBggrBgEF&#13;\n" +
                "BQcwAYYfaHR0cDovL29jc3AuY2VydGlmaWNhdGUuZGlnaXRhbDBgBggrBgEFBQcwAoZUaHR0cDov&#13;\n" +
                "L3d3dy5jZXJ0aWZpY2F0ZS5kaWdpdGFsL3JlcG9zaXRvcnkvQ2Fwcmljb3JuU3ViQ0Fmb3JEb2N1&#13;\n" +
                "bWVudFNpZ25lckRTQzIwMjIuY2VyMIH3BgNVHSAEge8wgewwVgYGYIJkZAIDMEwwSgYIKwYBBQUH&#13;\n" +
                "AgIwPho8Q2xhc3MgMyBDZXJ0aWZpY2F0ZSBpc3N1ZWQgYnkgQ2Fwcmljb3JuIENlcnRpZnlpbmcg&#13;\n" +
                "QXV0aG9yaXR5MEQGBmCCZGQKATA6MDgGCCsGAQUFBwICMCwaKk9yZ2FuaXphdGlvbmFsIERvY3Vt&#13;\n" +
                "ZW50IFNpZ25lciBDZXJ0aWZpY2F0ZTBMBgdggmRkAQoCMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93&#13;\n" +
                "d3cuY2VydGlmaWNhdGUuZGlnaXRhbC9yZXBvc2l0b3J5L2Nwc3YxLnBkZjBeBgNVHR8EVzBVMFOg&#13;\n" +
                "UaBPhk1odHRwOi8vd3d3LmNlcnRpZmljYXRlLmRpZ2l0YWwvY3JsL0NhcHJpY29yblN1YkNBZm9y&#13;\n" +
                "RG9jdW1lbnRTaWduZXJEU0MyMDIyLmNybDAdBgNVHQ4EFgQUG6Vd7+JpCpFMKNsAS7lPzlHZOAsw&#13;\n" +
                "IgYDVR0RBBswGYEXYWlnLmNhcmRAaWdycy5hcC5nb3YuaW4wDAYDVR0TAQH/BAIwADAOBgNVHQ8B&#13;\n" +
                "Af8EBAMCBsAwDQYJKoZIhvcNAQELBQADggEBADl5Mcra+Ymyo+b4pyVRIXU1fAZdIku5QXrsMTBe&#13;\n" +
                "s6y/0ORjQvL+rK303C9hgBoxIEuXPS0j3colfgZz3q+FDF5Xd0z6nwLL1SKan37UVjXTSjXBhbnq&#13;\n" +
                "Tal5ZYYnOoGz9OC3kmHdAPEHh9GeVpKNbU9tgzxXDJmlI4QWIL4aaFrlH48QNi4ZJ8aBE9tH4MLZ&#13;\n" +
                "mc4VKKDbdbh/xajOMipO1JQgzAqVmDIZcICuuSaw++H422heh8n/0+jiJ3/nWD6tvtLPml+I20Ra&#13;\n" +
                "LosaomP7GA0jZlVnGXH83P9IIldIQNykQqurB6v+V4/rJsMZTxtTsMONWMmA3ZEF4nWv2QUGK5k=</X509Certificate></X509Data></KeyInfo></Signature></Esign>";*/


        var requestMsg = applicationPreferences.getAadharNumber(thisActivity).toString()


        val ACTION_ESIGNRESPONSE = "com.nsdl.egov.esign.rdservice.fp.CAPTURE";
        val REQUEST_CODE=101;
        val appStartIntent =  Intent()
        appStartIntent.setAction(ACTION_ESIGNRESPONSE)
        appStartIntent.putExtra("msg", requestMsg) //msg contains esign request xml from ASP.
        appStartIntent.putExtra("env", "PREPROD") //PREPROD or PROD (case sensitive).
        appStartIntent.putExtra("returnUrl", "com.cardprime.eauth"); //ASP package name
        startActivityForResult(appStartIntent, REQUEST_CODE);

    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

        val response = intent?.getStringExtra("msg")  // key used by NSDL or RD service
        if (response != null) {
            // Parse response XML and continue your flow
            Log.d("EsignResponse", response)
        } else {
            Log.e("EsignResponse", "No response received")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        var print_data = "requestCode "+requestCode;
        var pidDataResponse = "";
        Utilities.logI("requestCode  : ${requestCode}")

        if (requestCode == 101 && resultCode == RESULT_OK) {

            var eSignResponse = data?.getStringExtra("signedResponse")

            /*var requestMsg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><Esign errCode=\"NA\" errMsg=\"NA\" resCode=\"3210487A99F0406A961CFFCEA49755A7\" status=\"1\" AuthMode=\"4\" aspId=\"ASPRASAPUAT007152\" ekycId=\"\" ekycIdType=\"A\" responseSigType=\"pkcs7\" responseUrl=\"http://127.0.0.1:9080/igrs-esign-service/igrsESignResponse\" sc=\"Y\" ts=\"2025-06-16T16:08:48\" txn=\"Test-1750070320631\" ver=\"2.1\"><Docs><InputHash docInfo=\"Document for eSign\" hashAlgorithm=\"SHA256\" id=\"1\">9bba672d791f2df64551093fc2218d3206bd9c4a603bafb9f58246aa594cd7a4</InputHash></Docs><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/><Reference URI=\"\"><Transforms><Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/><DigestValue>+N97UTtwHtps56jF8nC3YGOi12g=</DigestValue></Reference></SignedInfo><SignatureValue>WFckL59+aYfM/zphemXgDIAaiGY7UKW/6F4Y4YMiFv1zDsQnSA/R0vBTp8z3uKi9UXLysiwAQJi1&#13;\n" +
                    "QpZ0kdtp69cnErFMGpGNUqaYUccUVbNyY0jsWdwMzyqKQqVmTRnlZ4vvq5giiudr1QJ5UOnBeQn2&#13;\n" +
                    "5BG/6MIulHHLjGSt15bbYE9j+2pg4I18ExTg8qF9C3EUEgqi0ZzfxUyUSrwY8ZjXqgf9I6Ob8N7/&#13;\n" +
                    "v9NggSi5bKG9R0qd70uCG51L77wcVqLRHfeCIbjrkwhXY9y4tZ+HanGVih2Xj2xSyFHEdo4iIiTI&#13;\n" +
                    "ddn2Hl5UBKaBrHR0vg/2T2GgYjCaXD+qOKLb3A==</SignatureValue><KeyInfo><X509Data><X509SubjectName>CN=DS Registration and stamps Andhra Pradesh 01,2.5.4.51=#0c325620537175617265204275696c64696e6720204b5352205061726b20526f61642057617264206e6f2d322020546164657061,STREET=Guntur,ST=Andhra Pradesh,2.5.4.17=#0c06353232353031,OU=Registration and stamps A.P,O=Registration and stamps Andhra Pradesh,C=IN</X509SubjectName><X509Certificate>MIIG4jCCBcqgAwIBAgIFMMJflz4wDQYJKoZIhvcNAQELBQAwgZMxCzAJBgNVBAYTAklOMS0wKwYD&#13;\n" +
                    "VQQKEyRDYXByaWNvcm4gSWRlbnRpdHkgU2VydmljZXMgUHZ0IEx0ZC4xHTAbBgNVBAsTFENlcnRp&#13;\n" +
                    "ZnlpbmcgQXV0aG9yaXR5MTYwNAYDVQQDEy1DYXByaWNvcm4gU3ViIENBIGZvciBEb2N1bWVudCBT&#13;\n" +
                    "aWduZXIgRFNDIDIwMjIwHhcNMjMwODI5MTAyNDIyWhcNMjUwODI5MTAyNDIyWjCCARMxCzAJBgNV&#13;\n" +
                    "BAYTAklOMS8wLQYDVQQKDCZSZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaDEk&#13;\n" +
                    "MCIGA1UECwwbUmVnaXN0cmF0aW9uIGFuZCBzdGFtcHMgQS5QMQ8wDQYDVQQRDAY1MjI1MDExFzAV&#13;\n" +
                    "BgNVBAgMDkFuZGhyYSBQcmFkZXNoMQ8wDQYDVQQJDAZHdW50dXIxOzA5BgNVBDMMMlYgU3F1YXJl&#13;\n" +
                    "IEJ1aWxkaW5nICBLU1IgUGFyayBSb2FkIFdhcmQgbm8tMiAgVGFkZXBhMTUwMwYDVQQDDCxEUyBS&#13;\n" +
                    "ZWdpc3RyYXRpb24gYW5kIHN0YW1wcyBBbmRocmEgUHJhZGVzaCAwMTCCASIwDQYJKoZIhvcNAQEB&#13;\n" +
                    "BQADggEPADCCAQoCggEBALmfwetib/CCujy+EMWE5bRZG9BsKLvVWcqi777D8mnHMiW9so8awtC7&#13;\n" +
                    "T7OKFEqMpVH9ZJWt/vGyybMqhO5g6rd0FAlygnPfynh5wBUcOeigiu186dP2/ibqhOWcYzjmdKmL&#13;\n" +
                    "nDHcYrfypqChyJzr2ksyvaY59Wq+c2DzbtsCwAQq5WvMSiiLT0rkF5YPKzWND8pT++1TndHgmDDg&#13;\n" +
                    "u1Bn9HJkqkLemDuxIJCH6JMVUw5DSe36dvIhstxizJdWvPbt0AAo5LrQrJTHLJz/WBqpDWdOhC5J&#13;\n" +
                    "4A1WcYTuO0zrl7qXRQi5/WA17XvPfjjmrMgkDwn63LYHYyW3US17yhGKpr0CAwEAAaOCArgwggK0&#13;\n" +
                    "MDQGA1UdJQQtMCsGCCsGAQUFBwMEBggrBgEFBQcDAgYKKwYBBAGCNwoDDAYJKoZIhvcvAQEFMB8G&#13;\n" +
                    "A1UdIwQYMBaAFPJ+3f2kiz2mTEzy/e9TMxcKyn7JMIGfBggrBgEFBQcBAQSBkjCBjzArBggrBgEF&#13;\n" +
                    "BQcwAYYfaHR0cDovL29jc3AuY2VydGlmaWNhdGUuZGlnaXRhbDBgBggrBgEFBQcwAoZUaHR0cDov&#13;\n" +
                    "L3d3dy5jZXJ0aWZpY2F0ZS5kaWdpdGFsL3JlcG9zaXRvcnkvQ2Fwcmljb3JuU3ViQ0Fmb3JEb2N1&#13;\n" +
                    "bWVudFNpZ25lckRTQzIwMjIuY2VyMIH3BgNVHSAEge8wgewwVgYGYIJkZAIDMEwwSgYIKwYBBQUH&#13;\n" +
                    "AgIwPho8Q2xhc3MgMyBDZXJ0aWZpY2F0ZSBpc3N1ZWQgYnkgQ2Fwcmljb3JuIENlcnRpZnlpbmcg&#13;\n" +
                    "QXV0aG9yaXR5MEQGBmCCZGQKATA6MDgGCCsGAQUFBwICMCwaKk9yZ2FuaXphdGlvbmFsIERvY3Vt&#13;\n" +
                    "ZW50IFNpZ25lciBDZXJ0aWZpY2F0ZTBMBgdggmRkAQoCMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93&#13;\n" +
                    "d3cuY2VydGlmaWNhdGUuZGlnaXRhbC9yZXBvc2l0b3J5L2Nwc3YxLnBkZjBeBgNVHR8EVzBVMFOg&#13;\n" +
                    "UaBPhk1odHRwOi8vd3d3LmNlcnRpZmljYXRlLmRpZ2l0YWwvY3JsL0NhcHJpY29yblN1YkNBZm9y&#13;\n" +
                    "RG9jdW1lbnRTaWduZXJEU0MyMDIyLmNybDAdBgNVHQ4EFgQUG6Vd7+JpCpFMKNsAS7lPzlHZOAsw&#13;\n" +
                    "IgYDVR0RBBswGYEXYWlnLmNhcmRAaWdycy5hcC5nb3YuaW4wDAYDVR0TAQH/BAIwADAOBgNVHQ8B&#13;\n" +
                    "Af8EBAMCBsAwDQYJKoZIhvcNAQELBQADggEBADl5Mcra+Ymyo+b4pyVRIXU1fAZdIku5QXrsMTBe&#13;\n" +
                    "s6y/0ORjQvL+rK303C9hgBoxIEuXPS0j3colfgZz3q+FDF5Xd0z6nwLL1SKan37UVjXTSjXBhbnq&#13;\n" +
                    "Tal5ZYYnOoGz9OC3kmHdAPEHh9GeVpKNbU9tgzxXDJmlI4QWIL4aaFrlH48QNi4ZJ8aBE9tH4MLZ&#13;\n" +
                    "mc4VKKDbdbh/xajOMipO1JQgzAqVmDIZcICuuSaw++H422heh8n/0+jiJ3/nWD6tvtLPml+I20Ra&#13;\n" +
                    "LosaomP7GA0jZlVnGXH83P9IIldIQNykQqurB6v+V4/rJsMZTxtTsMONWMmA3ZEF4nWv2QUGK5k=</X509Certificate></X509Data></KeyInfo></Signature></Esign>";

            eSignResponse = requestMsg*/

            Utilities.logI("eSignResponse : ${eSignResponse}")

            val xmlString = eSignResponse

            try {
                val factory = DocumentBuilderFactory.newInstance()
                val builder = factory.newDocumentBuilder()
                val inputStream = ByteArrayInputStream(xmlString?.toByteArray(Charsets.UTF_8))
                val document: Document = builder.parse(inputStream)
                document.documentElement.normalize()

                val root = document.documentElement
                if (eSignResponse.toString().contains("errCode") && eSignResponse.toString()
                        .contains("errMsg") && eSignResponse.toString().contains("status")
                ) {
                    val errCode = root.getAttribute("errCode")
                    val errMsg = root.getAttribute("errMsg")
                    val status = root.getAttribute("status")

                    if (status.equals("1")) {

                        if(esign_type.equals("esign")) {
                            lblResponse.text =
                                "eSign successfully completed.\n\nUpdating the data.\n\nPlease wait.."
                        }else{
                            lblResponse.text =
                                "Refusal eSign successfully completed.\n\nUpdating the data.\n\nPlease wait.."
                        }

                        lblResponse.visibility = View.VISIBLE
                        lblTryAgian.visibility = View.GONE
                        if (eSignResponse != null) {
                            callAPI(eSignResponse)
                        } else {
                            lblResponse.text =
                                "eSign updating the data failed.\n\nPlease try again.."
                        }
                    } else {
                        lblResponse.text = "Error Code: $errCode\n$errMsg"
                        iv_error.visibility = View.VISIBLE
                        lblResponse.visibility = View.VISIBLE
                        lblTryAgian.visibility = View.VISIBLE
                    }

                    Utilities.logI("Error Code: $errCode")
                    Utilities.logI("Error Message: $errMsg")


                } else {
                    lblResponse.text = print_data
                    lblResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                }

                print_data = "eSignResponse: (${eSignResponse}"
            }catch (e: Exception) {
                e.printStackTrace()
                lblResponse.text = eSignResponse+"\n\nPlease try again."
                lblResponse.visibility = View.VISIBLE
                lblTryAgian.visibility = View.VISIBLE
            }

        }else{
            iv_error.visibility = View.VISIBLE
            lblResponse.visibility = View.VISIBLE
            lblResponse.text = "Failed to complete the eSign, Please try again"
            lblTryAgian.visibility = View.VISIBLE
        }

        Utilities.logI("onActivityResult pidDataResponse : $pidDataResponse")

    }


    fun callAPI(xmlDataResponse: String){
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)


        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.esign_service))
        val eSignXMLvalidateRequest = ESignXMLvalidateRequest(Utilities.encodeToBase64(xmlDataResponse))


        // Make the AadharEKYCWithFacialPID call
        apiService.validateESignResponseXML(eSignXMLvalidateRequest).enqueue(object : Callback<ESignXMLvalidateResponse> {
            override fun onResponse(
                call: Call<ESignXMLvalidateResponse>,
                response: Response<ESignXMLvalidateResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)
                try{ val request = call.request()
                    Utilities.logI("validateESignResponseXML Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("validateESignResponseXML Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful AadharEKYCWithFacialPID
                    val eSignXMLvalidateResponse = response.body()

                    var status = eSignXMLvalidateResponse?.status

                    if (status != null) {
                        if(status.lowercase().contains("success")) {

                            if(esign_type.equals("esign")) {
                                callESignSaveAPI()
                                var display = "eSign validation completed, calling eSign save transaction.."
                                lblErrorResponse.text = display
                            }else{
                                callESignSaveAPIForRefusal()
                                var display = "Refusal eSign validation completed, calling Refusal eSign save transaction.."
                                lblErrorResponse.text = display
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            var error = eSignXMLvalidateResponse?.error


                            if (!error.isNullOrEmpty()) {
                                lblErrorResponse.text = error
                            }else {
                                lblErrorResponse.text =
                                    "eSign validation failed\n" + getString(R.string.failed_try_again)
                            }
                            lblResponse.visibility = View.GONE
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = ""+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                        lblResponse.visibility = View.GONE
                    }


                } else {

                    val eSignXMLvalidateResponse = response.body()

                    var error = eSignXMLvalidateResponse?.error


                    if (!error.isNullOrEmpty()) {
                        lblErrorResponse.text = error
                    }else {
                        lblErrorResponse.text =
                            "eSign validation process failed.\n" + getString(R.string.failed_try_again)
                    }
                    lblResponse.visibility = View.GONE

                    /*var display = "eSign validation completed, calling eSign save transaction.."
                    lblErrorResponse.text = display
                    callESignSaveAPI()*/

                }
            }

            override fun onFailure(call: Call<ESignXMLvalidateResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("eSignXMLvalidateRequest failed: ${t.message}")

                if(eSignXMLvalidateRequestRetry == 0){
                    eSignXMLvalidateRequestRetry = 1
                    callAPI(xmlDataResponse)
                }else{
                    eSignXMLvalidateRequestRetry = 0
                    // Handle failure
                    lblErrorResponse.text = "eSign validation failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                    lblResponse.visibility = View.GONE
                }


            }
        })

    }

    data class PidResponseError(val errCode: String, val errInfo: String)

    fun parsePidDataError(xml: String): PidResponseError? {
        try {
            val factory = XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true
            val parser = factory.newPullParser()
            parser.setInput(xml.reader())

            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "Resp") {
                    val errCode = parser.getAttributeValue(null, "errCode") ?: ""
                    val errInfo = parser.getAttributeValue(null, "errInfo") ?: ""
                    return PidResponseError(errCode, errInfo)
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }


    fun callESignSaveAPI() {

        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        val regData = Gson().fromJson(applicationPreferences.getQRData(thisActivity).toString(), QRScanESignData::class.java)

        //{"sroCode":615,"bookNo":1,"documentNo":14,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":1,"name":"Putta Yashwanth","location":"GUNADALA","igrsEsign":true,"applicationId":"2506151750069689","txnid":34632042896698370}
        //{"sroCode":615,"bookNo":1,"documentNo":12,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":4,"name":"Srikanth",       "location":"GUNADALA","igrsEsign":true,"applicationId":"2506151749796923","txnid":5417699209448212}
        //{"sroCode":615,"bookNo":1,"documentNo":14,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":1,"name":"Putta Yashwanth","location":"GUNADALA","igrsEsign":true,"applicationId":"2506151750069689","txnid":34632042896698370}

        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val DOCT_NO = regData.doctNo
        val REG_YEAR = regData.regYear
        val CODE = regData.code
        val EC_NUMBER = regData.ec_number
        val AUTH_MDOE = regData.authmode
        val NAME = regData.name
        val LOCATION = regData.location
        val APP_ID = regData.applicationId
        val TXN_ID = regData.txnid


        val eSignSaveTxnRequest = ESignSaveTxnRequest(SR_CODE, BOOK_NO, DOCT_NO, REG_YEAR, CODE, EC_NUMBER,
            AUTH_MDOE, NAME, LOCATION, true, APP_ID, TXN_ID)


        // Make the saveParties call
        apiService.saveESignTxn(eSignSaveTxnRequest).enqueue(object : Callback<ESignSaveTxnResponse> {
            override fun onResponse(
                call: Call<ESignSaveTxnResponse>,
                response: Response<ESignSaveTxnResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("saveESignTxn Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("saveESignTxn Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val savePartiesResponse = response.body()

                    var status = savePartiesResponse?.status

                    lblErrorResponse.text = "AadharEKYCWithFacialPID callSavePartiesAPI, tokenId: $status"

                    if (status != null) {
                        if(status == true) {

                            val message = savePartiesResponse?.message

                            if(savePartiesResponse?.status == true) {
                                lblErrorResponse.text =
                                    "callSavePartiesAPI, status: $status\nmessage: $message"

                                ll_mainScreen.visibility = View.GONE
                                ll_success.visibility = View.VISIBLE


                                lblDetails.text = "eSign completed succesfully"
                                lblDetails.gravity = Gravity.CENTER_HORIZONTAL
                                lblDetails.textSize = 20f


                            }else{
                                lblErrorResponse.text =
                                    "eSign save failed, status: $status, message: $message"
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = "Error\n"+savePartiesResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "eSign saving failed "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {

                    val eSignXMLvalidateResponse = response.body()

                    var error = eSignXMLvalidateResponse?.message


                    if (!error.isNullOrEmpty()) {
                        lblErrorResponse.text = error
                    }else {
                        lblErrorResponse.text =
                            "eSign saving failed.\n" + getString(R.string.failed_try_again)
                    }
                    lblErrorResponse.visibility = View.VISIBLE
                    lblResponse.visibility = View.GONE

                    /*lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text =  getString(R.string.failed_try_again)+"."
                    lblErrorResponse.visibility = View.VISIBLE*/

                }
            }

            override fun onFailure(call: Call<ESignSaveTxnResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("Save Parties failed : ${t.message}")

                if(eSignSaveTxnRequestRetry == 0){
                    eSignSaveTxnRequestRetry = 1
                    callESignSaveAPI()
                }else{
                    eSignSaveTxnRequestRetry = 0
                    // Handle failure
                    lblErrorResponse.text = "eSign Save data failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                }


            }
        })

    }


    fun callESignSaveAPIForRefusal() {

        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        val regData = Gson().fromJson(applicationPreferences.getQRData(thisActivity).toString(), QRScanESignData::class.java)

        //{"sroCode":615,"bookNo":1,"documentNo":14,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":1,"name":"Putta Yashwanth","location":"GUNADALA","igrsEsign":true,"applicationId":"2506151750069689","txnid":34632042896698370}
        //{"sroCode":615,"bookNo":1,"documentNo":12,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":4,"name":"Srikanth",       "location":"GUNADALA","igrsEsign":true,"applicationId":"2506151749796923","txnid":5417699209448212}
        //{"sroCode":615,"bookNo":1,"documentNo":14,"registedYear":2025,"code":"CL-999","ec_number":1,"authmode":1,"name":"Putta Yashwanth","location":"GUNADALA","igrsEsign":true,"applicationId":"2506151750069689","txnid":34632042896698370}

        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val DOCT_NO = regData.doctNo
        val REG_YEAR = regData.regYear
        val CODE = regData.code
        val EC_NUMBER = regData.ec_number
        val AUTH_MDOE = regData.authmode
        val NAME = regData.name
        val LOCATION = regData.location
        val APP_ID = regData.applicationId
        val TXN_ID = regData.txnid


        val eSignSaveTxnRequest = ESignSaveTxnRequest(SR_CODE, BOOK_NO, DOCT_NO, REG_YEAR, CODE, EC_NUMBER,
            AUTH_MDOE, NAME, LOCATION, true, APP_ID, TXN_ID)


        // Make the saveParties call
        apiService.saveESignTxnForRefusal(eSignSaveTxnRequest).enqueue(object : Callback<ESignSaveTxnResponse> {
            override fun onResponse(
                call: Call<ESignSaveTxnResponse>,
                response: Response<ESignSaveTxnResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("saveESignTxnForRefusal Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("saveESignTxnForRefusal Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val savePartiesResponse = response.body()

                    var status = savePartiesResponse?.status

                    lblErrorResponse.text = "callESignSaveAPIForRefusal, tokenId: $status"

                    if (status != null) {
                        if(status == true) {

                            val message = savePartiesResponse?.message

                            if(savePartiesResponse?.status == true) {
                                lblErrorResponse.text =
                                    "callSavePartiesAPI, status: $status\nmessage: $message"

                                ll_mainScreen.visibility = View.GONE
                                ll_success.visibility = View.VISIBLE


                                lblDetails.text = "Refusal eSign completed succesfully"
                                lblDetails.gravity = Gravity.CENTER_HORIZONTAL
                                lblDetails.textSize = 20f


                            }else{
                                lblErrorResponse.text =
                                    "Refusal eSign save failed, status: $status, message: $message"
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = "Error\n"+savePartiesResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "Refusal eSign saving failed "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {

                    val eSignXMLvalidateResponse = response.body()

                    var error = eSignXMLvalidateResponse?.message


                    if (!error.isNullOrEmpty()) {
                        lblErrorResponse.text = error
                    }else {
                        lblErrorResponse.text =
                            "Refusal eSign saving failed.\n" + getString(R.string.failed_try_again)
                    }
                    lblErrorResponse.visibility = View.VISIBLE
                    lblResponse.visibility = View.GONE

                    /*lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text =  getString(R.string.failed_try_again)+"."
                    lblErrorResponse.visibility = View.VISIBLE*/

                }
            }

            override fun onFailure(call: Call<ESignSaveTxnResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("Save Parties failed : ${t.message}")

                if(eSignSaveTxnRequestRetry == 0){
                    eSignSaveTxnRequestRetry = 1
                    callESignSaveAPIForRefusal()
                }else{
                    eSignSaveTxnRequestRetry = 0
                    // Handle failure
                    lblErrorResponse.text = "Refusal eSign Save data failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                }


            }
        })

    }

}
