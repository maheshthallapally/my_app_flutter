package com.cardprime.eauth.activities

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.PidOptionsBuilder
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDRequest
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDResponse
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesRequest
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesResponse
import com.cardprime.eauth.utils.QRScanEKycData
import com.google.gson.Gson
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.widgets.TextViewCustom
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.random.Random
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory


class EKycProcessActivity : ParentActivity() {

    private lateinit var iv_error: ImageView
    private lateinit var lblTitle2: TextViewCustom
    private lateinit var lblResponse: TextViewCustom
    private lateinit var lblErrorResponse: TextViewCustom
    private lateinit var lblTryAgian: TextViewCustom
    private lateinit var ll_mainScreen: RelativeLayout
    private lateinit var ll_success: RelativeLayout
    private lateinit var lblSuccessMessage: TextViewCustom
    private lateinit var lblDetails: TextViewCustom
    private lateinit var lblOK: TextViewCustom
    private lateinit var myImageView: ImageView

    private lateinit var applicationPreferences: ApplicationPreferences
    private lateinit var activity: Activity

    var aadhaarData = ""
    var aadharNumber =""
    var aadharEKYCWithFacialPIDRetry = 0
    var callSavePartiesAPI = 0
    var ekyc_type: String = "ekyc"

    override fun onCreate(savedInstanceState: Bundle?) {
        applicationPreferences = ApplicationPreferences
        // Retrieve saved theme and apply
        activity = this
        Utilities.applyTheme(applicationPreferences.getThemeMode(this), activity)
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_ekyc_esign_process)

        ekyc_type = intent.getStringExtra("type").toString()

        Utilities.logI("MaheshChandraPrasad - encodeToBase64 : "+applicationPreferences.getAadharNumber(thisActivity).toString())

        aadhaarData = applicationPreferences.getAadharNumber(thisActivity).toString() //"858633410612");

        Utilities.logI("MaheshChandraPrasad - encodeToBase64aadhaarData : "+aadhaarData)

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)
        val aadharNumber = Utilities.encodeToBase64(regData.aadhar)

        Utilities.logI("MaheshChandraPrasad - encodeToBase64 : "+aadharNumber+"\n"+applicationPreferences.getAadharNumber(thisActivity).toString())

        iv_error = findViewById(R.id.iv_error)
        lblTitle2 = findViewById(R.id.lblTitle2)
        lblResponse = findViewById(R.id.lblResponse)
        lblErrorResponse = findViewById(R.id.lblErrorResponse)
        lblTryAgian = findViewById(R.id.lblTryAgian)
        ll_mainScreen =findViewById(R.id.ll_mainScreen)
        ll_success = findViewById(R.id.ll_success)
        lblSuccessMessage = findViewById(R.id.lblSuccessMessage)
        lblDetails = findViewById(R.id.lblDetails)
        lblOK = findViewById(R.id.lblOK)
        myImageView = findViewById(R.id.myImageView)

        if(ekyc_type.equals("ekyc")){
            lblTitle2.text = getText(R.string.e_kyc)
        }else{
            lblTitle2.text = getText(R.string.refusal_e_kyc)
        }

        //lblTitle2.text = thisActivity.getString(R.string.e_kyc)

        lblResponse.setOnClickListener {
            val textToCopy = lblResponse.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Copied Text", textToCopy)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
        }

        var pidDataResponse = "<PidData><CustOpts><Param name=\"txnId\" value=\"1534183822\"/><Param name=\"txnStatus\" value=\"PID_CREATED\"/><Param name=\"responseCode\" value=\"3a6e5b97-aae4-41dd-99bc-a14040018e3d\"/><Param name=\"faceRdVersionWithEnv\" value=\"1.2.0 pp\"/><Param name=\"clientComputeTime\" value=\"5774\"/><Param name=\"serverComputeTime\" value=\"64\"/><Param name=\"networkLatencyTime\" value=\"119\"/></CustOpts><Data type=\"X\">MjAyNS0wNS0yN1QxMzoxNTo0NMdQLaSBSQpNA94bSxT1m5lnWLJCKh+3IYBUZPGS0Z3WNc/AI27SeVbwK7h7qDmQH3zcRfJyQaT8h25z70NLdEteW2s4Z8pvX3VwAb6Q1ZcWrAGpZ/TkpYmQTuf1y8PyW9e7qPt7FtXSe96iiuefwX7V14Dfw3h+l0nTYT5/pEBKc/OnOSQ7Ky0WKn7mVk76MD5ZGxsOrMeB3339uscA5tIcDknSvdVmTlPNi7zyRV+gKZOJkmTkdySEA4Inxm03a5zkdGdpm4OB9Y9b+UKHTrEJZB/w7VoEAdER1gMUbZIw4Gu52T4myIRlOyq5yD4Ctytr/nvethCIyxt6msohpOkDTfInO7uB/Sx+wXL1Ln7OPqOg3FBaSktDBxdn8SFR8z5MZwtD1guFIAyqHwZ85p7lqo3axDxyG9bkLZOYc6h+mOrTmHgcxbByfFJTw9CMdwWz+IEWP3wLMgq5E7/nEYEQdN1/3AyoualWNk4qXpBs+FLc7jIVot7bvp1TCgCFO4ACEQ2/rasLSiSnnVCQku5rnJYWd1nMyT18jIEvM2DNb+LrueZYnFUqLMXS3lJ+4I4DKsb0UZt5qHi7vnEaLZALuYjRwaWAVrQBYaQkC58H6bEnc3+aKv6zDLxGPd1qBkj6p5Gj+42ZDWcxvp+ZtbN3qsFWqIOIfQOdeS7oix4BviK8A6sToswVH5PWMGycQOfxTsoGTO0gh3+ezumK7gnpEWoQFc3sVCOA1xMGO+ahhc1Z/YuFks7lkXkx+jM65Yu366SUDWvrqUKHJZtqzHMrNu9gwio9CBqsUGmm8GuDcPhp3CPoduW95izNHp/zs36QL2vn5Fl5CuwUUOCk+IZEHPir1dFECXNgi8igGhZV/UFaNiB7TTYtZbcXoevYtHBIpBc4h2BhzrJmZzXiYSRaYoaPZ0/qwM+TIQusoeVRU9SsjDzHQ8cHar251vsS1W1EYlrm7/1xz/xhxEpQVoOEUQLu/9nw4oyoUWEygTplwU8rGAtulYcztPPD5qq5/MJUsUofkhAMhAM/UZqn6uvu956+111QXnAoHIz9pUBYrcBGewatG0AVnVXAkZpEz6/AfDfjSKrPCdFCPF2hNLhveh+ikAVoeF/35/bFikPnk+Xp0SpFZBR39lPXg5YCHNredd369sv1HGlPF/CYIBfeVizbRljA2xPHRUqtcDjvgIGtb0JZ18Wu9cRay2PdNkl964lWx94luBnir1hpL4u2S8a3PUr8T+XVQtNMrHRXFnhC84pIHFa9Eg95d4y2Gz5oKERAYoTmLx9+dX4556Y55UTkg2KseDlcxsE0Eh3DD3fGf8vMLRbF998s7rFZ6q+VZq58d2UmYxD3ufUE/vKQmB3YmIE9p/x+lMILY72csEWiJwFDL25o7K5Obcm7XY8pzSUfCG+srMZCesRsroLmUdXX25i+sav8wfb7Bv8lQBtnzm0TYR6qEn2cn/Gm9B7Fw7K+3etP7FQRETlOXTYmJKln+x+4a0sVibHMDTDVhNeX3l63U3dFBC/GPUAfu4WkehagWyGenmRZrN9IKp/tt2gsuHQo7JBZrBkvDeZjl4UUY3ChGXxP9TrOiWUJnC50PLaZR/JvDDTDXknd/KpA5nnYc0aGB6PD5oRNgqPTUOFLtH1cXu4DHkJphx9iZh5Pspr4b1tZYSiLNoq6dk2vokFVUUL5KHfLuZ7hu/IF0GGdNXP2thP08SiGdOEjAygN0YhH74FlQEZSG3SNZOETnivndsv1ZQVp8YdaJwlofaMmzqmIbNSa4gyngJWxIJaozvkArvpEKxg6Xd70C/n8aTq5ZasPlq7LYJgeSxQ7GSyzvBASsl0hqcB9j8qWi+CQVeLfBBM7O62QVjKWMVMeGb07f9oTsFq543RsqSf9ZEXr8xf4ACAmlDIwDzes/YOnt9D0wd4zhr42UecZPFm1wSOSs9RyxuR3wTGvdbfGg185QiqINE/R0nJzDg22uevl/NbAQa1d+IfV3Ml1sZohO6w92CYffs0FWXi5Jxn+zA3IBe+QYy6xO0MoHqzbKat9dwvzb7DR8XvYATRKDbWV7N6qbCpKpYVslwhYq1PoBVlpcVXjjcYp4J0vsada4Lw987iOcKxOqjMzTCbOzqKWd+lkvSeInv3OSaei6XETEhn/Pp7tT7Zvo5LOWz9IK7N7Ib0vJ7JPwAmpCBv1X7mrZmByz4ccc0SL5BbItHNpVAWgdKeyurlFmD+9Krsa1Ye04OIVx1UuZrjewZuuC0jIjE6x0g2eY1tDRhn2Th8FHSpurccLMj9sQnE2Ksx9wMUPxXt4GGk+YUbBnwArZOHXSQHqNAalqFVKXWrBekyOG52lbyXZ51lZL6QSiec8T6G6IrKiSJadJMElDUUByirc6/tXqcarV4pHySf+j1viJileMUlpX+oUawA2GITRq+ZBHoYAUc+g6164f9bdK1ssLaxKzZqnoPi6wp4MIcX5szh/4XE0ntczlmAs5T1p4QmxRRi8XcH2VvaMjojOYbjsWqd4FiNkCXqz73QWqPZ2rFZiMHVhHVYLCSs1kkzsidc7J1dBveykiIpelvv/8o+V4RsTBI0OiPv7GfVWAzhtWliM0ngLtauGOrzW1q2jRJGyjohaYcR8xUmEtiWoaLTcpc8JtO1Lwi/Z7p6Z1vKDfBhDJA5iJeQxzlwkzuJe3fCgTOxfuwmGJD6i7yFWo7qxmvcpOiRy6RwsyZ8xSo8p/DBUMUO8/i7iut1SAwzs2tdyX6Xbv8hDSxEcz0s83B0Lw7DNJtN91qIke+up2xIm/XOaL4uXhMG3u/JWzs4R7RARZRkQSCQdffBJepfybF3MP3xRfAfK1MaKDA50mDHoyJ7eFWhDDWkq40UN87zZ2eCIibUiYoRPJ6UANtmJvpTsMZPubMyn6bNjv1T6KI3gcCp77KnhJMO8wpS9m5oo9ENLh36TR62JgsIn0acj4njYkk+u9o59XnpwqHCLA04Ks5GupUUu+yMSSkOcM646+HvOg3SEy7NgI6SZ/JauLXWIV4sGm5pwAHlhsVSiUwfxkF6bOJESS2OJjh9gGMXeqvquE315i/mIm2RTij1IlYi1d55XO7yjRXPX+poMpQhF0OnjQNHWtiyd416Hphkfk80pHKoGq8QHog9oox+ykwPO1Knp6QOS/w58Dh9p+VU/GEmFwIKgoViGdwjuG31HI0DAj82upkvWRtAYw2pw7rs4ry5nnyYNozzP5zx0sgtlUDUhnOpgiRaG54YmOyMh2HK6NCbZlyAuciyhe7Kp82NeSHi6YDKaov5VeHD5XM1Hw5/B2SWcwb27VqSRTWTYXeVdyBaI5G80eY4wwV54CzCcXjRARSEjSsw3dZ/fLE6wks0lETNV6fPXKvebxj2Z71PmqcvB+UFXkHUFwmfAESk0Se4Vgbuic2Zq9AIuIO8dyjvGbAmbFgbhoCg+RJag42+GcDYVJpSulNUIQEpShIwzIOtWnEvjKNP5m/Mx2L5LuHAWFaGIQKcudwONbIVFwm0Zg7++lazvb7TRVc8quUo/rJG0jgzbHmetc1R1XTk38XHnBdsjE8mzVMpGZJ7/Faki9nNgwkI5s/3OiY/ZCEeQKPo1xOEL8vd4zOsciAXNvvHgVcd0r8t2ydpjpZF2gOz6a2uMQC//hkiUe7OC8XRTULoc869GmpJTGiLCzZSK1frlHuZaqIz+YoaefJLGyL4DgqzwA5TnwlAwCDvZ2dZmxr8RewadJNlnMnv5NQ/Tj3hJAovR27AdsV3z8FwRZu3xvonyQkWkYANXf4hHntL3yVVZ9jG8StU8JDhPslKBfXyKr0OkuH5OBRt/+4hBPWC0Z7ztwIxZyTI9els+Z4lkwEp3UBH65WYAr1hZEh7KjJGjBJBgYlvEJyR5fyO86O8XZyu18wqerlo4KO+iZFGI8RDdjrVNOklo6XNGIJocdRtRj1aQVJsCFHhOrDKHk+/ObO3vvE70YkNT4X65Wz8CSWns5wyA9iCEOpE+rFEsiSgWYgPpECCl4w9KF+/H2aZtA/vtLBAQwDC4VCN1lQfOevxGc4P6pcJUeTTrLLDDg0lSV2D+jmOcf+nsiEYH4ocx/xoHVh7YdHzYdIR63hCVMGpCiPfC/mR/xNsjCVwYEZedFvT1wHaK11XGQrRprO/SyLuvsRUqWx2sNGk+wyfs4flK8og11DX03Dp1iuM5CAz5pMfI/kWDgaP00qi2RtLyP91vs41mZWkJ1LEaYwHY1JtVuGf8ailJZ/kIyv7ac5cKB1VOV5vHuYiwUixy8DDEFDhxxL0tjI7w8CnOUupP+8h1g7Nb2H/j8vLAwubZazMbtj+yXS3muBm+Cb0q8ZqqLIKm3Y0lKcuEmWWdFr1LAtAjLz8Q7GAAPvACigR4/kvjK4p4801uxxTuKVWa+kB2DSI0MQ4kjnf9X9QMAcWmMjMKPpc=</Data><DeviceInfo dc=\"6a34b4aa-2446-4e3f-864a-7ac49147afe4\" dpId=\"UIDAI.UIDAI\" mc=\"MIIDrDCCApSgAwIBAgIEFuSbaDANBgkqhkiG9w0BAQsFADCBhjEYMBYGA1UEAxMPRmFjZSBBYWRoYWFyIERQMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgRFAxGzAZBgNVBAoTElVJREFJIEZBQ0UgQUFESEFBUjESMBAGA1UEBxMJQmFuZ2Fsb3JlMRIwEAYDVQQIEwlLYXJuYXRha2ExCzAJBgNVBAYTAklOMB4XDTI1MDQyNDEyMzQwNloXDTI2MDQyMjEyMzQwNlowgYYxCzAJBgNVBAYTAklOMRIwEAYDVQQIEwlLYXJuYXRha2ExEjAQBgNVBAcTCUJhbmdhbG9yZTEbMBkGA1UEChMSVUlEQUkgRkFDRSBBQURIQUFSMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgTUMxGDAWBgNVBAMTD0ZhY2UgQWFkaGFhciBNQzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJpFoptQZ/gWaha9hBYZMp7oSYy0leES5fK2LwfDZ3whpMxyUTI4HyElmRJVaQmQgKTy/Mt4qhQMt/HhIgeAjj3SA1sutoEkYBYTiLyPHDpNCbCRYwU0oA8M2MhERy7WM5fwaA0kKFBgZcnMmgLni4V3R/I1henuoTR7bsmhNIsiy2gAAFHNzrV3D5nm/EV3C4GKli4PzBXJ9g+lTv/QpZ1+GEpfECEPQqEyqKezcl6eMJ3AeuVMs4bGopYas5xRppGhfJ6pUbMXep+YpIf5vngGYNRHmYCIkeqQjI/nYCCWzJX7bwcS+H1rkkQuFbaDpqplJVsoAwbzIJrZokTW4NsCAwEAAaMgMB4wDwYDVR0TAQH/BAUwAwEB/zALBgNVHQ8EBAMCBaAwDQYJKoZIhvcNAQELBQADggEBAF9UB5P2Jxyoy2emwabeadXAxvryrZIwyxNHYDnxpqXYK3ebiBlxoL8p36oucZhUL9c/3DpFtpEg0O6TWvAQib9aoQW/VtVYS9ymwzwHVABAWBG27HiKdpiZXgFG2dfD1Zg2RpIflkqELgMlY+eIpA1k7pC8Mb7UorUffQlupg7L5VwkjvSKVPMrtRblFeHpiqQbQEoTKk/6Tt01klTky/wQmK5fVVXxKy8uF8jRYJWqhvnhbNrynau0Tka1OariRnT489OLUNYLZJGYd1oIad4YrhsifABSoZOCTiwBUiI25DVgNsQWa3m3p5mpSKOEXl1UfTkrV3EYwVfR60RMNLY=\" mi=\"UIDAI.ONLINE\" rdsId=\"UIDAI.ONLINE.001\" rdsVer=\"1.0.0\"><Additional_Info/></DeviceInfo><Hmac>INoV1fFzrEXEh55FhZeDlVIMKjhLLTysBTqt2WU13jLzilwi42lhcZoOvw512h90</Hmac><Resp errCode=\"0\" fCount=\"0\" fType=\"0\" iCount=\"0\" iType=\"0\" nmPoints=\"0\" pCount=\"1\" pType=\"3\" qScore=\"-1\"/><Skey ci=\"20250929\">irnKudLUFlWRoRwRYpaYqMfvjtIJdeOAq5MNLhHdMCoH3y3WOAJsaqb6ggmxdjqTflYnM7l7GKX439b52oN88Yc7+Dgnb/Flm9uxk20MMu1k/eUl8mAdMQ7iOY14ebxIOZT2EjUG5bj+0cDfyK5lwa6Pf4lQIJ1Jc8Ud01IR8Rpik8MGAIn4tAAvkNBhS83Q5fa/Q5n/Cv7FUqP1NyOYRuoV3fhTlVGHNv3vD1OYazD7QL2OqAANhZ1Rj7hFQKe70olx28Z8kuwpJwNTJoJTXRZiKxqCm+kXm1xiLC7JK32+CjT1gLQ9FC9zmhx9tocsN8/3KC0KnKRdLqxX1fT8Bw==</Skey></PidData>"
        pidDataResponse = "<PidData><CustOpts><Param name=\"txnId\" value=\"2838535744\"/><Param name=\"txnStatus\" value=\"PID_CREATED\"/><Param name=\"responseCode\" value=\"b8b93cd6-1b38-45a2-b573-88bb318181f2\"/><Param name=\"faceRdVersionWithEnv\" value=\"1.2.0 pp\"/><Param name=\"clientComputeTime\" value=\"7813\"/><Param name=\"serverComputeTime\" value=\"201\"/><Param name=\"networkLatencyTime\" value=\"883\"/></CustOpts><Data type=\"X\">MjAyNS0wNS0yOVQyMDo0OToxNx7Mbh1DbKnww0rSPLuSSQK5ahR0pgnm08J0g/+obhzy93+XnwXC0rrh/oYjRRN2E+Gp8rFZXivOSkGU0ajXddW49MyYOvFd6OutnGh2yEXt0gxb1HX8/rewLI5CK3popqHq8vPhyXYCsb9WZ7EczMiBWIbCcBW+qV+9iL+kxj6GvvxwJeSA044R1oHX2Mba/dDc2+iiHAi6xJwyFNz37HMX/3T7cg4KTo4+1XCHeslcZAvpBRKsVkE6XKRy9oWJ58oy/woMRcvaD+m4il5FteTkRvkL520ihWCneMgChBYX5zpnIXuQw8X/I9epPRtgAxLylAEtDpP91izq3H8U0C0OcD5/CKHCQMJHiFU/0hvVSkFs71W7bATopch9yb1vgvBIrxBsjXOIUkQlnDI+rQG0jbAmjno8CrIm7jjT0vH4k7nLKC0/gX4tRzoZ10oOCqbo8olrhtLprbO7oFexsNoKwP+rWlwuK9aLAhs0XiEHnfHA6npdFCRXLy72+U6AeQfEIHJBS4skoruyAQ81rKUXJpcGRsmn8GIYTQFYXdH/MIZP8WlVL0W+yl2R75R3vFgxzI8ux7OVYK8+uwHs/ox/gbHKaTj275V9lfhe7X2QN+EMSeRVmlO1rq0BI+GhQKGlZMFFOaNQWdb36vRuyxKW3SrmesY9QdIVQEf8WUyZXAtlxbXhuVNXzo7xlZeOjqI9Kl1CNkAcqsdYDUGooCC47W65dLAj/MvxQXSWaUkdcFxklBZpCIgJfQQ/413EFBmJUoihpxzXr14Rw3Swlhkg0FrSTyjyoCGijaJSZNmoJTVBzwjVjzNiRvHVLDVXGA7/zsx6FwnW97hYrgtVrTn+Kc91mcfyzEPxVwX9on9A8CeEvL5qppUdGPLyo0gs97aRccdTy+kNrFhEi4vZykK0vSN5viJVoul36lkmp1AdRZtn2DTnmcipU6K11O1Oa8Ew1iYqhOWr3AR+irMULRF6ztu1eERE1aeKUpAOOOpPQP/OOyYGl1fjE5ROLMmvt7ZjsICdzD4c4fyaQWfPwkuFns58U3Twsh3kmVN25Yr762QEFR4ziNB7Eo3BJwwblWMOp7VpSyTb/xicIp1S07WQ6fOfNZeIRtURMlv5CsU0C3SS6rt+GxwGdedrAeplq2weL6c6QkaZ4NGiYKuHpJi/KJI268Cgz7kLuUrmPDsD7OZPIioUNly2Rc1GNLioxzmYqSKpha8pElzfQg15EpwovPO8x4m+PQwbCb8PwIA+rgnq9ed4frfXjcv0+pFUaskrlMoc5Q8AqZR7h2ZUtxEMJnqXWuNVINr3rpjfO7bBup2+2SkCKbdLrWSOXi0AMJ7h7yBUJUIepm92NOeHIF92RDvGdtOXTxPyGALqB2g60OclGHBHdeUZi3LAJAZp9WbMwN1xLzPEI3seBJyEGw+sp/5/XcqCWXL7XDi70EReMqTbDv7Zmon2G8UP+DwMjsZwuSsSHExUz5s4CemMUZWhEVVFaHjXu78e0uqvZ9s8RODW2w60AXhBg4WCMvb9RlYZiEvexVZ/hzVJfPtNdK2kow7asaQtl+WaoS2zsg0ed+mdBsOkXdKB5YaJnV0cElcgeIQ74EatOxT6wjpEr9OLRitwIYd8TzgiTJViJ9yUmzr1M1564f0xswRzhR22CQUhiOyMpS+0/o8fYr/HZWLysK1Csi0kAI6NwhVoKuYKmgZdWk1gzZ+y2l17++/DzqUOpbObyQLcfUjUdF6WhvbIj8EEHegr7pBmex9Cu9Wls8RTvBlb1WdjPVdJpxbPoNkVdIbSpA/xXOq6BBsIygpW8WU5Xplm1yXg1CLnbdcZ3Jgw7dd1fI9VJwNj1LRR/R0dGqtKFfBPW2LtEAAjKLrlBmWluSFMS/k5ec5ncOPq29wbrZFIPlu8c++c+Fuwg22XNOBQiRB8x1V8/GcV3aJPsY3Ri3T7fkG2JgztvErrziCmPZazBjS4XdKqt2NwgUJvgabkV1f4zSR79myzyILNgUNt54wUwhOwWTEXJ/JaRMWRWT6TahdCl88fdB73tfzWEmYE2y9hyHm7b8IG/V/EfpjMcolgoPZKu6CmPcqBpF1GDdOyzrgGYR7JheILlhNqwsCemUudfeX4ghPrhSCLe3luNjZz93PfslmhnOJuABvDqnsv3+oHkZ4B9mgeRi+yIWoFkZ1hElywdxIiGgWR8tA77tBaVu7zV+s6veQrCzyDKTcyRXeW8BEIosFjg4N3du/L/N5gNktTnCM/iKm36fLb3Ii2R0I+Qvz3+CU32HW4CxxXwmqbT8aJjq+PNi5zl5m8Jqg0zHQTTXyV2Ns8zh2e6n4hHPMEQIfTaZZ68OQCp5i6Tm35sO6U8YpOuz+PR/PFjwrYxPPRICA6e5qRnNYjL7yn93e6ppW1i+cGJDzhSIcVdAKeS77BXVMTstmihxWg5U3H+SXHhTELRtgoQ78toSKdBQNVEqZjHmRTpVVNjEMoPQplzeh/2K2OWifehalFH/yeyKNyZBpx+o+LC/gIRYtuvtIMl5dkSxYQmsXJYuTK+HyVfJFk3KndN52gO6WMIDuQONDwRaI7tkzMAP93DJw94dpIINKCpI7RP/kCej0IIl4DnqCu6lBBvs0qhHWwj3Usw5mhWowQXwOJP+c1dD3GwjJNGDTjVYCz/0i+VkHx06+NtrKJbwT+gK4KUYZVcFy5M05xrDfcLEHSpMvfBqKq0ohMO2YC8C1kbZL8voW5YaMO4RjilW/0v0oHkAGSc+iqYfJTHFrYnZRv7wQ2ubfCa0ZBjhiHKawgGxl98UF7qWESh8wvz+61/anfEyD+GpioxkHMh/EoCBHyOcyFnRuXPPb2sLUCWhZXR7TDLGnGQHmfuJqhKXqXO2yZ5A/B3BpgrEl+syCkpxjszedWznmRT6ZbPrzhVLzpFMaro69WMk5qf9kbeaHdZq0D1SAZaWR51ZLpiQRU5PakttZlTnaGYL1V7slMAV7HxHjQRLkQvgMMRhwf6Ra96d4ODAERZH8GJCZcY6/6eA9bBgDIc7+ibcYGSkF/qwC70saJ7DxA7RSSDgAIg7EDGx4ttovXIYkPJoDHdO+iemKx219ZsDvdInn1kd55pM5vSwTyMo1M9k61rBMdLw29esmm8eS3oOVsrM/iVEkH+gGTetmGGlcaaV4LPYfO0GfZomNtxDd3J1dbwWG6y3TN2Vz6mSp82Wzley2CAnwD8PeUkzwcqQzO0bVoeg/aGLB0vbNfg5Up6J6MUMZ10C2DJVUx90Tpea35efDSby0u2up5cgdLYD99YMwyTYZ6z/M5QJO4ibdgo2rTvXCqQMwVV4wTijmiLILe9q0WqSgGJyBeRNdwNCRe/Ve6o4nFQ9QDBLZ0ftWSQDWaj4cmuODFVLtXlmRsCbofOB1HChJ8WuoGNvDxPkLCoxjcC+adOJgyZGqnFnjmxS1gjRz+s/dDlutxxlY9y4Mt6ZJ+ZeMYU7uE+1CRJsQzX8ZO6NuJIFrvdFXZeZ0WSAHiQDsNBinRPdB0CZXsTRsJd9dZf1xsVQb0/768knKmKxidQsk44IgnT1sdLrNifwt+8PwinGCitMp1kwST1yimfZa0GLanV6GggnQeIDcyAtcUdHGp0DRyH8VY7vS/CXEn931TXzqyikGYk+LgK/ZeFRnxG4qJtUU32HKFxMw6JPDidhv/UN4Fm1PhtZoT2TksekcvOsPfWaK3jk0XZ5Os9DYEtuAZANaHGoqarBsGd3tiyQjwYUZs9aVwlNDdPYmwRG8Xm+n+XhxOFcDte1SkcboPHxD6PRAaYujoFiSVS82II375cVv04y89RNXAw+R5A9HP9ZZW6v/zJES4F+GVcYtTUd7dKKBF0D89uMyGgY1s9jcgFHKTT1ETKc0J66bttZo0zf0HXdP0uFANrm8W+OsTBlMuMoFpzlT9KB+r8BuS4RMeMqQllAVPjZy12JmrW1TXOt+IJxh9weHW5hxsu3BK/hJuL5rV78eY+Uvd2P9B9C8NoNvWrLjLNQTMyVvfHLLL62PaETnth21azfB2mToDFdSdRZJqox7y6bKFhhnBmdixihLhomP0Ak68tAHwwjn5DSLtR3WRUs61RDqQNTFb42zyGZPrqfF2RUpDW8g/3OYOnfKwaCV0UCSo7GpeCcwmDdjdhM1Z3FGFS7/aji+bS9pKaxcjAcF8WLBRVyzFgkSc2ZoBdRkqHLobxLPm+RfNKNo03vsUN5DlbWyq6b1esm+gB9iWLBDzPq5rQme8tYvobKpqPAM1WtmDSqRnarIBOs7ZtV7zeX9x09oPUMwxHd5jP4LzSoJGa8r/z5cSNw8l3HwJ+PnHsKewOG+xM+sP2znLlbwHC/c/DxOh6O8/jlmtGEfmeLEiC4p+4p80yaV74bYXg6xj7Ch4zQ6HH5hIiEiN2XpD91F8112FixRFiKVnOW1CJ+FTzbU=</Data><DeviceInfo dc=\"6a34b4aa-2446-4e3f-864a-7ac49147afe4\" dpId=\"UIDAI.UIDAI\" mc=\"MIIDrDCCApSgAwIBAgIEFuSbaDANBgkqhkiG9w0BAQsFADCBhjEYMBYGA1UEAxMPRmFjZSBBYWRoYWFyIERQMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgRFAxGzAZBgNVBAoTElVJREFJIEZBQ0UgQUFESEFBUjESMBAGA1UEBxMJQmFuZ2Fsb3JlMRIwEAYDVQQIEwlLYXJuYXRha2ExCzAJBgNVBAYTAklOMB4XDTI1MDQyNDEyMzQwNloXDTI2MDQyMjEyMzQwNlowgYYxCzAJBgNVBAYTAklOMRIwEAYDVQQIEwlLYXJuYXRha2ExEjAQBgNVBAcTCUJhbmdhbG9yZTEbMBkGA1UEChMSVUlEQUkgRkFDRSBBQURIQUFSMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgTUMxGDAWBgNVBAMTD0ZhY2UgQWFkaGFhciBNQzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJpFoptQZ/gWaha9hBYZMp7oSYy0leES5fK2LwfDZ3whpMxyUTI4HyElmRJVaQmQgKTy/Mt4qhQMt/HhIgeAjj3SA1sutoEkYBYTiLyPHDpNCbCRYwU0oA8M2MhERy7WM5fwaA0kKFBgZcnMmgLni4V3R/I1henuoTR7bsmhNIsiy2gAAFHNzrV3D5nm/EV3C4GKli4PzBXJ9g+lTv/QpZ1+GEpfECEPQqEyqKezcl6eMJ3AeuVMs4bGopYas5xRppGhfJ6pUbMXep+YpIf5vngGYNRHmYCIkeqQjI/nYCCWzJX7bwcS+H1rkkQuFbaDpqplJVsoAwbzIJrZokTW4NsCAwEAAaMgMB4wDwYDVR0TAQH/BAUwAwEB/zALBgNVHQ8EBAMCBaAwDQYJKoZIhvcNAQELBQADggEBAF9UB5P2Jxyoy2emwabeadXAxvryrZIwyxNHYDnxpqXYK3ebiBlxoL8p36oucZhUL9c/3DpFtpEg0O6TWvAQib9aoQW/VtVYS9ymwzwHVABAWBG27HiKdpiZXgFG2dfD1Zg2RpIflkqELgMlY+eIpA1k7pC8Mb7UorUffQlupg7L5VwkjvSKVPMrtRblFeHpiqQbQEoTKk/6Tt01klTky/wQmK5fVVXxKy8uF8jRYJWqhvnhbNrynau0Tka1OariRnT489OLUNYLZJGYd1oIad4YrhsifABSoZOCTiwBUiI25DVgNsQWa3m3p5mpSKOEXl1UfTkrV3EYwVfR60RMNLY=\" mi=\"UIDAI.ONLINE\" rdsId=\"UIDAI.ONLINE.001\" rdsVer=\"1.0.0\"><Additional_Info/></DeviceInfo><Hmac>WS49n5er1b/+0pMn5rVVrwyvv9sYQL8o/2OjRPnHSPRRqbDIFH/CV+Q5M4zHwQgk</Hmac><Resp errCode=\"0\" fCount=\"0\" fType=\"0\" iCount=\"0\" iType=\"0\" nmPoints=\"0\" pCount=\"1\" pType=\"3\" qScore=\"-1\"/><Skey ci=\"20250929\">tc0Ot8gtMxXwNJUeNwHjeBJ5848H0L/ywYlkHEEsN/5FY8m+iPMs59E7yUEq5wLpZ/F4vEuPxxpKSnj5+BOF8AafIKXnHNOlHb9pvbL1eG0rsHQ9TGP2amUO04XYHxJmax43dxkbhzHPWI/qqZ/4dkFCkpTvRZ59n7Tm+UL09iR6ozdcf73uf8P7BMrcvDna6k3a5q8pn8iBCfhfJuYTCByRc84Z71lnF1jLmByhDfEYZgUCbP+65z5xkt+X7/8TiC+4yGYYUNlcoDcmqV6s4/BBpzMK0A1kjdHS2pCV3K/y1SemUCslkFcEl/BOTIhMFC9/qwRmlt4jgvQvVwuGCw==</Skey></PidData>"
        pidDataResponse = "<PidData><CustOpts><Param name=\"txnId\" value=\"1018819209\"/><Param name=\"txnStatus\" value=\"PID_CREATED\"/><Param name=\"responseCode\" value=\"72d245e2-9e69-4e40-b9a6-8d1287d505f5\"/><Param name=\"faceRdVersionWithEnv\" value=\"1.2.0 pp\"/><Param name=\"clientComputeTime\" value=\"11080\"/><Param name=\"serverComputeTime\" value=\"54\"/><Param name=\"networkLatencyTime\" value=\"1557\"/></CustOpts><Data type=\"X\">MjAyNS0wNi0wMVQxMTo1NDo1M4H5z8RlB2BX/bb+nMhe+u+yWqZjDEXJDHzUr7AY/Q5HOayeCgeeGhT7/qJ/cfNXl4beyzutfu92H8A8HrYcpxt23OJ1sLwdws2jkNIeF5ufXikA3587M1F8ALnqzwqYN2LI6iSLXiJow2W84U1eB0Vf72PyVRyccFjUpSqTBdk1AVRwMtQjUrpIOguMfU0QMF6cRMiVJtPKvM0r4nxve2Fcj86mkfX8mN9gQSheqXwXXTmTr6K+y7McFYOlO6y/cdGVtvb6ZtshCjupY5/zwKQXn6YENfj6V3TGf77JDAjsuXvREsuy6jvLq2n1t4vfa/vzDGDOLkciyx9L8uNVbgXMrkufgRU/WgFGS//BHhk8kQDi8411d+OYXXBP9+5MWBtGHa3hgwYqSldW2no3y7/s3bQKzwEInxQKSY2ojtWUVOqhB2i7/k52+mwPx5diA61WE1tIog0f5p9s3ihs23uozNrfR2j2A9/b3ipfDDLPznMloin1ya3KtvxrkQSBs/oAD0NRRVVltsV3QoIpxNzPb8nNw9ccYaWndpH5fiNSd82X22eHl7rCVVAgIB0Q21zPDtVW21tNP0Hymz6aKEKWbXVtj6ZYKqx/BP7p6tewJtmgtrR4WcqSVreXu95YDqFJOwP0mQ1U/aL0LUvG9sq6zRvVHbZmP/peOkHG+gU02USeFiIYMVMdaU1swj0RRrAEQgtIhvWFdCsa7cTc6X6FzTQ6b4IM27pFGr2wV3yfR5Xznh21p64q1565xqENLLDyDyr7ex/uEsQpQLoQ3EHcZ+lPITABU4kvwUgU5FqVF9COsFwcMQgI0hPNlkd6+KOsijKxVtLmuE7SKjYPVwdATsi2sKjd2bNvtKLMtrnkDqSrpbPpTCx1HAnZ7FUTgoYpBwarITjCcWU2wcEeLSgs3DUUJJ9CFrCfEpxn4CgGmlrpAEN/ZVcdhzK/e9O/UeRzPrNnJQl0BAioYkNJhO+iNXEL6Hqg5sVo7t/hFmdZ2BuopVAT1WI/OaLCFLZinUB5Z6q+5rfyajkD2hASN7lrCgf41QeFobLk7/MY+eEMPy7n1u66VHhjvURGh/loXcn+0gFBtqR1AtrzXbu50EVaX2ZJvm/3SfRy3gWyp1fpLaOpCTaq8Hv1dd0/hoDoURcEDeHyucQB70GqEziTdDY7s6mAbRNNv/Y6XhUXA0vPqTfqw+lq7GQ/rBATbOoGljPwYneHkoJ95DfgFNyy1X1bdBQHRZAsZ3DFVHgG+mm3m3ZZUxi1/ypzS0i/YW8EG2jZKXzQ1BiKfdaEhe8l+HKFjW1pH9UzIgUayQs8mrzqXMiwRs0JeiNzfYTfCWeA1ncrPpswxgTL2FPVZxCPa1s/1ygZ5xnsY+7GRJu3ICaWMlRHweVK3/KbToP1DW7vW1arcG2Mdy2CLuc2Ybc8sISW6cbUKarpKniUAdiSwk6Js6L4R7WHYikXAoej8KkExcvqMwhU5u71sx2Vn0j5+9P2BDlbchSSLqCfEQIkm5ExkRE0x2rVACMyx72EW71OVi+VsGOt7hdU1XyxcKAoezAWtL1/W5t13jNC74atgXpbAkMC6xpcO2q7ETrT9t+JSkohwgq2isMTF4iTrknZkoR8l2kWWHidOdTKaKWp+6xP6FkauvB5m9MM9Vz9Y/MwtGKs+1m3decTUZhAXYIpgBVEtj8YrbTTMbG9yUKccU/bHS5dqCZeKoe/X8knlFQgRMrp1kLN9VVaVvmykzrbsZ+o6vUb+OyLb2SpA0qZQ3JRgfkjSdAiZCZknI9YESWk/Pu3uDXZ4PwzSGmoHA8aCIEtsyKFUWFjmpDQrQv7lljNWClwu3uXNYczlTLYTUVkCpMDHW/xuPESOriZWGeo5KbdZtedVpRWnojG+JNGWP3Mq52BWK5Uvpmamjf4DFoK1+3VkWXnEYCBqnxba/Mk2eCJXjKyDDkdivXaX5wDH9tlpQKhCiBj9tsQ1RPC87UjMEO58Clrnnsidr6TwneNkhHpx1XC47t6zxCjDwwxHFJj3jYQdVBQJYaZd6omdgNNxU3Tf9+HKTT0cMZLkY+dbWE5O/iTR3CDDAhp9l+Umqbqh4oCYI9oHQLW4oBtCirPQGChvk24A14R3d0MxcN1wyWXOv1/zqr32BJYwWoynXUUTsLHSpwjsZzlUZXcPCDB4lgxdvcqcskFk82m4TvMhfk/R8lxztQNYfHm+q7isWwrR0nEzxYnOo580JSst6LXEtoF/3bfBY9XtiBBUCVhD7zodhlH98nB0YGcoXhg2jX8RFL276iRtnqA+4TCH48UZm1UAkVGXoQyMrXYSNHuV5/ZsTxlP3U2l2kuVoZzw8ECaED9DccLuRkDFzKteWEk36su1cW4Hm8+Ozm3Z7IRGbgEbEjYg8ZdDWxxHA8gkBM4OPZdxPj3tUsWwnwMmSS0G85/Q8H1XcMuAog/x4+vOGl+55HGrKctKVrtCzHU2uWdtxfikyLEV8m/CrydGPQaKEq7OFvHMLvLB3EqNDctc5YC8ZmoX0Wjf+D5qAoRqmm2eGjNyROW0/hJKVaSUI3kLpCJvS5hNH2+RA4k2yvyKoRAbxJ8/8ZrPBsNAMJkfaViwqWjRjeem3PN3mrv2E8YqUWYd44LsSTEKSAkF+UVnV1b4tTdpRKadwIhFcCVB4lE7VmqHZCCWWAIJuqIIPSOxd3dM6LzMvRKx/X2R0VP5DBvAl++P8p3uARa5ZD6c60FaK0uHjeNQhoZVNHhmH/eKATSuk3Fo9/3KUqhWdkcZpKa1FPms5Li9ps0//++jIrbd8PJMwt7WjmJLbXPigW/g1purvYytVtOlRu1wFzKDxrsVf2NXYHpIDP2qUIP3Bzm7vOYg7jVLZvVufugfWfqtij+hTAF4nn5z069FRJ4aC8gOAwxg94pRHFmKpYK7ixOgWZgktcjy1nRjJF5eaP43W/WFjf6zOw+vmRhGrTDT+PsghRIcfP6EPnSOh/DUlbxD0MwGtcIX2/Ca27VUdf0df2B6tYCUblTPRnsTD8jGxJdXIiUOB2bqTRey6AN558/vAGeIh0HafXCX3Ge0zDGRzOq9DVeldATSW49P/lYft7LEeDGK8iZEVWmXAOm5GJemC4JegUqf8YNwaZdu55QY/G/zseHOLXA56D1Tkt5pnIyYs2pWiWvkZN411C0YQjuV+nzULlYU8dK9oxbDmaFycHaApDelJQ2QUHN+8XI4QH47qU0XR9jdlud6Bu8AP+aD9pSlmkwGyRaX/79j/bfTC9Wo5mE9rQy+hCW4wHvTeT+H0Qzydpq8/kYbh5uVJNUi6bcHa7MRCzsIh9qdBALQY9JJ95jMtVdLMjIXecg7t2KddQORHsoXfofEXKYu5gHYudjYphZjI72SwdQLGCV5m5k6y7ma4jQ2MqdgPG3rUOuzrzQ9udxfmOh7hDiGIwH/8T7Ir+RWaWaAm99zPNvTPRwVwX49u9cdCmJbyV5SpwgqnSXcxzxYi1rPzoy6KwxIpOJQuuloz6VTo0WZqVkmrII7OsyHeDOSN5gd9C9dFa4roS2Z7NQsOMJ5sgapQtwo/P/6kkrg1BdwI7j9BO+RRJBhvDrv3S0h2AbfxrxoAYZG2C749tNi7iDjIIQwJlHjGehCRsBwEmjvxqwZ8tQ2eARytTOSQyerB0VeB5Oc74xpu+0O8trhFw9fFl1K6dK8UPrRan72a/bbvr7rDk8xhsMZz5aGOw7PumMebyAreH0vwlpbghtgj0IuAgSv8PPMxhqQc4fh5Dm/FJ4HRAu89OldO/8c+o+kTPjCpJpqmM+LT4TMtLJQzEC3dW9tLJTkEA3kyUh4Mj7uS08F0winSSJ8j4Isa0eKa0mNaxe0O/LAQ9hDNa5cFlTbsCuSkaTgNluo8Wo4q6nI0v8ItQ3dZ/GTnTMdraHNFQUlhWCmyp/bxHQu2++yvnxZ529qzVALzYL1WLIMyeNij0BlysrT+ytXBEASfxYcyOlSS5NgnrVMx3XK2nEi8AndZ6MBYwBwRbzenSuJMH9V57yMJpKo3NvCHM025H4Ah4Hp07F7Cgma+WkEtqGBCkiA7njUtqM9bF4PtMXBmRfH9a/IrWxa13Q3k7WcPKD0A7GDlawXcW6sfM66m4AHdmOJPDJkHmuBnhlBq6wa/eW1HlI2xeh2HqBn7u8yGeX4clvE4QPeS607OUE7yHVVcXTEICOTTl6ko5UyD4/ihur/Qr4FB9Sh2iogbRkxTmppBLU542203rq/SyxmBnZyyeTXhOhlQzwbN1604ZOxVP90xD96h33zcYBINKE7pgHRpuJ740zump8RIqwb8gSkfbp1Kerh3LuMY6jyjI7rr53l5D0RJhR97hT/Rj+5y/UxbwTd8f1pi6lUKt5jY5hMmLXuIEXClG4gvLcU+oqL9Eu0NgVfq+yEPT0ywL9Slb9prmAn/CZHfOW7ltfjdw=</Data><DeviceInfo dc=\"6a34b4aa-2446-4e3f-864a-7ac49147afe4\" dpId=\"UIDAI.UIDAI\" mc=\"MIIDrDCCApSgAwIBAgIEFuSbaDANBgkqhkiG9w0BAQsFADCBhjEYMBYGA1UEAxMPRmFjZSBBYWRoYWFyIERQMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgRFAxGzAZBgNVBAoTElVJREFJIEZBQ0UgQUFESEFBUjESMBAGA1UEBxMJQmFuZ2Fsb3JlMRIwEAYDVQQIEwlLYXJuYXRha2ExCzAJBgNVBAYTAklOMB4XDTI1MDQyNDEyMzQwNloXDTI2MDQyMjEyMzQwNlowgYYxCzAJBgNVBAYTAklOMRIwEAYDVQQIEwlLYXJuYXRha2ExEjAQBgNVBAcTCUJhbmdhbG9yZTEbMBkGA1UEChMSVUlEQUkgRkFDRSBBQURIQUFSMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgTUMxGDAWBgNVBAMTD0ZhY2UgQWFkaGFhciBNQzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJpFoptQZ/gWaha9hBYZMp7oSYy0leES5fK2LwfDZ3whpMxyUTI4HyElmRJVaQmQgKTy/Mt4qhQMt/HhIgeAjj3SA1sutoEkYBYTiLyPHDpNCbCRYwU0oA8M2MhERy7WM5fwaA0kKFBgZcnMmgLni4V3R/I1henuoTR7bsmhNIsiy2gAAFHNzrV3D5nm/EV3C4GKli4PzBXJ9g+lTv/QpZ1+GEpfECEPQqEyqKezcl6eMJ3AeuVMs4bGopYas5xRppGhfJ6pUbMXep+YpIf5vngGYNRHmYCIkeqQjI/nYCCWzJX7bwcS+H1rkkQuFbaDpqplJVsoAwbzIJrZokTW4NsCAwEAAaMgMB4wDwYDVR0TAQH/BAUwAwEB/zALBgNVHQ8EBAMCBaAwDQYJKoZIhvcNAQELBQADggEBAF9UB5P2Jxyoy2emwabeadXAxvryrZIwyxNHYDnxpqXYK3ebiBlxoL8p36oucZhUL9c/3DpFtpEg0O6TWvAQib9aoQW/VtVYS9ymwzwHVABAWBG27HiKdpiZXgFG2dfD1Zg2RpIflkqELgMlY+eIpA1k7pC8Mb7UorUffQlupg7L5VwkjvSKVPMrtRblFeHpiqQbQEoTKk/6Tt01klTky/wQmK5fVVXxKy8uF8jRYJWqhvnhbNrynau0Tka1OariRnT489OLUNYLZJGYd1oIad4YrhsifABSoZOCTiwBUiI25DVgNsQWa3m3p5mpSKOEXl1UfTkrV3EYwVfR60RMNLY=\" mi=\"UIDAI.ONLINE\" rdsId=\"UIDAI.ONLINE.001\" rdsVer=\"1.0.0\"><Additional_Info/></DeviceInfo><Hmac>OwUU0JwAAjF2GQIilGMSNLtRvyRnhQgRcDTIkbXn7dUUUPcLLYpZpbbZ5uh+VJ9A</Hmac><Resp errCode=\"0\" fCount=\"0\" fType=\"0\" iCount=\"0\" iType=\"0\" nmPoints=\"0\" pCount=\"1\" pType=\"3\" qScore=\"-1\"/><Skey ci=\"20250929\">T+7loCUWPXbcyE/tpGgeyTwWDn9h/jf6C7T9GduG5TRVPSxLEF25luhUQ0g+iisucXp6akUGiEW7kB1qub9j2ru850eNGgxxbQw9ANpGlpXMsNCOu3sn5DFljfGdqFvEb9dMhQIUXXo801MNSBcngvxw2FjRY2fB0keJQMdmBIBmkm8l8JjHU9zQgXiaKSMzMyVRKlOhc9CuslH9gxZRwGginF7RRkvV1B4AUQLyv8ZFoCi0v368fHNUHbOklJsAuIX1F4b2Aw9MCtNRhj6R/ACSHcoNBBAG7F0FzwytZ/I1K2cudlNCXsZIEgNDAxw3Rc8Jc0l3NWYrSX4e6WnkEQ==</Skey></PidData>";
        pidDataResponse = "<PidData><CustOpts><Param name=\"txnId\" value=\"7278044880\"/><Param name=\"txnStatus\" value=\"PID_CREATED\"/><Param name=\"responseCode\" value=\"2e4baf2e-8a03-40d9-9b13-e594609ecb95\"/><Param name=\"faceRdVersionWithEnv\" value=\"1.2.0 pp\"/><Param name=\"clientComputeTime\" value=\"9074\"/><Param name=\"serverComputeTime\" value=\"189\"/><Param name=\"networkLatencyTime\" value=\"3539\"/></CustOpts><Data type=\"X\">MjAyNS0wNi0wM1QxODowNDowOLk+j29nfcT5NM3MJAmGr08+5YRSwXVTm9kis0SeN9EfODoFObhVy0HNbuL+3O2UyAKiAy/s7fj5Zgt5R+4SABHOqZ1rBKcFSlsxnSJhN4tV0TT12mTCEHnFZZMT46Yf85No/WV18cIKImA7SpuT6PIaf47mnjJCFuBSkg0XgXXQvfTwFIi/IAsY6YFds1R+pqerccfaDqmUDD+emCrAUjG4JpaNSq6yhZtgUOVRhxMtuYaQK+V7kIW+13Or9iE7UIuSD0yu4rtVg8lO7RnSoDvy/nqOJtjH2XfRj9qe5Ztk4GxDSpzO72ToQYgTMF1wosG3YxRqIMkcxl4txDdDN20RHYNdQ6jaEW9VnNYdM9QLxDzJIudA6LRCcP073/nrsOSC2pM+DqjewqcH2FCxFOemiFmj59QshKRmuY/LR/yzcsOvTysh2SPt+LjgCfw76OiYkgcbQlXHa0G03kQCg0a7viUQa+ngA0zKNYqGRhFO5zmbDczNASnf44DcXEhZuezcArRghAU7CJssmN4Jrk9R2vyS8Mqy0mFS7sThgxGxB1KancgWfMU4ssjYYACQY3EUoIG9g8O2sMo/hk16BLex0eipSgO7SZP/rDEysC79zOUMfeERp31BVnuWmsYRZKK3Ysy+p2z6Of6xAuGwEEQbrUS4U70IuyQ/snyfPJWl+VQ6hML7jR6RvDQdj5d2rpQcGKP5VMPk9i5O3JV9x/HczP87ixneXhq8Hp+BNtgy9KDh821c0mtLHsUqBDdfU7ITqF04CB3Dh6QbI7BWXFzcShCdOAvOzmJaUZWQuXAGaH4RPTPwyAGW0Gzdrb7+GgLwwU104M10olbZYQJJNt6qzxJetWfDSU7K9v3SRrvyEhueCxnruHomd2zDywIHQTvXBf/x9R5rBBDM2ZTY/ndB3UMFx6AzSdOKCWEA/2OiA0DwreHSeRzJlA9snLzjgbmMCgDSg3aOrFmzeaq/HyNHGYImFY7F4Y2ywt1f86farB6oHX5zfhvmLDO/03oN+YPNgMgcRBgan6SovgaR0HjkOM/dD0Guga8RarLWbithZFQR2L0xOEG1La1XxC9OMCj+73ByVp3Xp0wPpxpMaP9x9fe0CpN/YlDxbwOyZfIPbdMv3UehcTXUiXG4XO3vj9VnshQI7npY06Yj2wZw7Km1mHaYgsB/XQJaa5NOYGbtG850vNd62922kxNx2880FpxwBVmYAChsj6tlhM8t5orwEEVXBvb/wPSxIGvweVHhmJPNfvJV5V29DyaYh65/Uvc9cv2wPnBWRHwU4CcVBwznfJfdYFT0tJNkQfdfoqZK3VSjTkobDF+PUqgRLPQhGARCkv3gBbMR6NR3nzHSI8BkNxM6tAyqGusk9yYu37GSndEa2uPHgxtpt93hYv7X061hWcPWY5SQDWjkxq+zKwg0B1oVCStgqNGyv/PG3lu2X8om6VASl1k8p7+EBThG2nWqaFFP6GmK9OQGnaQf0PUt3FolegiLdSJi+8QRLMRisa3nQGWhPmZmNTb3c0LabpON3O2m4tJqtO+hNvdNqzz+w8fO68IeOdlXg960sJFiBde8YEqQ9ouyRs0ERytxVQ+1OjG25G3/kGyGXxJAFBTdFAd9OayG+5I4rLqNMlU48i1wSliXPVhIcB4lxHTdQqsMnPkCNEBZnNmXEQBhjXrggdXcdym2OLZmBabcWjkBfa5mqaAj5K8MCs89E9gmZxUCM53vT7stNUGJNGM70mT7/o6UG8lYQKz2CXaKpoQ/3T/c2SjfshvuDIWJQCZfBaOaonLvjh5MjVWSD5TPkCXTHM8hmSzzTL0L+og70nsaWjznujnPlpjT87UFZjsMj1a9rfqd3ceKA/7Li5yaF5HVuMq/TQCElhQ3JqfhdlZkmr+UdQ/XEorehY2O/6MiE6R6AFvWBPukVcgZcPQ6B+Rhl1agZAZ1IKlwGmOXe0R9STFOttw8ydEpQTSWYx9HAEXwwM0bju0cyOsXvUUU54ZPjAtFmy2YEFvno0yHvE363zx18zZ7v6SRm2CtiQ8hCpLY4dX5L+QbkUUCRRRiu3ydL7Xgv5uTxz5EZS26oCf+mSZ/MdjNqHJT1K/lWon/MorB7ubjMW8lk66wtndpI4ZZGWU29LLxGJBxQWSaAX5lHCgT7vgrKDTHlBUornQz2+ITXzCP85fyrPBR3xk7bBLlUOF2vs51EHxUw+z9Ip5XYRNtDe6MUQMvVMRKrt451ZTWxtP2buMfpmiLtiUH50aNC8QracRJmf5rMJWe6ku9R9vXK903svYgJ3L5Q3/jWTwEMWkXCu97sMoYE5hsioqDYtqQ3pRYte4XC61A6VPWj9DWq6a89DzmErTVNVsN3FimkUmR4OnjH3udqTLiTNeAzkbQLLJXSJNrSeEaCHOEs8Ln+/EZZXNlaQSDRwv6GTzS7puw09LvgYXJ59ol9DY5ymsXW7b/+E3uwarWttz8zEe0GGwrqlvuNTz+OLdoOsW8tO9W0Hm3n+CakON9RAF2zNLtf8XHA+CrayvafPj+/T9Qg2WQ9xQckGDTNvCrqqZA0BRTqahHl3ZygjowgDldD0w8bnR38BV/nm6beY4INJs0ltl9nEABBjJWTVSTx+bocVCOQ6WN5/MbfB6Od5VCIxmar/sX79VArshzViyXDkOgqyuZJD3YfmNOkg1bIpDBhrPmrwJp8Y7na1ilNso2J57rGojkqxhYAzcU1W4BxP90AmtplpTdB+WKIbWTGJXKKsRR0Uk6ADw3InWLDJrTIXxvXaVznrfbs+k65iedpCr1DhKpNx8iX74RZLPasRXR5vc6a89ceIh5qorBF3qEDjKi58VU5oc/4GBw1GcGbmgS1ETGxMm1FIVLHpggsyVYmdt/HtV9myc1TLdZsSW12QQzo7ZtXI1YeTQq6NPM4EFP2LhMpCFLdGjWp8/j9DTQslBQel+h4RTSYT/DBI3fVMyniAXNu3hGtUWBUnyzZuFRNt+k1wosjjOrrkJLFAWNr25+4tPrxssbrI/BI6lYq6gFuk2GV9wuZ/8uqH1uIBy+2J9SI1097m/6WBsQfjzzOxwoOPsDZII5k0SDasBKk8Y/rgoMARQAvhggepyafVA6IRSXXsoOG9QU/gKA5XRl+AANMHVyhZGT5bxMpINbZ7nkQbZKDAbwumFLeLvkJdIW5uWtyvwLCYRWwysa+B1H0qjjUvNsyYcRrUet9LQGhzpnioqbw2TQ46zTVCE8P6Yb6PWKY1VzayQ7nigVPeLHgqG0sU/6zISIwTjgycnbVJjOknyTT2wt6kj/EN99rYe+j74an2VHujue1/RIAuhGAtZ2tTkToTetTnn8fJVbHhu8bUaalu6LdicUUwA34DdMZxp3miha+wEAh2hNGi816XOIszL/M+i9rxa6v77GNAbjrTyNRCz5dgYpjjU8y1r4+a3eaTuUVM/94MtIYM/coFbyKadvODSpa+SFpSzREQG6jqG54cPWDMTP75zUZAvHVn0ju2PH3IF6wjj0XH3I4eUWRa/GvWq0EbpFQSVU84SQU4siyMreN4uOTr8meZ0SsU2bNiXBG+GMuHUXs7SjNACXfjILZG21QXXrKF2MUio8pP+/UqHsoECdiekxvFzGXBUnIzSUpsyi5tsfzQH8dF3gp3KaKiyMF8nwyAjUGURgLa2m2Zwiu9etj7i1TazvJRj0GTdieAeeB/9+AWV7thuEg57JxmJj7bP4GJZ1WqCDcQfQdU7/5KdNbeacTWx0YA3bsGMhnsgsjC+kmWRHJCSp0qeLDg57xf6ix9cIdQLVjg+VcJ18wgj/aDh84+0R3da9+u7kdUDhU+p1oe0MBuhx3nfp5xNSuPczDLybvGPHmXOR3Ut0WS/Arbr7TBVNgCGySr+d0J/RJOS4MOOxrI0qmja/HySU96+cROKY7t87NWyU/W45Z7esCjSpUCPTjDcq/HNSvuesnWq2nNGZeCjOwa9AwEZ+eDd6bRk9i5jUvc/mBrDbJuV7NnD8CRj54GFHP5jTRSVqk6op766783jLx5kHSCVqamwPpr8u+l5ylDjt7nLDdbEmV10KO5CSiM4jT+TYH6sJGzgPpqbwENxpYUuClFxi27QKjoRZ5ukvrwecHcz/ROI6t1m4/2hZdqIEA5W/aAFET3jaheNndjOr4VGIOAyLXB5/aI+mjUNrAFriu1HBrrl6DzYsMjhw4eFMrXDmAQZoRHtjCmkQ+51aaAhR5r5NHEFm4dXGIjKhZNR6oAtbHNdPtXDtN1MxD3OjAHIhL4yqHhbHa5N10MrSYJzQyu+CWiHP4dYHiYUIIBbqocLGIm1fqfzJ/hjIF81ACahBcE32rOFbU0mHcIj7kFuQDDgCjvA2UXsK88N+vB48GR16zGhklJ1oVgaOO/oLMwXrQXgh/TdJNOQnOi9afm0qwm7Z3egY+zznyEJlr3biH2pR968Y3wUjdcAdxbjhFY+hH4XBDrd5b+lTgRXx1eTRiIj8WLTuywXo9Q==</Data><DeviceInfo dc=\"6a34b4aa-2446-4e3f-864a-7ac49147afe4\" dpId=\"UIDAI.UIDAI\" mc=\"MIIDrDCCApSgAwIBAgIEFuSbaDANBgkqhkiG9w0BAQsFADCBhjEYMBYGA1UEAxMPRmFjZSBBYWRoYWFyIERQMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgRFAxGzAZBgNVBAoTElVJREFJIEZBQ0UgQUFESEFBUjESMBAGA1UEBxMJQmFuZ2Fsb3JlMRIwEAYDVQQIEwlLYXJuYXRha2ExCzAJBgNVBAYTAklOMB4XDTI1MDQyNDEyMzQwNloXDTI2MDQyMjEyMzQwNlowgYYxCzAJBgNVBAYTAklOMRIwEAYDVQQIEwlLYXJuYXRha2ExEjAQBgNVBAcTCUJhbmdhbG9yZTEbMBkGA1UEChMSVUlEQUkgRkFDRSBBQURIQUFSMRgwFgYDVQQLEw9GYWNlIEFhZGhhYXIgTUMxGDAWBgNVBAMTD0ZhY2UgQWFkaGFhciBNQzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJpFoptQZ/gWaha9hBYZMp7oSYy0leES5fK2LwfDZ3whpMxyUTI4HyElmRJVaQmQgKTy/Mt4qhQMt/HhIgeAjj3SA1sutoEkYBYTiLyPHDpNCbCRYwU0oA8M2MhERy7WM5fwaA0kKFBgZcnMmgLni4V3R/I1henuoTR7bsmhNIsiy2gAAFHNzrV3D5nm/EV3C4GKli4PzBXJ9g+lTv/QpZ1+GEpfECEPQqEyqKezcl6eMJ3AeuVMs4bGopYas5xRppGhfJ6pUbMXep+YpIf5vngGYNRHmYCIkeqQjI/nYCCWzJX7bwcS+H1rkkQuFbaDpqplJVsoAwbzIJrZokTW4NsCAwEAAaMgMB4wDwYDVR0TAQH/BAUwAwEB/zALBgNVHQ8EBAMCBaAwDQYJKoZIhvcNAQELBQADggEBAF9UB5P2Jxyoy2emwabeadXAxvryrZIwyxNHYDnxpqXYK3ebiBlxoL8p36oucZhUL9c/3DpFtpEg0O6TWvAQib9aoQW/VtVYS9ymwzwHVABAWBG27HiKdpiZXgFG2dfD1Zg2RpIflkqELgMlY+eIpA1k7pC8Mb7UorUffQlupg7L5VwkjvSKVPMrtRblFeHpiqQbQEoTKk/6Tt01klTky/wQmK5fVVXxKy8uF8jRYJWqhvnhbNrynau0Tka1OariRnT489OLUNYLZJGYd1oIad4YrhsifABSoZOCTiwBUiI25DVgNsQWa3m3p5mpSKOEXl1UfTkrV3EYwVfR60RMNLY=\" mi=\"UIDAI.ONLINE\" rdsId=\"UIDAI.ONLINE.001\" rdsVer=\"1.0.0\"><Additional_Info/></DeviceInfo><Hmac>L1xsxXrB7dkUhF28DjkMlWSDybX33q3y0qA0/iqnNCZ8eTjCIJ6AeQj6byBFzznR</Hmac><Resp errCode=\"0\" fCount=\"0\" fType=\"0\" iCount=\"0\" iType=\"0\" nmPoints=\"0\" pCount=\"1\" pType=\"3\" qScore=\"-1\"/><Skey ci=\"20250929\">aKRJGf7oT4bT98fykd0ZE4j2qcJflbNstLwKsQzuiVVdZKAbd4soqIFW6+u2yOVeW8jTYzK/2o33L1+N7eJwmYV5TGTpGJk3npTRBet6d6VFhALMXZ7I6dR9YWVjdrlG9BnBmmq0ePFeaRY4rRpWH+nPZ0rWUFNq8ln86TuhWvM6dHNaicw+A0AhOOFFnbtvnvpWCDbDb761xw3n1SdNcj3JnHVXniezw1whbuooVLfRa73h4RDY3enNaMm+3TfevnuBwOqivxaHHSFj8yaRhm2RHdTZDjY1oI/9aYIFajDHeSi0sK80F/kDf78LNpivxekjcG0NtwNbVrohsSvxIA==</Skey></PidData>"

        //callAPI(pidDataResponse)

        openFaceScan()

        lblTryAgian.setOnClickListener(){
            lblErrorResponse.text = ""
            iv_error.visibility = View.GONE
            lblResponse.visibility = View.GONE
            lblTryAgian.visibility = View.GONE
            openFaceScan()
        }

        lblOK.setOnClickListener(){
            finish()
        }

    }

    fun openFaceScan(){
        val pidOptions = PidOptionsBuilder.build(generateRandomTenDigitNumber().toString(), "IURPC-BUQUO-NXCOW-TPOPI", "https://callback.url", "jwt-token")
        val intent = Intent("in.gov.uidai.rdservice.face.CAPTURE")
        intent.putExtra("request", pidOptions)
        startActivityForResult(intent, 101)
    }


    fun generateRandomTenDigitNumber(): Long {
        return Random.nextLong(1_000_000_000L, 10_000_000_000L)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        var print_data = "requestCode "+requestCode;
        var pidDataResponse = "";
        if (requestCode == 101 && resultCode == RESULT_OK) {
            print_data = print_data + "\nresultCode "+resultCode;
            val pidData = data?.getStringExtra("PidData")
            print_data = print_data + "\npidData "+pidData;

            val pidXml = data?.getStringExtra("PID_DATA")
            Log.i("mahesh", "maheshchandraprasad pidXml: "+pidXml);

            print_data = print_data + "\npidXml "+pidXml;

            val extras = data?.extras
            if (extras != null) {
                for (key in extras.keySet()) {
                    val value = extras.get(key)
                    print_data += "\n$key : $value"
                    pidDataResponse = "$value"
                }
            } else {
                print_data += "\nNo extras found in intent data"
            }

            if(pidDataResponse.contains("errCode") || pidDataResponse.contains("errInfo")){

                val error = parsePidDataError(pidDataResponse)
                Utilities.logI("Error Code: ${error?.errCode}, Info: ${error?.errInfo}")

                if(error?.errCode != "0") {
                    print_data = "Error Code: (${error?.errCode})\nInfo: ${error?.errInfo}"
                    iv_error.visibility = View.VISIBLE
                    lblResponse.visibility = View.VISIBLE
                    lblResponse.text = print_data
                    lblTryAgian.visibility = View.VISIBLE
                }else{
                    lblResponse.text = ""
                    callAPI(pidDataResponse)
                }
            }else {
                lblResponse.text = ""
                callAPI(pidDataResponse)
            }
            Log.i("mahesh", "maheshchandraprasad "+lblResponse.text);
        }else{
            iv_error.visibility = View.VISIBLE
            lblResponse.visibility = View.VISIBLE
            lblResponse.text = "Failed to open the e-KYC"
            lblTryAgian.visibility = View.VISIBLE
        }

        Log.i("mahesh", "maheshchandraprasadt "+pidDataResponse);
//        lblResponse.text = print_data

    }


    fun callAPI(pidDataResponse: String){
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)
        val aadharNumber = Utilities.encodeToBase64(regData.aadhar)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_aadhar))
        val aadharEKYCWithFacialPIDrequest = AadharEKYCWithFacialPIDRequest(aadharNumber, pidDataResponse)


        // Make the AadharEKYCWithFacialPID call
        apiService.aadharEKYCWithFacialPID(aadharEKYCWithFacialPIDrequest).enqueue(object : Callback<AadharEKYCWithFacialPIDResponse> {
            override fun onResponse(
                call: Call<AadharEKYCWithFacialPIDResponse>,
                response: Response<AadharEKYCWithFacialPIDResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("aadharEKYCWithFacialPID Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("aadharEKYCWithFacialPID Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful AadharEKYCWithFacialPID
                    val aadharEKYCWithFacialPIDResponse = response.body()

                    var status = aadharEKYCWithFacialPIDResponse?.status

                    if (status != null) {
                        if(status.lowercase().contains("success")) {

                            val token = aadharEKYCWithFacialPIDResponse?.reference
                            val tokenId =
                                aadharEKYCWithFacialPIDResponse?.userInfo?.name + "  " + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf
                            Utilities.logI("AadharEKYCWithFacialPID successful, tokenId: $tokenId, token: $token")


                            var display = aadharEKYCWithFacialPIDResponse?.message + "\n\n" +
                                    "Transaction Number :" + aadharEKYCWithFacialPIDResponse?.transactionNumber + "\n\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.name + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.landmark + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.location + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.district + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.state + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.country

                            lblErrorResponse.text = display

                            if(ekyc_type.equals("ekyc")) {
                                callSavePartiesAPI(aadharEKYCWithFacialPIDResponse)
                            }else{
                                callSavePartiesAPIForRefusal(aadharEKYCWithFacialPIDResponse)
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = aadharEKYCWithFacialPIDResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "AadharEKYCWithFacialPID "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {
                    lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text = getString(R.string.failed_try_again)
                    lblErrorResponse.visibility = View.VISIBLE

                }
            }

            override fun onFailure(call: Call<AadharEKYCWithFacialPIDResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("AadharEKYCWithFacialPID failed: ${t.message}")

                if(aadharEKYCWithFacialPIDRetry == 0){
                    aadharEKYCWithFacialPIDRetry = 1
                    callAPI(pidDataResponse)
                }else {
                    aadharEKYCWithFacialPIDRetry = 0;
                    // Handle failure
                    lblErrorResponse.text = "AadharEKYCWithFacialPID failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                }
            }
        })

    }

    data class PidResponseError(val errCode: String, val errInfo: String)

    fun parsePidDataError(xml: String): PidResponseError? {
        try {
            val factory = XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true
            val parser = factory.newPullParser()
            parser.setInput(xml.reader())

            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "Resp") {
                    val errCode = parser.getAttributeValue(null, "errCode") ?: ""
                    val errInfo = parser.getAttributeValue(null, "errInfo") ?: ""
                    return PidResponseError(errCode, errInfo)
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }


    fun callSavePartiesAPI(aadharEKYCWithFacialPIDResponse: AadharEKYCWithFacialPIDResponse?) {

        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)

        val AADHAR = regData.aadhar
        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val DOCT_NO = regData.doctNo
        val REG_YEAR = regData.regYear
        val CODE = regData.code
        val EC_NUMBER = regData.ecNumber
        val ENTRY_BY = regData.entryBy

        val age_calculate = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth?.let {
            Utilities.calculateAge(
                it
            )
        }

        val A_NAME = aadharEKYCWithFacialPIDResponse?.userInfo?.name
        val CARE_OF = aadharEKYCWithFacialPIDResponse?.userInfo?.careOf
        val GENDER = aadharEKYCWithFacialPIDResponse?.userInfo?.gender
        val DOB = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth
        val PIN_CODE = aadharEKYCWithFacialPIDResponse?.userInfo?.pinCode
        val AGE = age_calculate
        val ADDRESS = aadharEKYCWithFacialPIDResponse?.userInfo?.landmark
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.location
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.district
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.state
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.country
        val PH_NO = "null"//null
        val PHOTO = aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto
        val DN_QUALIFIER = aadharEKYCWithFacialPIDResponse?.userInfo?.dnQualifier

        val UDC_SERIAL_NO = 23456720000000
        val CONSENT = "Y"
        val ACCESSED_BY = "P"
        val ESIGN = "N"
        val ADDRESS2 = ""

        val savePartiesRequest = SavePartiesRequest(AADHAR, SR_CODE, BOOK_NO, DOCT_NO, REG_YEAR, CODE, EC_NUMBER, ENTRY_BY,
            A_NAME, CARE_OF, GENDER, DOB, PIN_CODE, AGE, ADDRESS, PH_NO, PHOTO, DN_QUALIFIER,
            UDC_SERIAL_NO, CONSENT, ACCESSED_BY, ESIGN, ADDRESS2)

        val requestList = listOf(savePartiesRequest)

        // Make the saveParties call
        apiService.saveParties(requestList).enqueue(object : Callback<SavePartiesResponse> {
            override fun onResponse(
                call: Call<SavePartiesResponse>,
                response: Response<SavePartiesResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("saveParties Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("saveParties Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val savePartiesResponse = response.body()

                    var status = savePartiesResponse?.status

                    lblErrorResponse.text = "AadharEKYCWithFacialPID callSavePartiesAPI, tokenId: $status"

                    if (status != null) {
                        if(status == true) {

                            val message = savePartiesResponse?.message

                            if(savePartiesResponse?.data == true) {
                                lblErrorResponse.text =
                                    "callSavePartiesAPI, status: $status\nmessage: $message \ndata: ${savePartiesResponse?.data}"


                                ll_mainScreen.visibility = View.GONE
                                ll_success.visibility = View.VISIBLE


                                val ADDRESS = "" + aadharEKYCWithFacialPIDResponse?.userInfo?.landmark + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.location + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.district + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.state + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.country

                                var display =
                                        /*"Transaction Number :" + aadharEKYCWithFacialPIDResponse?.transactionNumber + "\n\n" +*/
                                        "Name: " + aadharEKYCWithFacialPIDResponse?.userInfo?.name + "\n" +
                                        "Date of Birth: " + aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth + "\n" +
                                        "Gender: " + aadharEKYCWithFacialPIDResponse?.userInfo?.gender + "\n" +
                                        "C/O: " + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf + "\n"


                                lblDetails.text = display +"Address: "+ADDRESS

                                aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto?.let {
                                    Utilities.displayBase64Image(
                                        it, myImageView)
                                }

                                /*try {
                                    val dialog: Dialog = getDialog(thisActivity)
                                    val text = dialog.findViewById<TextView>(R.id.lblHeader)
                                    text.text = "e-KYC successfully completed"
                                    val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
                                    dialogOK.setOnClickListener {
                                        dialog.dismiss()          // Close the alert dialog
                                        finish()  // Finish the activity
                                    }
                                    dialog.show()
                                    dialog.window?.apply {
                                        setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                                        setGravity(Gravity.CENTER)
                                    }
                                    return
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    logErrors("Utilities showAlert : " + e.localizedMessage)
                                }*/

                            }else{
                                lblErrorResponse.text =
                                    "callSavePartiesAPI, status: $status, message: $message \n" +
                                            "data: ${savePartiesResponse?.data}"
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = "Error\n"+savePartiesResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "Save Parties failed "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {
                    lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text =  getString(R.string.failed_try_again)+"."
                    lblErrorResponse.visibility = View.VISIBLE

                }
            }

            override fun onFailure(call: Call<SavePartiesResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("Save Parties failed : ${t.message}")

                if(callSavePartiesAPI == 0){
                    callSavePartiesAPI = 1
                    callSavePartiesAPI(aadharEKYCWithFacialPIDResponse)
                }else {
                    // Handle failure
                    lblErrorResponse.text = "Save Parties failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                    callSavePartiesAPI = 0
                }
            }
        })

    }


    fun callSavePartiesAPIForRefusal(aadharEKYCWithFacialPIDResponse: AadharEKYCWithFacialPIDResponse?) {

        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)

        val AADHAR = regData.aadhar
        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val DOCT_NO = regData.doctNo
        val REG_YEAR = regData.regYear
        val CODE = regData.code
        val EC_NUMBER = regData.ecNumber
        val ENTRY_BY = regData.entryBy

        val age_calculate = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth?.let {
            Utilities.calculateAge(
                it
            )
        }

        val A_NAME = aadharEKYCWithFacialPIDResponse?.userInfo?.name
        val CARE_OF = aadharEKYCWithFacialPIDResponse?.userInfo?.careOf
        val GENDER = aadharEKYCWithFacialPIDResponse?.userInfo?.gender
        val DOB = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth
        val PIN_CODE = aadharEKYCWithFacialPIDResponse?.userInfo?.pinCode
        val AGE = age_calculate
        val ADDRESS = aadharEKYCWithFacialPIDResponse?.userInfo?.landmark
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.location
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.district
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.state
        ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.country
        val PH_NO = "null"//null
        val PHOTO = aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto
        val DN_QUALIFIER = aadharEKYCWithFacialPIDResponse?.userInfo?.dnQualifier

        val UDC_SERIAL_NO = 23456720000000
        val CONSENT = "Y"
        val ACCESSED_BY = "P"
        val ESIGN = "N"
        val ADDRESS2 = ""

        val savePartiesRequest = SavePartiesRequest(AADHAR, SR_CODE, BOOK_NO, DOCT_NO, REG_YEAR, CODE, EC_NUMBER, ENTRY_BY,
            A_NAME, CARE_OF, GENDER, DOB, PIN_CODE, AGE, ADDRESS, PH_NO, PHOTO, DN_QUALIFIER,
            UDC_SERIAL_NO, CONSENT, ACCESSED_BY, ESIGN, ADDRESS2)

        val requestList = listOf(savePartiesRequest)

        // Make the saveParties call
        apiService.savePartiesForRefusal(requestList).enqueue(object : Callback<SavePartiesResponse> {
            override fun onResponse(
                call: Call<SavePartiesResponse>,
                response: Response<SavePartiesResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("savePartiesForRefusal Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("savePartiesForRefusal Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val savePartiesResponse = response.body()

                    var status = savePartiesResponse?.status

                    lblErrorResponse.text = "AadharEKYCWithFacialPID callSavePartiesAPI, tokenId: $status"

                    if (status != null) {
                        if(status == true) {

                            val message = savePartiesResponse?.message

                            if(savePartiesResponse?.data == true) {
                                lblErrorResponse.text =
                                    "callSavePartiesAPI, status: $status\nmessage: $message \ndata: ${savePartiesResponse?.data}"


                                ll_mainScreen.visibility = View.GONE
                                ll_success.visibility = View.VISIBLE
                                lblSuccessMessage.text = "Refusal e-KYC successfully completed"


                                val ADDRESS = "" + aadharEKYCWithFacialPIDResponse?.userInfo?.landmark + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.location + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.district + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.state + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.country

                                var display =
                                    /*"Transaction Number :" + aadharEKYCWithFacialPIDResponse?.transactionNumber + "\n\n" +*/
                                    "Name: " + aadharEKYCWithFacialPIDResponse?.userInfo?.name + "\n" +
                                            "Date of Birth: " + aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth + "\n" +
                                            "Gender: " + aadharEKYCWithFacialPIDResponse?.userInfo?.gender + "\n" +
                                            "C/O: " + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf + "\n"


                                lblDetails.text = display +"Address: "+ADDRESS

                                aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto?.let {
                                    Utilities.displayBase64Image(
                                        it, myImageView)
                                }

                                /*try {
                                    val dialog: Dialog = getDialog(thisActivity)
                                    val text = dialog.findViewById<TextView>(R.id.lblHeader)
                                    text.text = "e-KYC successfully completed"
                                    val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
                                    dialogOK.setOnClickListener {
                                        dialog.dismiss()          // Close the alert dialog
                                        finish()  // Finish the activity
                                    }
                                    dialog.show()
                                    dialog.window?.apply {
                                        setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                                        setGravity(Gravity.CENTER)
                                    }
                                    return
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    logErrors("Utilities showAlert : " + e.localizedMessage)
                                }*/

                            }else{
                                lblErrorResponse.text =
                                    "Refusal SaveParties, status: $status, message: $message \n" +
                                            "data: ${savePartiesResponse?.data}"
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = "Error\n"+savePartiesResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "Refusal Save Parties failed "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {
                    lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text =  getString(R.string.failed_try_again)+"."
                    lblErrorResponse.visibility = View.VISIBLE

                }
            }

            override fun onFailure(call: Call<SavePartiesResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("Save Parties failed : ${t.message}")

                if(callSavePartiesAPI == 0){
                    callSavePartiesAPI = 1
                    callSavePartiesAPIForRefusal(aadharEKYCWithFacialPIDResponse)
                }else {
                    // Handle failure
                    lblErrorResponse.text = "Refusal Save Parties failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                    callSavePartiesAPI = 0
                }
            }
        })

    }

}
