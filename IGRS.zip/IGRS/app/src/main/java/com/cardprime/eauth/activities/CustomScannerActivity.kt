package com.cardprime.eauth.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.cardprime.eauth.R
import com.journeyapps.barcodescanner.CaptureActivity

class CustomScannerActivity : CaptureActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_scanner)

        val backArrow = findViewById<View>(R.id.frmBackArrow)
        backArrow.setOnClickListener { v ->
            val resultIntent = Intent()
            setResult(RESULT_CANCELED, resultIntent)
            finish()
        }



    }



}
