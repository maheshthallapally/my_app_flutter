package com.cardprime.eauth.activities

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeDocumentHandoverRequest
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeRequest
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeResponse
import com.cardprime.eauth.utils.QRScanDocumentHandoverData
import com.cardprime.eauth.utils.QRScanEKycData
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.utils.Utilities.calculateDistanceInMeters
import com.pos.foodservicespos.widgets.EditTextCustom
import com.pos.foodservicespos.widgets.TextViewCustom
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DocumentHandoverQRCodeActivity : ParentActivity() {

    private lateinit var applicationPreferences: ApplicationPreferences

    private lateinit var txtAadharNumber: EditTextCustom
    private lateinit var lblScan: TextViewCustom
    private lateinit var lblTitle: TextViewCustom
    private lateinit var activity: Activity
    private lateinit var scQrScan: ScrollView
    private lateinit var ll_qrDetails: LinearLayout
    private lateinit var lblQrDetails: TextViewCustom
    private lateinit var lblFaceScan: TextViewCustom
    private lateinit var lblCancelFaceScan: TextViewCustom
    private lateinit var back_button: ImageView
    private lateinit var ll_logout: LinearLayout

    val CAMERA_PERMISSION: Int = 1001
    val LOCATION_PERMISSION: Int = 1003
    val LOCATION_ON: Int = 1002

    var data_status_final: String = ""
    var regData_final: QRScanDocumentHandoverData = QRScanDocumentHandoverData(0, 0, 0, 0, "", "")
    var result_final: String = ""

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1001
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private fun getLastKnownLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                location?.let {
                    val latitude = it.latitude
                    val longitude = it.longitude
                    Utilities.logI("Distance Lat: $latitude, Lng: $longitude")

                    val distanceMeters = ApplicationPreferences.getLatitude(thisActivity)?.let { it1 ->
                        ApplicationPreferences.getLongitude(thisActivity)?.let { it2 ->
                            Utilities.logI("Distance: latitude $it1")
                            Utilities.logI("Distance: longitude $it2")
                            calculateDistanceInMeters(
                                lat1 = latitude, lon1 = longitude,   // My Location
                                lat2 = it1, lon2 = it2
                            )
                        }
                    }

                    Utilities.logI("Distance: %.2f meters".format(distanceMeters))

                    if (distanceMeters != null) {
                        if(distanceMeters > 50){
                            var location_details = "Document Handover\n\nCurrent location of phone: Lat: $latitude, Lng: $longitude .\n\nSRO Code: ${ApplicationPreferences.getSROCode(thisActivity)} \n\nSRO Lat: ${ApplicationPreferences.getLatitude(thisActivity)}  Lng: ${ApplicationPreferences.getLongitude(thisActivity)}\n\nDistance in Meters: $distanceMeters "
                            Utilities.showAlertCopy(thisActivity, "Unauthorised access.\nSRO locations are not matched with your current location.", location_details)
                            //Utilities.showAlert(thisActivity, "Unauthorised access.\nSRO locations are not matched with your current location.")
                        }else{
                            proceedtoNextStep(data_status_final, regData_final, result_final)
                        }
                    }else{
                        Utilities.showAlert(thisActivity, "Unauthorised access.\n\nSRO locations are not matched with your current location.")
                    }

                } ?: run {
                    Utilities.logI("Location is null")
                    var location_details = "Location is null"
                    Utilities.showAlertCopy(thisActivity, "Unable to fetch the location. Please enable it in settings. & Enable the location services on phone", location_details)
                }
            }
            .addOnFailureListener {
                Utilities.logI("Failed to get location: ${it.message}")
            }
    }

    // Handle permission result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastKnownLocation()
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    // User denied without "Don't ask again", so we can ask again
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        LOCATION_PERMISSION_REQUEST_CODE
                    )
                } else {
                    Utilities.showAlertAndOpenAppSettingsforLocation(thisActivity, "Location permission denied. Please enable it in settings.", packageName)
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        applicationPreferences = ApplicationPreferences
        // Retrieve saved theme and apply

        activity = this
        Utilities.applyTheme(applicationPreferences.getThemeMode(this), activity)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(thisActivity)

        lblTitle = findViewById(R.id.lblTitle)
        lblScan = findViewById(R.id.lblScan)
        txtAadharNumber = findViewById(R.id.txtAadharNumber)
        scQrScan = findViewById(R.id.scQrScan)
        ll_qrDetails = findViewById(R.id.ll_qrDetails)
        lblQrDetails = findViewById(R.id.lblQrDetails)
        lblFaceScan = findViewById(R.id.lblFaceScan)
        lblCancelFaceScan = findViewById(R.id.lblCancelFaceScan)

        ll_logout = findViewById(R.id.ll_logout)
        ll_logout.setOnClickListener{

            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes") { _, _ ->
                    applicationPreferences.setToken(thisActivity, "")
                    applicationPreferences.setLoginTime(thisActivity, 0)
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
                .setNegativeButton("No", null)
                .show()
        }

        lblTitle.text = getText(R.string.document_handover)

        back_button = findViewById(R.id.back_button)

        back_button.setOnClickListener {
            finish()
        }

        lblCancelFaceScan.setOnClickListener(){
            ll_qrDetails.visibility = View.GONE
            scQrScan.visibility = View.VISIBLE
        }

        lblFaceScan.setOnClickListener(){

            ll_qrDetails.visibility = View.GONE
            scQrScan.visibility = View.VISIBLE

            Utilities.logI("lblFaceScan1 ${lblFaceScan.getTag().toString()}")
            applicationPreferences.setAadharNumber(thisActivity, lblFaceScan.getTag().toString())
            Utilities.logI("lblFaceScan2 ${applicationPreferences.getAadharNumber(thisActivity)}")
            startActivity(Intent(applicationContext, DocumentHandoverProcessActivity::class.java))
        }

        lblScan.setOnClickListener {
            applicationPreferences.setAadharNumber(thisActivity, "")

            if (ContextCompat.checkSelfPermission(
                    thisActivity,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(
                        arrayOf<String>(Manifest.permission.CAMERA),
                        CAMERA_PERMISSION
                    )
                }
            }else{
                if(Utilities.isLocationEnabled(thisActivity)) {
                    initializeGPS()
                }else{
                    Utilities.openLocationOn(thisActivity)
                }
            }

            if(txtAadharNumber.visibility == View.VISIBLE) {
                if (txtAadharNumber.text.toString().trim().length == 0) {
                    Utilities.showAlert(thisActivity, "Please enter your aadhar number")
                } else if (txtAadharNumber.text.toString().trim().length < 12) {
                    Utilities.showAlert(thisActivity, "Please enter your valid aadhar number")
                } else {
                    applicationPreferences.setAadharNumber(
                        thisActivity,
                        txtAadharNumber.text.toString().trim()
                    )
                    startActivity(Intent(applicationContext, DocumentHandoverProcessActivity::class.java))
                }
            }


        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result: IntentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result.contents != null) {
            //resultTextView.text = "Scanned: ${result.contents}"
            Utilities.logI("onActivityResult Scanned: ${result.contents}")

            try{
                val jsonStr = result.contents
                val regData = Gson().fromJson(jsonStr, QRScanDocumentHandoverData::class.java)

                var aadhar_number = regData.aadhar

                if(aadhar_number.length > 0 && aadhar_number.length == 12){

                    validateQrCodeAPI(regData, result.contents.toString())

                }else{
                    Utilities.showErrorAlert(thisActivity, "Invalid QR Code (Incorrect Aadhaar number)")
                }

                Utilities.logI("onActivityResult Scanned Parse: ${aadhar_number}\n${regData.doctNo} / ${regData.regYear}")

            }catch (e: Exception){
                Utilities.logI("onActivityResult Scanned Error: ${e.printStackTrace()}")
                Utilities.showErrorAlert(thisActivity, "Invalid QR Code")
            }

        } else {
            //resultTextView.text = "Cancelled"
            Utilities.logI("onActivityResult Cancelled")
            Utilities.showErrorAlert(thisActivity, "Failed to Scan QR")

        }
        super.onActivityResult(requestCode, resultCode, data)
    }


    fun initializeGPS() {
        if (ContextCompat.checkSelfPermission(
                thisActivity,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                /*requestPermissions(
                    arrayOf<String>(
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    ),
                    LOCATION_ON
                )*/

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    com.cardprime.eauth.activities.LoginActivity.LOCATION_PERMISSION_REQUEST_CODE
                )
            }
        } else {
            loadScanner()
        }
    }

    fun checkGpsEnabled() {
        val lm = thisActivity.getSystemService(LOCATION_SERVICE) as LocationManager
        var gps_enabled = false
        var network_enabled = false

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (ex: Exception) {
            ex.printStackTrace()
        }

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (ex: Exception) {
            ex.printStackTrace()
        }

        if (gps_enabled || network_enabled) {

            loadScanner()

        } else {
            // notify user
            val dialog = AlertDialog.Builder(thisActivity)
            dialog.setMessage(thisActivity.resources.getString(R.string.gps_is_disabled))
            dialog.setPositiveButton(
                thisActivity.resources.getString(R.string.enable_gps)
            ) { paramDialogInterface, paramInt ->
                val myIntent =
                    Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                thisActivity.startActivity(myIntent)
            }
            dialog.setNegativeButton(
                thisActivity.resources.getString(R.string.cancel)
            ) { paramDialogInterface, paramInt ->
                //                    thisActivity.getFragmentManager().popBackStack();
            }
            dialog.show()
        }
    }

    fun loadScanner() {
        val integrator = IntentIntegrator(this)
        integrator.setOrientationLocked(true)
        integrator.setPrompt("Scan a QR Code")
        integrator.setBeepEnabled(false)
        integrator.setCaptureActivity(PortraitCaptureActivity::class.java)
        integrator.initiateScan()
    }


    fun validateQrCodeAPI(regData: QRScanDocumentHandoverData, result: String) {

        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val REG_YEAR = regData.regYear
        val DOCT_NO = regData.doctNo
        val AADHAR = regData.aadhar
        val EMPL_NAME = regData.EMPL_NAME


        //val validateQrCodeRequest = ValidateQrCodeDocumentHandoverRequest(SR_CODE, BOOK_NO, REG_YEAR, DOCT_NO, AADHAR, EMPL_NAME)

        // Make the saveParties call
        apiService.getValidateDocumentHandoverQr(SR_CODE, BOOK_NO, REG_YEAR, DOCT_NO, AADHAR, EMPL_NAME).enqueue(object :
            Callback<ValidateQrCodeResponse> {
            override fun onResponse(
                call: Call<ValidateQrCodeResponse>,
                response: Response<ValidateQrCodeResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("getValidateDocumentHandoverQr Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("getValidateDocumentHandoverQr Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val validateQrCodeResponse = response.body()

                    var status = validateQrCodeResponse?.status

                    if (status != null) {
                        if(status == true) {

                            val status = validateQrCodeResponse?.status
                            val message = validateQrCodeResponse?.message
                            val data_status = validateQrCodeResponse?.data?.get(0)?.status
                            Utilities.logI("validateQrCodeAPI, status: $status, message: $message")

                            val data_isPrivateAttendance = validateQrCodeResponse?.data?.get(0)?.isPrivateAttendance

                            Utilities.logI("validateQrCodeAPI, status: $status, message: $message   data_isPrivateAttendance: $data_isPrivateAttendance")

                            if(data_status.equals("N") || data_status.equals("n")){
                                Utilities.showErrorAlert(activity, "Scanned QR Code is invalid, Generate a new QR Code.")
                                return
                            }

                            if(data_isPrivateAttendance.equals("Y") || data_isPrivateAttendance.equals("y")){
                                proceedtoNextStep(data_status, regData, result)
                            }else if (data_isPrivateAttendance.equals("N") || data_isPrivateAttendance.equals("n") ||
                                data_isPrivateAttendance.equals("") || data_isPrivateAttendance.equals(null)) {

                                if (data_status != null) {
                                    data_status_final = data_status
                                }
                                result_final = result
                                regData_final = regData;

                                getLastKnownLocation()
                            }

                        }else{
                            Utilities.showErrorAlert(activity, "Invalid QR Code")
                        }
                    }else{
                        Utilities.showErrorAlert(thisActivity, "Invalid QR Code")
                    }


                } else {
                    Utilities.showErrorAlert(thisActivity, "Invalid QR Code")

                }
            }

            override fun onFailure(call: Call<ValidateQrCodeResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Handle failure
                Utilities.logI("validateQrCodeAPI failed : ${t.message}")

                //Utilities.showErrorAlert(thisActivity, "Invalid QR Code(Failed to validate)")
                Utilities.showErrorAlert(activity, "QR code validation failed.")
            }
        })

    }

    fun proceedtoNextStep(data_status: String?, regData: QRScanDocumentHandoverData, result: String){
        if(data_status.equals("Y") || data_status.equals("y")) {

            lblQrDetails.text = "Document No: ${regData.doctNo} / ${regData.regYear} Aadhar No: ${regData.aadhar}\n\nWould you like proceed for e-KYC ?"

            ll_qrDetails.visibility = View.VISIBLE
            scQrScan.visibility = View.GONE
            lblFaceScan.setTag(result)


        }else{
            Utilities.showErrorAlert(activity, "Scanned QR Code is invalid, Generate a new QR Code.")
        }
    }

}
