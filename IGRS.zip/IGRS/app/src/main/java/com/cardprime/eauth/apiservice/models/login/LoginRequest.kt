package com.pos.foodservicespos.apiservice.models.login

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("role") val role: String,
    @SerializedName("SRO_CODE") val SRO_CODE: Int?,
    @SerializedName("SR_NAME") val SR_NAME: String?,
    @SerializedName("EMPL_ID") val EMPL_ID: Long,
    @SerializedName("EMPL_NAME") val EMPL_NAME: String?,
    @SerializedName("VILLAGE_NAME") val VILLAGE_NAME: String?,
    @SerializedName("VILLAGE_CODE") val VILLAGE_CODE: String?,
    @SerializedName("PASSWRD") val PASSWRD: String?,
    @SerializedName("EMPL_Data") val data: EMPL_Data?
)

data class EMPL_Data(
    @SerializedName("EMPL_ID") val EMPL_ID: Long?,
    @SerializedName("EMPL_NAME") val EMPL_NAME: String?,
    @SerializedName("STATUS") val STATUS: String?,
)
