package com.cardprime.eauth.activities


import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.utils.IGRSApplication
import com.pos.foodservicespos.apiservice.models.login.EncryptedPasswordResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarData
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarListResponse
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.utils.Utilities.getDialog
import com.pos.foodservicespos.widgets.TextViewCustom
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File


class SelectServiceActivity : ParentActivity() {

    private lateinit var llFaceScan: LinearLayout
    private lateinit var llESign: LinearLayout
    private lateinit var llRefusalFaceScan: LinearLayout
    private lateinit var llRefusalESign: LinearLayout
    private lateinit var llDocuemntHandover: LinearLayout
    private lateinit var ll_logout: LinearLayout
    private lateinit var applicationPreferences: ApplicationPreferences
    private lateinit var img_logo: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        applicationPreferences = ApplicationPreferences

        onBackPressedDispatcher.addCallback(this) {
            showExitConfirmation()
        }

        // Retrieve saved theme and apply
        applyTheme(applicationPreferences.getThemeMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_service)

        llFaceScan = findViewById(R.id.llFaceScan)
        llESign = findViewById(R.id.llESign)
        llRefusalFaceScan = findViewById(R.id.llRefusalFaceScan)
        llRefusalESign = findViewById(R.id.llRefusalESign)
        llDocuemntHandover = findViewById(R.id.llDocuemntHandover)
        ll_logout = findViewById(R.id.ll_logout)
        img_logo = findViewById(R.id.img_logo)

        try {
            val packageInfo = packageManager.getPackageInfo(packageName, 0)
            val versionName = packageInfo.versionName
            (findViewById<TextView>(R.id.lblVersion)).text = "v ${versionName}"
        }catch (e: Exception){
            e.printStackTrace()
        }

        llFaceScan.setOnClickListener {
            if(Utilities.isLocationEnabled(thisActivity)) {
                //startActivity(Intent(applicationContext, EKycQRCodeActivity::class.java))
                val intent = Intent(applicationContext, EKycQRCodeActivity::class.java)
                intent.putExtra("type", "ekyc")
                startActivity(intent)
            }else{
                Utilities.openLocationOn(thisActivity)
            }
        }

        llESign.setOnClickListener {
            if(Utilities.isLocationEnabled(thisActivity)) {
                //startActivity(Intent(applicationContext, ESignQRCodeActivity::class.java))
                val intent = Intent(applicationContext, ESignQRCodeActivity::class.java)
                intent.putExtra("type", "esign")
                startActivity(intent)
            }else{
                Utilities.openLocationOn(thisActivity)
            }
        }

        llRefusalFaceScan.setOnClickListener {
            if(Utilities.isLocationEnabled(thisActivity)) {
                val intent = Intent(applicationContext, EKycQRCodeActivity::class.java)
                intent.putExtra("type", "refusal_ekyc")
                startActivity(intent)
            }else{
                Utilities.openLocationOn(thisActivity)
            }
        }

        llRefusalESign.setOnClickListener {
            if(Utilities.isLocationEnabled(thisActivity)) {
                val intent = Intent(applicationContext, ESignQRCodeActivity::class.java)
                intent.putExtra("type", "refusal_esign")
                startActivity(intent)
            }else{
                Utilities.openLocationOn(thisActivity)
            }
        }

        llDocuemntHandover.setOnClickListener {
            if(Utilities.isLocationEnabled(thisActivity)) {
                startActivity(Intent(applicationContext, DocumentHandoverQRCodeActivity::class.java))
            }else{
                Utilities.openLocationOn(thisActivity)
            }
        }

        img_logo.setOnLongClickListener {
            /*var str_logs = ApplicationPreferences.getLogsData(IGRSApplication.getContext())
            if (str_logs != null) {
                Log.i("Mahesh", str_logs)
            }

            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Copied Text", str_logs)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show()*/
            shareLogFile(thisActivity)
            true
        }

        ll_logout.setOnClickListener{

            AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes") { _, _ ->
                    logoutAccount()
                }
                .setNegativeButton("No", null)
                .show()

            /*val dialog: Dialog = getDialog(applicationContext)
            val text = dialog.findViewById<TextView>(R.id.lblHeader)
            text.text = "Are you sure you want to log out?"
            val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
            val dialogCancel = dialog.findViewById<TextView>(R.id.lblCancel)
            dialogCancel.visibility = View.VISIBLE
            dialogOK.setOnClickListener {
                applicationPreferences.setToken(thisActivity, "")
                applicationPreferences.setLoginTime(thisActivity, 0)
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }

            dialogCancel.setOnClickListener {
                dialog.dismiss()          // Close the alert dialog
            }
            dialog.show()*/

        }

    }

    private fun showExitConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Exit App")
            .setMessage("Are you sure you want to exit?")
            .setPositiveButton("Yes") { _, _ ->
                // Finish activity or move task to back
                /*moveTaskToBack(true)*/
                finish()
            }
            .setNegativeButton("No", null)
            .show()
    }

    fun shareLogFile(context: Context) {
        val logFile = File(File(context.filesDir, "logs"), "logs.txt")

        if (!logFile.exists()) {
            Toast.makeText(context, "Log file not found", Toast.LENGTH_SHORT).show()
            return
        }

        // Get content URI
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            logFile
        )

        // Create share intent
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "App Logs")
            putExtra(Intent.EXTRA_TEXT, "Please find attached log file.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        // Launch chooser
        context.startActivity(Intent.createChooser(shareIntent, "Share Log via"))
    }

    private fun applyTheme(mode: String?) {
        when (mode) {
            "cool" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                setTheme(R.style.AppCoolTheme)
            }
            "dark" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                setTheme(R.style.AppDarkTheme)
            }
            "system" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            else -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                setTheme(R.style.AppCoolTheme) // Default to cool theme
            }
        }
    }



    private fun logoutAccount(){
        // Get the root layout (full screen)
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        // Create a FrameLayout to overlay the screen
        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        // Create ProgressBar dynamically
        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // Add ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // Add overlay (with ProgressBar) to the root layout
        rootLayout.addView(overlayLayout)

        // Show the ProgressBar
        progressBar.visibility = View.VISIBLE

        // Handle login API call or authentication logic
        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))
        apiService.logoutAccount().enqueue(object : Callback<EncryptedPasswordResponse> {
            override fun onResponse(
                call: Call<EncryptedPasswordResponse>,
                response: Response<EncryptedPasswordResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("logoutAccount Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}

                applicationPreferences.setToken(thisActivity, "")
                applicationPreferences.setLoginTime(thisActivity, 0)
                startActivity(Intent(applicationContext, LoginActivity::class.java))
                finish()

                //if (response.isSuccessful) { } else { }
            }

            override fun onFailure(call: Call<EncryptedPasswordResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Handle failure
                Utilities.logI("logoutAccount failed: ${t.message}")

                applicationPreferences.setToken(thisActivity, "")
                applicationPreferences.setLoginTime(thisActivity, 0)
                startActivity(Intent(applicationContext, LoginActivity::class.java))
                finish()

            }
        })
    }

}
