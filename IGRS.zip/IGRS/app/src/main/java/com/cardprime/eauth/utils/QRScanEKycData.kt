package com.cardprime.eauth.utils

import com.google.gson.annotations.SerializedName

data class QRScanEKycData(
    @SerializedName("AADHAR")   var aadhar: String,
    @SerializedName("SR_CODE")  val srCode: Int,
    @SerializedName("BOOK_NO")  val bookNo: Int,
    @SerializedName("DOCT_NO")  val doctNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("CODE")     val code: String,
    @SerializedName("EC_NUMBER")val ecNumber: Int,
    @SerializedName("ENTRY_BY") val entryBy: String
)
