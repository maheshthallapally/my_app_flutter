package com.cardprime.eauth.apiservice.models.saveparties

import com.google.gson.annotations.SerializedName

data class SavePartiesResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    @SerializedName("data") val data: Boolean
)

