package com.cardprime.eauth.apiservice

import com.pos.foodservicespos.utils.Utilities

object AuthXMLBuilder {
    fun buildAndSendAuthXML(pidData: String, aadhaar: String) {
        Utilities.logI("Received PID Data: $pidData")
        Utilities.logI("Forming Auth XML for Aadhaar: $aadhaar")

        val authXml = """
            <Auth uid='$aadhaar' tid='' ac='public' sa='public' ver='2.5' txn='TXN12345' lk='license_key'>
                <Uses bio='n' otp='n' pi='n' pa='n' pfa='n' pin='n' fmr='n' iri='n' iris='n' face='y'/>
                <Meta udc='DEVICE_ID' fdc='NC' idc='NA' pip='127.0.0.1' lot='P' lov='110001'/>
                <Skey ci='20250101'>ENCRYPTED_SESSION_KEY</Skey>
                <Hmac>ENCRYPTED_HMAC</Hmac>
                <Data type='X'>ENCRYPTED_PID_BLOCK</Data>
            </Auth>
        """.trimIndent()

        Utilities.logI("Auth XML:$authXml")
    }
}