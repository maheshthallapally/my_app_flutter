package com.cardprime.eauth.apiservice.apis

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// Generic extension function for Retrofit API calls
fun <T> Call<T>.enqueueResponse(
    onSuccess: (T) -> Unit,
    onFailure: (Throwable) -> Unit
) {
    this.enqueue(object : Callback<T> {
        override fun onResponse(call: Call<T>, response: Response<T>) {
            if (response.isSuccessful) {
                response.body()?.let { data ->
                    onSuccess(data)
                } ?: onFailure(Throwable("Response body is null"))
            } else {
                onFailure(Throwable("Response error: ${response.code()}"))
            }
        }

        override fun onFailure(call: Call<T>, t: Throwable) {
            onFailure(t)
        }
    })
}
