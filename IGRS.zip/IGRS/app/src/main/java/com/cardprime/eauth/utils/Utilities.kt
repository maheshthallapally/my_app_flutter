package com.pos.foodservicespos.utils

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.util.Base64
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.cardprime.eauth.R
import com.cardprime.eauth.activities.ParentActivity
import com.cardprime.eauth.utils.IGRSApplication
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.io.PrintWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.Period
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Hashtable
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

object Utilities {

    var sTypeFaces: Hashtable<String, Typeface> = Hashtable(4)
    var logFileName = "logs"
    var logFilePath = "data/data/.IGRS/.Logs"
    var res: Resources? = null
    private lateinit var sharedPreferences: SharedPreferences

    // Encode a String to Base64
    fun encodeToBase64(input: String): String {
        return Base64.encodeToString(input.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    // Decode a Base64 String
    fun decodeFromBase64(base64Str: String): String {
        val decodedBytes = Base64.decode(base64Str, Base64.NO_WRAP)
        return String(decodedBytes, Charsets.UTF_8)
    }


    public fun applyTheme(mode: String?, activity: Activity) {
        when (mode) {
            "cool" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                activity.setTheme(R.style.AppCoolTheme)
            }
            "dark" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                activity.setTheme(R.style.AppDarkTheme)
            }
            "system" -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            else -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                activity.setTheme(R.style.AppCoolTheme) // Default to cool theme
            }
        }
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false

        return activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    fun showAlertCopy(thisActivity: Context, alertMsg: String, textToCopy: String ) {
        try {
            val dialog: Dialog = getDialog(thisActivity)
            val text = dialog.findViewById<TextView>(R.id.lblHeader)
            text.text = alertMsg

            text.setOnClickListener{
                val clipboard = thisActivity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Copied Text", textToCopy)
                clipboard.setPrimaryClip(clip)

                Toast.makeText(thisActivity, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
            }

            val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
            dialogOK.setOnClickListener { v: View? -> dialog.dismiss() }
            dialog.show()
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.CENTER)
            }
            return
        } catch (e: Exception) {
            e.printStackTrace()
            logErrors("Utilities showAlert : " + e.localizedMessage)
        }
    }

    fun showAlert(thisActivity: Context, alertMsg: String) {
        try {
            val dialog: Dialog = getDialog(thisActivity)
            val text = dialog.findViewById<TextView>(R.id.lblHeader)
            text.text = alertMsg
            val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
            dialogOK.setOnClickListener { v: View? -> dialog.dismiss() }
            dialog.show()
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.CENTER)
            }
            return
        } catch (e: Exception) {
            e.printStackTrace()
            logErrors("Utilities showAlert : " + e.localizedMessage)
        }
    }

    fun showErrorAlert(thisActivity: Context, alertMsg: String) {
        try {
            val dialog: Dialog = getErrorDialog(thisActivity)
            val text = dialog.findViewById<TextView>(R.id.lblHeader)
            text.text = alertMsg
            val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
            dialogOK.setOnClickListener { v: View? -> dialog.dismiss() }
            dialog.show()
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.CENTER)
            }
            return
        } catch (e: Exception) {
            e.printStackTrace()
            logErrors("Utilities showAlert : " + e.localizedMessage)
        }
    }

    fun showAlertAndOpenAppSettingsforLocation(
        thisActivity: Context,
        alertMsg: String,
        packageName: String
    ){
        try {
            val dialog: Dialog = Utilities.getDialog(ParentActivity.thisActivity)
            val text = dialog.findViewById<TextView>(R.id.lblHeader)
            text.text = alertMsg
            val dialogOK = dialog.findViewById<TextView>(R.id.lblOK)
            dialogOK.setOnClickListener {
                dialog.dismiss()
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                thisActivity.startActivity(intent)
            }
            dialog.show()
            dialog.window?.apply {
                setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.CENTER)
            }
            return
        } catch (e: Exception) {
            e.printStackTrace()
            logErrors("Utilities showAlert : " + e.localizedMessage)
        }
    }


    fun logErrors(contentStr: String?) {
        val message = contentStr ?: "null"
        val context = IGRSApplication.getContext()

        // Always log to Logcat as ERROR
        Log.e("CARD_PRIMME_ERROR", "❌ $message")

        //generateLogsOnPrefs("ErrorLog: "+message)

        try {
            val context = IGRSApplication.getContext()
            val enableFileLogging = true

            if (!enableFileLogging) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                generateNotesOnSD(context, logFileName, message)
            } else {
                val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED
                } else true

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R || hasPermission) {
                    generateNotesOnSD(context, logFileName, message)
                }
            }

        } catch (e: Exception) {
            Log.e("CARD_PRIMME", "logI exception: ${e.message}")
        }
    }


    fun getDialog(thisActivity: Context?): Dialog {
        val dialog = Dialog(thisActivity!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.custom_dialogue)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= 33) {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        } else {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return dialog
    }

    fun getErrorDialog(thisActivity: Context?): Dialog {
        val dialog = Dialog(thisActivity!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.custom_dialogue_error)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= 33) {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        } else {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return dialog
    }

    fun getApiResponseDialogue(thisActivity: Context?): Dialog? {
        /*val dialog = Dialog(thisActivity!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.api_status_alert)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= 33) {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        } else {
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return dialog*/
        return null;
    }


    fun logI(contentStr: String?) {
        val message = contentStr ?: "null"

        // Always log to Logcat regardless of preferences
        Log.i("CARD_PRIMME", message)

        //generateLogsOnPrefs(message)

        try {
            val context = IGRSApplication.getContext()
            val enableFileLogging = true

            if (!enableFileLogging) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                generateNotesOnSD(context, logFileName, message)
            } else {
                val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED
                } else true

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R || hasPermission) {
                    generateNotesOnSD(context, logFileName, message)
                }
            }

        } catch (e: Exception) {
            Log.e("CARD_PRIMME", "logI exception: ${e.message}")
        }
    }

    fun generateLogsOnPrefs(message: String) {
        var dateTime = ""
        try {
            val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
            dateTime = sdf.format(Date())
        } catch (ignored: java.lang.Exception) {}


        try{
            var str_logs = ApplicationPreferences.getLogsData(IGRSApplication.getContext())
            str_logs = str_logs + "\n" + dateTime + " : " + message

            try {
                val lastLine = str_logs.lines().lastOrNull()

                if (isOlderThan12Hours(lastLine.toString())) {
                    print("Log is older than 12 hours.")
                    ApplicationPreferences.setLogsData(IGRSApplication.getContext(), "");
                } else {
                    print("Log is recent.")
                    ApplicationPreferences.setLogsData(IGRSApplication.getContext(), str_logs);
                }
            }catch (e:Exception ){
                ApplicationPreferences.setLogsData(IGRSApplication.getContext(), str_logs);
            }
        }catch (e:Exception){}
    }

    fun isOlderThan12Hours(log: String): Boolean {
        val timestamp = extractTimestamp(log)
        //logI("Extracted Timestamp: $timestamp")
        if (timestamp != null) {
            val now = LocalDateTime.now()
            val duration = java.time.Duration.between(timestamp, now)
            return duration.toHours() > 12
        }
        return false
    }

    fun extractTimestamp(log: String): LocalDateTime? {
        return try {
            val regex = Regex("""^\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2}""")
            val match = regex.find(log)?.value
            val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")
            match?.let { LocalDateTime.parse(it, formatter) }
        } catch (e: Exception) {
            null
        }
    }

    fun generateNotesOnSD(context: Context, sFileName: String, sBody: String) {
        try {
            val root: File
            val gpxfile: File

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // logs is treated as a folder for Android R+
                root = File(context.filesDir, logFileName) // "logs" directory
                if (!root.exists()) root.mkdirs()
                gpxfile = File(root, "logs.txt") // actual file
            } else {
                // logs is used as folder for pre-R (legacy external storage)
                root = File(Environment.getExternalStorageDirectory(), logFilePath)
                if (!root.exists()) root.mkdirs()
                gpxfile = File(root, logFileName) // logs.txt file
            }

            // Clear log if it exceeds 5 KB (or MB if FileSize is in KB)
            try {
                //Log.i("FileSize(gpxfile)","FileSize(gpxfile) ${FileSize(gpxfile)}")
                val fileSize = FileSize(gpxfile) / 1024
                if (fileSize >= 5) {
                    clearLogFileData(context, logFileName)
                }
            } catch (_: Exception) {
            }

            // Get current timestamp
            val dateTime = try {
                val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault())
                sdf.format(Date())
            } catch (_: Exception) {
                ""
            }

            // Write log entry (append mode)
            try {
                BufferedWriter(FileWriter(gpxfile, true)).use { buf ->
                    buf.append(dateTime).append(" : ").append(sBody)
                    buf.newLine()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    fun generateNotesOnSD2(context: Context, sFileName: String?, sBody: String) {
        try {
            var root: File? = null
            root = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                File(context.filesDir, logFileName)
            } else {
                File(
                    Environment.getExternalStorageDirectory(),
                    logFilePath
                )
            }
            if (!root.exists()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        root.createNewFile()
                        logI("generateNotesOnSD File has been created root.getAbsolutePath() " + root.absolutePath)
                    } catch (e: IOException) {
                        logI("generateNotesOnSD File has been creation failed root.getAbsolutePath() " + root.absolutePath)
                    }
                } else {
                    root.mkdirs()
                }
            }
            var gpxfile: File? = null
            gpxfile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                File(root.toString())
            } else {
                File(root, logFileName)
            }
            try {
                val filesize: Long =
                    FileSize(gpxfile) / 1024
                if (filesize >= 5) {  // Clearing the data int the file after every 5 MB
                    clearLogFileData(
                        context,
                        logFileName
                    )
                } /*else{
                    clearLogfileonDailyBasis(logFileName);
                }*/
            } catch (ignored: java.lang.Exception) {
            }
            var dateTime = ""
            try {
                val sdf = SimpleDateFormat("dd-MM-yyyy HH:mm:ss")
                dateTime = sdf.format(Date())
            } catch (ignored: java.lang.Exception) {
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    /*FileWriter fileWriter = new FileWriter(gpxfile.getAbsolutePath()+File.separator+""+logFileName, true);
                    BufferedWriter buf = new BufferedWriter(fileWriter);
                    buf.append(dateTime+" : "+sBody);
                    buf.newLine();
                    buf.close();*/
                    val fileWriter = FileWriter(gpxfile, true)
                    val buf = BufferedWriter(fileWriter)
                    buf.append("$dateTime : $sBody")
                    buf.newLine()
                    buf.close()
                } else {
                    val buf = BufferedWriter(FileWriter(gpxfile, true))
                    buf.append("$dateTime : $sBody")
                    buf.newLine()
                    buf.close()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        } catch (e: java.lang.Exception) {
        }
    }

    fun FileSize(fileName: File): Long {
        return try {
            val filesize = fileName.length()
            filesize / 1024
        } catch (e: java.lang.Exception) {
            0
        }
    }

    fun clearLogFileData(context: Context, sFileName: String?) {
        try {
            var root: File? = null
            root = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                File(context.filesDir, logFileName)
            } else {
                File(
                    Environment.getExternalStorageDirectory(),
                    logFilePath
                )
            }
            if (!root.exists()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        root.createNewFile()
                        logI("clearLogFileData File has been created root.getAbsolutePath() " + root.absolutePath)
                    } catch (e: IOException) {
                        logI("clearLogFileData File has been creation failed root.getAbsolutePath() " + root.absolutePath)
                    }
                } else {
                    root.mkdirs()
                }
            }
            var gpxfile: File? = null
            gpxfile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                File(root.toString())
            } else {
                File(root, logFileName)
            }
            val writer = PrintWriter(gpxfile)
            writer.print("")
            writer.close()
        } catch (ignored: java.lang.Exception) {
        }
    }

    fun getColor(context: Context, id: Int): Int {
        val version = Build.VERSION.SDK_INT
        return if (version >= 23) {
            ContextCompat.getColor(context, id)
        } else {
            context.resources.getColor(id)
        }
    }

    fun getDrawable(context: Context, id: Int): Drawable? {
        val version = Build.VERSION.SDK_INT
        return if (version >= 23) {
            ContextCompat.getDrawable(context, id)
        } else {
            context.resources.getDrawable(id)
        }
    }

    fun setLabelWithAsterisk(context: Context, textView: TextView, text: String) {
        val spannable = SpannableString("$text") // Append * to text
        spannable.setSpan(
            ForegroundColorSpan(Color.RED), // Set last character to red
            spannable.length - 1, // Last character
            spannable.length,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        textView.text = spannable
    }
    fun saveCredentials(email: String, password: String, context: Context) {
        sharedPreferences = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("EMAIL", email)
        editor.putString("PASSWORD", password)
        editor.putBoolean("REMEMBER_ME", true)
        editor.apply()
    }

    fun clearCredentials(context: Context) {
        sharedPreferences = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove("EMAIL")
        editor.remove("PASSWORD")
        editor.putBoolean("REMEMBER_ME", false)
        editor.apply()
    }

    fun parseErrorJson(jsonString: String): String {
        try {
            // Create a JSONObject from the JSON string
            val jsonObject = JSONObject(jsonString)

            // Manually extract the "error" field
            if(jsonObject.has("message")) {
                return jsonObject.getString("message") // Returns "Invalid Credentials"
            }else{
                return "API error"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return "Error parsing JSON"
        }
    }

    fun getCurrentDateTime(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return dateFormat.format(Date())
    }

    fun safeToast(context: Context?, message: String) {
        try {
            if (context is Activity && !context.isFinishing && !context.isDestroyed) {
                context.runOnUiThread {
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                }
            }
        }catch (e: Exception){

        }
    }


    fun displayBase64Image(base64Data: String, imageView: ImageView) {
        try {
            // Remove data URI prefix if present (e.g., "data:image/png;base64,")
            val pureBase64 = base64Data.substringAfter(",")

            // Decode base64 to byte array
            val decodedBytes = Base64.decode(pureBase64, Base64.DEFAULT)

            // Convert byte array to Bitmap
            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)

            // Set the Bitmap to ImageView
            imageView.setImageBitmap(bitmap)
        } catch (e: Exception) {
            e.printStackTrace()
            // Optionally handle error (e.g., show a placeholder image)
        }
    }


    fun calculateAge(dobString: String): Int {
        try {
            val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
            val dob = LocalDate.parse(dobString, formatter)
            val today = LocalDate.now()
            val age = Period.between(dob, today).years
            return age
        }catch (e: Exception){
            return 0
        }

    }

    fun calculateDistanceInMeters(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val earthRadiusKm = 6371.0

        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        val distanceKm = earthRadiusKm * c
        return distanceKm * 1000  // convert to meters
    }


    fun isLocationEnabled(context: Context): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    fun openLocationOn(thisActivity: Context){
        AlertDialog.Builder(thisActivity)
            .setTitle("Location Required")
            .setMessage("Please enable location services to continue.")
            .setPositiveButton("Enable") { _, _ ->
                thisActivity.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun decryptDatas(encryptedBase64: String, key: String): String {
        // In CryptoJS, short keys are zero-padded or truncated.
        // Manually pad or truncate to 16 bytes (AES-128).
        val normalizedKey = key.toByteArray(StandardCharsets.UTF_8).copyOf(16)
        Utilities.logI("🔐 normalizedKey bytes: ${normalizedKey.joinToString(", ") { it.toString() }}")
        Utilities.logI("🔐 normalizedKey hex: ${normalizedKey.joinToString("") { "%02x".format(it) }}")


        val secretKeySpec = SecretKeySpec(normalizedKey, "AES")

        val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec)

        val encryptedBytes = Base64.decode(encryptedBase64, Base64.DEFAULT)
        val decryptedBytes = cipher.doFinal(encryptedBytes)

        return String(decryptedBytes, StandardCharsets.UTF_8)
    }

}