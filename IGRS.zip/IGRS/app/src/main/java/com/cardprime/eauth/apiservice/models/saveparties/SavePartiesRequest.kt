package com.cardprime.eauth.apiservice.models.saveparties

import com.google.gson.annotations.SerializedName

data class SavePartiesRequest(
    @SerializedName("AADHAR") val aadhar: String,
    @SerializedName("SR_CODE") val srCode: Int,
    @SerializedName("BOOK_NO") val bookNo: Int,
    @SerializedName("DOCT_NO") val documentNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("CODE") val code: String,
    @SerializedName("EC_NUMBER") val ecNumber: Int,
    @SerializedName("ENTRY_BY") val entryBy: String,

    @SerializedName("A_NAME") val name: String?,
    @SerializedName("CARE_OF") val careOf: String?,
    @SerializedName("GENDER") val gender: String?,
    @SerializedName("DOB") val dob: String?,
    @SerializedName("PIN_CODE") val pinCode: String?,
    @SerializedName("AGE") val age: Int?,
    @SerializedName("ADDRESS") val address: String?,
    @SerializedName("PH_NO") val phoneNumber: String?, // nullable
    @SerializedName("PHOTO") val photo: String?,
    @SerializedName("DN_QUALIFIER") val dnQualifier: String?,

    @SerializedName("UDC_SERIAL_NO") val udcSerialNo: Long?,
    @SerializedName("CONSENT") val consent: String,
    @SerializedName("ACCESSED_BY") val accessedBy: String,
    @SerializedName("ESIGN") val eSign: String,
    @SerializedName("ADDRESS2") val address2: String,
)
