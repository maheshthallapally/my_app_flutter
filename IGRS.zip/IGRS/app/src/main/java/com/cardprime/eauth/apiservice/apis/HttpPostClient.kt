package com.cardprime.eauth.apiservice.apis

import com.pos.foodservicespos.utils.Utilities
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

object HttpPostClient {
    fun postAuthXml(authXml: String, endpointUrl: String) {
        val url = URL(endpointUrl)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/xml")
        conn.doOutput = true

        conn.outputStream.use { os: OutputStream ->
            os.write(authXml.toByteArray())
            os.flush()
        }

        val responseCode = conn.responseCode
        Utilities.logI("POST Response Code: $responseCode")
    }
}