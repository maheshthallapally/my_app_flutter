package com.pos.foodservicespos.apiservice.models.subregistrarlist

import com.google.gson.annotations.SerializedName

data class SubRegistrarListResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    //@SerializedName("data") val data: String
    @SerializedName("data") val data: List<SubRegistrarData>
)

data class SubRegistrarData(
    @SerializedName("SR_CD") val srCd: Int,
    @SerializedName("SR_NAME") val srName: String,
    @SerializedName("SR_EMAIL") val srEmail: String,
    @SerializedName("DR_CD") val drCd: String,
    @SerializedName("DIG_CD") val digCd: String,
    @SerializedName("IP_ADDRESS") val ipAddress: String,
    @SerializedName("IP_FROM") val ipFrom: String,
    @SerializedName("IP_TO") val ipTo: String,
    @SerializedName("SUBINDEX_CREATE") val subindexCreate: String?, // nullable
    @SerializedName("STATE_CD") val stateCd: String,
    @SerializedName("ADR_CD") val adrCd: Int,
    @SerializedName("STAMP_VERIFY") val stampVerify: String,
    @SerializedName("PHONE_NO") val phoneNo: Long,
    @SerializedName("LONGITUDE") val LONGITUDE: String,
    @SerializedName("LATITUDE") val LATITUDE: String

)

