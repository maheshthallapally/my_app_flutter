package com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid

import com.google.gson.annotations.SerializedName

data class AadharEKYCWithFacialPIDRequest(
    @SerializedName("aadharNumber") val aadharNumber: String,
    @SerializedName("pidData") val pidData: String
)
