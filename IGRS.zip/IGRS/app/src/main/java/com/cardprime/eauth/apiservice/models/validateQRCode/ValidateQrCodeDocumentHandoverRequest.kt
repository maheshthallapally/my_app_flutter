package com.cardprime.eauth.apiservice.models.validateQRCode

import com.google.gson.annotations.SerializedName

data class ValidateQrCodeDocumentHandoverRequest(
    @SerializedName("SR_CODE")  val srCode: Int,
    @SerializedName("BOOK_NO")  val bookNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("DOCT_NO")  val doctNo: Int,
    @SerializedName("AADHAR")   val aadhar: String,
    @SerializedName("EMPL_NAME") val EMPL_NAME: String,
)
