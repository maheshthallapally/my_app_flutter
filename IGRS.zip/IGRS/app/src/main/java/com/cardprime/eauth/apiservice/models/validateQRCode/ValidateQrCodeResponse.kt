package com.cardprime.eauth.apiservice.models.validateQRCode

import com.google.gson.annotations.SerializedName

data class ValidateQrCodeResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    @SerializedName("data") val data: List<StatusData>
)

data class StatusData(
    @SerializedName("status") val status: String, // UAT
    /*@SerializedName("STATUS") val status: String, // staging*/
    @SerializedName("isPrivateAttendance") val isPrivateAttendance: String
)

