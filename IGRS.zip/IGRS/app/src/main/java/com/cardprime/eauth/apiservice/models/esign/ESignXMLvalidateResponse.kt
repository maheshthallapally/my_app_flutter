package com.cardprime.eauth.apiservice.models.esign

import com.google.gson.annotations.SerializedName

data class ESignXMLvalidateResponse(
    @SerializedName("status") val status: String,
    @SerializedName("error") val error: String? = null,
    @SerializedName("callBackUrl") val callBackUrl: String? = null
)

