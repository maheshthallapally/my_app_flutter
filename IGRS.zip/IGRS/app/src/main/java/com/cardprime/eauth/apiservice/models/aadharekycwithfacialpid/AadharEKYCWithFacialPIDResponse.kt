package com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid

import com.google.gson.annotations.SerializedName

data class AadharEKYCWithFacialPIDResponse(
    @SerializedName("reference") val reference: String,
    @SerializedName("code") val code: String,
    @SerializedName("transactionNumber") val transactionNumber: String,
    @SerializedName("message") val message: String,
    @SerializedName("status") val status: String,
    @SerializedName("userInfo") val userInfo: UserInfo
)

data class UserInfo(
    @SerializedName("co") val careOf: String,
    @SerializedName("country") val country: String,
    @SerializedName("dist") val district: String,
    @SerializedName("lm") val landmark: String,
    @SerializedName("loc") val location: String,
    @SerializedName("pc") val pinCode: String,
    @SerializedName("po") val postOffice: String,
    @SerializedName("state") val state: String,
    @SerializedName("vtc") val villageTownCity: String,
    @SerializedName("dob") val dateOfBirth: String,
    @SerializedName("gender") val gender: String,
    @SerializedName("name") val name: String,
    @SerializedName("encodedPhoto") val encodedPhoto: String,
    @SerializedName("dnQualifier") val dnQualifier: String
)
