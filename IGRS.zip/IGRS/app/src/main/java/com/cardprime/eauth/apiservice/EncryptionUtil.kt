package com.cardprime.eauth.apiservice

import java.security.PublicKey
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

object EncryptionUtil {
    fun encryptPid(pidXml: String, uidaiPublicKey: PublicKey): Pair<String, String> {
        val keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(256)
        val aesKey: SecretKey = keyGen.generateKey()

        val aesCipher = Cipher.getInstance("AES")
        aesCipher.init(Cipher.ENCRYPT_MODE, aesKey)
        val encryptedPid = aesCipher.doFinal(pidXml.toByteArray())

        val rsaCipher = Cipher.getInstance("RSA")
        rsaCipher.init(Cipher.ENCRYPT_MODE, uidaiPublicKey)
        val encryptedSessionKey = rsaCipher.doFinal(aesKey.encoded)

        return Pair(
            Base64.getEncoder().encodeToString(encryptedPid),
            Base64.getEncoder().encodeToString(encryptedSessionKey)
        )
    }
}