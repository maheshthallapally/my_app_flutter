package com.pos.foodservicespos.apiservice.models.login

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    @SerializedName("data") val data: LoginData
)

data class LoginData(
    @SerializedName("role") val role: String,
    @SerializedName("SR_NAME") val srName: String,
    @SerializedName("EMPL_ID") val emplId: Long,
    @SerializedName("EMPL_NAME") val emplName: String,
    @SerializedName("SR_CODE") val srCode: Int,
    @SerializedName("access_token") val accessToken: AccessToken,
    @SerializedName("UpdateLogin") val updateLogin: Int,
    @SerializedName("Status") val status: String?, // nullable
    @SerializedName("DR_CD") val drCd: String
)

data class AccessToken(
    @SerializedName("token") val token: String,
    @SerializedName("expires") val expires: String,
    @SerializedName("refreshTokenUrl") val refreshTokenUrl: String
)
