package com.cardprime.eauth.activities

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import com.cardprime.eauth.R
import com.cardprime.eauth.apiservice.PidOptionsBuilder
import com.cardprime.eauth.apiservice.apis.RetrofitClient
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDRequest
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDResponse
import com.cardprime.eauth.apiservice.models.esign.ESignSaveTxnResponse
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesRequest
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesResponse
import com.cardprime.eauth.utils.QRScanDocumentHandoverData
import com.cardprime.eauth.utils.QRScanEKycData
import com.google.gson.Gson
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities
import com.pos.foodservicespos.widgets.TextViewCustom
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.random.Random
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory


class DocumentHandoverProcessActivity : ParentActivity() {

    private lateinit var iv_error: ImageView
    private lateinit var lblTitle2: TextViewCustom
    private lateinit var lblResponse: TextViewCustom
    private lateinit var lblErrorResponse: TextViewCustom
    private lateinit var lblTryAgian: TextViewCustom
    private lateinit var ll_mainScreen: RelativeLayout
    private lateinit var ll_success: RelativeLayout
    private lateinit var lblDetails: TextViewCustom
    private lateinit var lblOK: TextViewCustom
    private lateinit var myImageView: ImageView

    private lateinit var applicationPreferences: ApplicationPreferences
    private lateinit var activity: Activity

    var aadhaarData = ""
    var aadharEKYCWithFacialPIDRetry = 0
    var callSaveHandoverAPI = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        applicationPreferences = ApplicationPreferences
        // Retrieve saved theme and apply
        activity = this
        Utilities.applyTheme(applicationPreferences.getThemeMode(this), activity)
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_ekyc_esign_process)

        Utilities.logI("DocumentHandoverProcessActivity - encodeToBase64 : "+applicationPreferences.getAadharNumber(thisActivity).toString())

        aadhaarData = applicationPreferences.getAadharNumber(thisActivity).toString() //"858633410612");

        Utilities.logI("DocumentHandoverProcessActivity - encodeToBase64aadhaarData : "+aadhaarData)

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanDocumentHandoverData::class.java)
        val aadharNumber = Utilities.encodeToBase64(regData.aadhar)

        Utilities.logI("DocumentHandoverProcessActivity - encodeToBase64 : "+aadharNumber+"\n"+applicationPreferences.getAadharNumber(thisActivity).toString())

        iv_error = findViewById(R.id.iv_error)
        lblTitle2 = findViewById(R.id.lblResponse)
        lblResponse = findViewById(R.id.lblResponse)
        lblErrorResponse = findViewById(R.id.lblErrorResponse)
        lblTryAgian = findViewById(R.id.lblTryAgian)
        ll_mainScreen =findViewById(R.id.ll_mainScreen)
        ll_success = findViewById(R.id.ll_success)
        lblDetails = findViewById(R.id.lblDetails)
        lblOK = findViewById(R.id.lblOK)
        myImageView = findViewById(R.id.myImageView)

        lblTitle2.text = thisActivity.getString(R.string.document_handover)

        lblResponse.setOnClickListener {
            val textToCopy = lblResponse.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Copied Text", textToCopy)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(this, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
        }

        openFaceScan()

        lblTryAgian.setOnClickListener(){
            lblErrorResponse.text = ""
            iv_error.visibility = View.GONE
            lblResponse.visibility = View.GONE
            lblTryAgian.visibility = View.GONE
            openFaceScan()
        }

        lblOK.setOnClickListener(){
            finish()
        }

    }

    fun openFaceScan(){
        val pidOptions = PidOptionsBuilder.build(generateRandomTenDigitNumber().toString(), "IURPC-BUQUO-NXCOW-TPOPI", "https://callback.url", "jwt-token")
        val intent = Intent("in.gov.uidai.rdservice.face.CAPTURE")
        intent.putExtra("request", pidOptions)
        startActivityForResult(intent, 101)
    }


    fun generateRandomTenDigitNumber(): Long {
        return Random.nextLong(1_000_000_000L, 10_000_000_000L)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        var print_data = "requestCode "+requestCode;
        var pidDataResponse = "";
        if (requestCode == 101 && resultCode == RESULT_OK) {
            print_data = print_data + "\nresultCode "+resultCode;
            val pidData = data?.getStringExtra("PidData")
            print_data = print_data + "\npidData "+pidData;

            val pidXml = data?.getStringExtra("PID_DATA")
            Log.i("mahesh", "maheshchandraprasad pidXml: "+pidXml);

            print_data = print_data + "\npidXml "+pidXml;

            val extras = data?.extras
            if (extras != null) {
                for (key in extras.keySet()) {
                    val value = extras.get(key)
                    print_data += "\n$key : $value"
                    pidDataResponse = "$value"
                }
            } else {
                print_data += "\nNo extras found in intent data"
            }

            if(pidDataResponse.contains("errCode") || pidDataResponse.contains("errInfo")){

                val error = parsePidDataError(pidDataResponse)
                Utilities.logI("Error Code: ${error?.errCode}, Info: ${error?.errInfo}")

                if(error?.errCode != "0") {
                    print_data = "Error Code: (${error?.errCode})\nInfo: ${error?.errInfo}"
                    iv_error.visibility = View.VISIBLE
                    lblResponse.visibility = View.VISIBLE
                    lblResponse.text = print_data
                    lblTryAgian.visibility = View.VISIBLE
                }else{
                    lblResponse.text = ""
                    callAPI(pidDataResponse)
                    //callSaveHandoverAPI()
                }
            }else {
                lblResponse.text = ""
                //callAPI(pidDataResponse)
                callSaveHandoverAPI()
            }
            Log.i("mahesh", "maheshchandraprasad "+lblResponse.text);
        }else{
            iv_error.visibility = View.VISIBLE
            lblResponse.visibility = View.VISIBLE
            lblResponse.text = "Failed to open the e-KYC"
            lblTryAgian.visibility = View.VISIBLE
        }

        Log.i("mahesh", "maheshchandraprasadt "+pidDataResponse);
//        lblResponse.text = print_data

    }


    fun callAPI(pidDataResponse: String){
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)
        val aadharNumber = Utilities.encodeToBase64(regData.aadhar)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_aadhar))
        val aadharEKYCWithFacialPIDrequest = AadharEKYCWithFacialPIDRequest(aadharNumber, pidDataResponse)


        // Make the AadharEKYCWithFacialPID call
        apiService.aadharEKYCWithFacialPID(aadharEKYCWithFacialPIDrequest).enqueue(object : Callback<AadharEKYCWithFacialPIDResponse> {
            override fun onResponse(
                call: Call<AadharEKYCWithFacialPIDResponse>,
                response: Response<AadharEKYCWithFacialPIDResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("aadharEKYCWithFacialPIDHandOver Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("aadharEKYCWithFacialPIDHandOver Response${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful AadharEKYCWithFacialPID
                    val aadharEKYCWithFacialPIDResponse = response.body()

                    var status = aadharEKYCWithFacialPIDResponse?.status

                    if (status != null) {
                        if(status.lowercase().contains("success")) {

                            val token = aadharEKYCWithFacialPIDResponse?.reference
                            val tokenId =
                                aadharEKYCWithFacialPIDResponse?.userInfo?.name + "  " + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf
                            Utilities.logI("AadharEKYCWithFacialPID successful, tokenId: $tokenId, token: $token")


                            var display = aadharEKYCWithFacialPIDResponse?.message + "\n\n" +
                                    "Transaction Number :" + aadharEKYCWithFacialPIDResponse?.transactionNumber + "\n\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.name + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.landmark + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.location + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.district + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.state + "\n" +
                                    "" + aadharEKYCWithFacialPIDResponse?.userInfo?.country

                            lblErrorResponse.text = display

                            /*callSaveHandoverAPI(aadharEKYCWithFacialPIDResponse)*/
                            callSaveHandoverAPI()

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = aadharEKYCWithFacialPIDResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "AadharEKYCWithFacialPID "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {
                    lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text = getString(R.string.failed_try_again)
                    lblErrorResponse.visibility = View.VISIBLE

                }
            }

            override fun onFailure(call: Call<AadharEKYCWithFacialPIDResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("AadharEKYCWithFacialPID failed: ${t.message}")

                if(aadharEKYCWithFacialPIDRetry == 0){
                    aadharEKYCWithFacialPIDRetry = 1
                    callAPI(pidDataResponse)
                }else {
                    aadharEKYCWithFacialPIDRetry = 0;
                    // Handle failure
                    lblErrorResponse.text = "AadharEKYCWithFacialPID failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                }
            }
        })

    }

    data class PidResponseError(val errCode: String, val errInfo: String)

    fun parsePidDataError(xml: String): PidResponseError? {
        try {
            val factory = XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true
            val parser = factory.newPullParser()
            parser.setInput(xml.reader())

            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "Resp") {
                    val errCode = parser.getAttributeValue(null, "errCode") ?: ""
                    val errInfo = parser.getAttributeValue(null, "errInfo") ?: ""
                    return PidResponseError(errCode, errInfo)
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }


    //fun callSaveHandoverAPI(aadharEKYCWithFacialPIDResponse: AadharEKYCWithFacialPIDResponse?) {
    fun callSaveHandoverAPI() {
        val rootLayout = findViewById<ViewGroup>(android.R.id.content)

        val overlayLayout = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#80000000")) // Semi-transparent background
        }

        val progressBar = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER  // Centers it in the overlay
            )
        }

        // 🔥 Add the ProgressBar to the overlay layout
        overlayLayout.addView(progressBar)

        // 🔥 Add the overlay layout to the root layout
        rootLayout.addView(overlayLayout)

        val apiService = RetrofitClient.createApiService(applicationContext, getString(R.string.base_url_sro))

        /*val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanEKycData::class.java)

        val AADHAR = regData.aadhar
        val SR_CODE = regData.srCode
        val BOOK_NO = regData.bookNo
        val DOCT_NO = regData.doctNo
        val REG_YEAR = regData.regYear
        val CODE = regData.code
        val EC_NUMBER = regData.ecNumber
        val ENTRY_BY = regData.entryBy

        val age_calculate = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth?.let {
            Utilities.calculateAge(
                it
            )
        }

        val A_NAME = aadharEKYCWithFacialPIDResponse?.userInfo?.name
        val CARE_OF = aadharEKYCWithFacialPIDResponse?.userInfo?.careOf
        val GENDER = aadharEKYCWithFacialPIDResponse?.userInfo?.gender
        val DOB = aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth
        val PIN_CODE = aadharEKYCWithFacialPIDResponse?.userInfo?.pinCode
        val AGE = age_calculate
        val ADDRESS = aadharEKYCWithFacialPIDResponse?.userInfo?.landmark
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.location
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.district
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.state
                ", " + aadharEKYCWithFacialPIDResponse?.userInfo?.country
        val PH_NO = "null"//null
        val PHOTO = aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto
        val DN_QUALIFIER = aadharEKYCWithFacialPIDResponse?.userInfo?.dnQualifier

        val UDC_SERIAL_NO = 23456720000000
        val CONSENT = "Y"
        val ACCESSED_BY = "P"
        val ESIGN = "N"
        val ADDRESS2 = ""

        val savePartiesRequest = SavePartiesRequest(AADHAR, SR_CODE, BOOK_NO, DOCT_NO, REG_YEAR, CODE, EC_NUMBER, ENTRY_BY,
            A_NAME, CARE_OF, GENDER, DOB, PIN_CODE, AGE, ADDRESS, PH_NO, PHOTO, DN_QUALIFIER,
            UDC_SERIAL_NO, CONSENT, ACCESSED_BY, ESIGN, ADDRESS2)

        val requestList = listOf(savePartiesRequest)*/


        val regData = Gson().fromJson(applicationPreferences.getAadharNumber(thisActivity).toString(), QRScanDocumentHandoverData::class.java)

        // Make the saveParties call
        apiService.saveHandOver(regData.srCode, regData.bookNo, regData.doctNo, regData.regYear).enqueue(object : Callback<ESignSaveTxnResponse> {
            override fun onResponse(
                call: Call<ESignSaveTxnResponse>,
                response: Response<ESignSaveTxnResponse>
            ) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                try{ val request = call.request()
                    Utilities.logI("saveHandOver Request ${request.method} ${request.url.encodedPath} : ${request.headers}  :  ${request.body}")}catch (e:Exception){}
                try{Utilities.logI("saveHandOver Response ${response.isSuccessful} : response code ${response.isSuccessful} : ${response.body()}")}catch (e:Exception){}

                if (response.isSuccessful) {
                    // Successful saveParties
                    val savePartiesResponse = response.body()

                    var status = savePartiesResponse?.status

                    lblErrorResponse.text = "AadharEKYCWithFacialPID callSaveHandoverAPI, tokenId: $status"

                    if (status != null) {
                        if(status == true) {

                            val message = savePartiesResponse?.message

                            if(savePartiesResponse?.status == true) {
                                lblErrorResponse.text =
                                    "callSaveHandoverAPI, status: $status\nmessage: $message}"


                                ll_mainScreen.visibility = View.GONE
                                ll_success.visibility = View.VISIBLE


                                /*val ADDRESS = "" + aadharEKYCWithFacialPIDResponse?.userInfo?.landmark + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.location + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.villageTownCity + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.postOffice + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.district + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.state + "\n" +
                                        "" + aadharEKYCWithFacialPIDResponse?.userInfo?.country

                                var display =
                                        "Name: " + aadharEKYCWithFacialPIDResponse?.userInfo?.name + "\n" +
                                        "Date of Birth: " + aadharEKYCWithFacialPIDResponse?.userInfo?.dateOfBirth + "\n" +
                                        "Gender: " + aadharEKYCWithFacialPIDResponse?.userInfo?.gender + "\n" +
                                        "C/O: " + aadharEKYCWithFacialPIDResponse?.userInfo?.careOf + "\n"


                                lblDetails.text = display +"Address: "+ADDRESS*/

                                lblDetails.text = "Face scan completed succesfully.\nHandover the document"
                                lblDetails.gravity = Gravity.CENTER_HORIZONTAL
                                lblDetails.textSize = 20f

                                /*aadharEKYCWithFacialPIDResponse?.userInfo?.encodedPhoto?.let {
                                    Utilities.displayBase64Image(
                                        it, myImageView)
                                }*/
                            }else{
                                lblErrorResponse.text =
                                    "callSaveHandoverAPI, status: $status, message: $message \n" +
                                            "code: ${savePartiesResponse?.code}"
                            }

                        }else{
                            lblTryAgian.visibility = View.VISIBLE
                            lblErrorResponse.visibility = View.VISIBLE
                            lblErrorResponse.text = "Save Handover Error:\n"+savePartiesResponse?.message
                        }
                    }else{
                        lblTryAgian.visibility = View.VISIBLE
                        lblErrorResponse.text = "Save Handover failed "+getString(R.string.failed_try_again)
                        lblErrorResponse.visibility = View.VISIBLE
                    }


                } else {
                    lblTryAgian.visibility = View.VISIBLE
                    lblErrorResponse.text =  getString(R.string.failed_try_again)+"."
                    lblErrorResponse.visibility = View.VISIBLE

                }
            }

            override fun onFailure(call: Call<ESignSaveTxnResponse>, t: Throwable) {

                // Hide ProgressBar
                progressBar.visibility = View.GONE
                rootLayout.removeView(overlayLayout)

                Utilities.logI("Save Parties failed : ${t.message}")

                if(callSaveHandoverAPI == 0){
                    callSaveHandoverAPI = 1
                    //callSaveHandoverAPI(aadharEKYCWithFacialPIDResponse)
                    callSaveHandoverAPI()
                }else {
                    // Handle failure
                    lblErrorResponse.text = "Save Handover failed: ${t.message}"
                    lblErrorResponse.visibility = View.VISIBLE
                    lblTryAgian.visibility = View.VISIBLE
                    callSaveHandoverAPI = 0
                }
            }
        })

    }

}
