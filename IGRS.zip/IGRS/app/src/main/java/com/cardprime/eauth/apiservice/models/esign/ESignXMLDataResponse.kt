package com.cardprime.eauth.apiservice.models.esign

import com.google.gson.annotations.SerializedName

data class ESignXMLDataResponse(
    @SerializedName("status") val status: String,
    @SerializedName("eSignRequest") val eSignRequest: String? = null,
    @SerializedName("message") val message: String? = null
)

