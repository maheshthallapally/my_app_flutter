package com.pos.foodservicespos.apiservice.models.subregistrarlist

import com.google.gson.annotations.SerializedName

data class SubRegistrarEmployeeListResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    @SerializedName("data") val data: String
    //@SerializedName("data") val data: List<EmployeeData>
)

/*data class EmployeeData(
    @SerializedName("SR_CODE") val srCode: Int,
    @SerializedName("EMPL_ID") val emplId: Long,
    @SerializedName("CFMS_ID") val cfmsId: Long,
    @SerializedName("AADHAR") val aadhar: String,
    @SerializedName("MOBILE_NO") val mobileNo: Long?, // Nullable
    @SerializedName("EMPL_NAME") val emplName: String,
    @SerializedName("DESIGNATION") val designation: String,
    @SerializedName("PROCEEDING_NO") val proceedingNo: String?, // Nullable
    @SerializedName("PROCEEDING_DATE") val proceedingDate: String?, // Nullable
    @SerializedName("FROM_DATE") val fromDate: String?, // Nullable
    @SerializedName("TO_DATE") val toDate: String?, // Nullable
    @SerializedName("EMP_STATUS") val empStatus: String?, // Nullable
    @SerializedName("LAST_LOGIN") val lastLogin: String,
    @SerializedName("PASSWRD") val password: String,
    @SerializedName("VILL_CODE") val villCode: String?, // Nullable
    @SerializedName("VERIFY_STATUS") val verifyStatus: String,
    @SerializedName("PAST_DESIGNATION") val pastDesignation: String? // Nullable
)*/

