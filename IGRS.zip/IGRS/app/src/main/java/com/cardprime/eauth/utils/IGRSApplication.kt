package com.cardprime.eauth.utils

import android.content.Context
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication

class IGRSApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        mContext = applicationContext // Initialize `mContext` properly
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    companion object {
        val TAG: String = IGRSApplication::class.java.simpleName

        // Ensure `mContext` is initialized properly
        @JvmStatic
        private var mContext: Context? = null

        @JvmStatic
        fun getContext(): Context {
            return mContext ?: throw IllegalStateException("Application context is not initialized yet.")
        }

        @JvmStatic
        lateinit var instance: IGRSApplication
            private set
    }
}
