package com.cardprime.eauth.apiservice.models.esign

import com.google.gson.annotations.SerializedName

data class ESignSaveTxnResponse(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    //@SerializedName("data") val data: Boolean
)

