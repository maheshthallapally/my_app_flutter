package com.cardprime.eauth.apiservice

object PidOptionsBuilder {
    fun build(txnId: String, auaCode: String, callbackUrl: String, jwtToken: String): String {
        return """<?xml version='1.0' encoding='UTF-8'?>
            <PidOptions ver='1.0' env='PP'>
                <Opts format='0' pidVer='2.0' wadh='sgydIC09zzy6f8Lb3xaAqzKquKe9lFcNR9uTvYxFp+A='/>
                <CustOpts>
                    <Param name='txnId' value='$txnId'/>
                    <Param name='language' value='en'/>
                </CustOpts>
                <BioData/>
                <Signature/>
            </PidOptions>
        """.trimIndent()
    }

//    <Param name='cameraUsage' value='F'/>
//    <Param name='auaCode' value='$auaCode'/>
//    <Param name='callBackUrl' value='$callbackUrl'/>
//    <Param name='auaAuthToken' value='$jwtToken'/>
}