package com.cardprime.eauth.utils

import com.google.gson.annotations.SerializedName

data class QRScanESignData(
    @SerializedName("SR_CODE")  val srCode: Int,
    @SerializedName("BOOK_NO")  val bookNo: Int,
    @SerializedName("DOCT_NO")  val doctNo: Int,
    @SerializedName("REG_YEAR") val regYear: Int,
    @SerializedName("authmode") val authmode: Int,
    @SerializedName("name")     val name: String,
    @SerializedName("location") val location: String,
    @SerializedName("igrsEsign") val igrsEsign: Boolean,
    @SerializedName("applicationId")val applicationId: String,
    @SerializedName("ec_number")   val ec_number: Int,
    @SerializedName("txnid")   val txnid: Long,
    @SerializedName("code")   val code: String,
)
