package com.cardprime.eauth.apiservice.models.esign

import com.google.gson.annotations.SerializedName

data class ESignXMLvalidateRequest(
    @SerializedName("responseXml") val responseXml: String,
)
