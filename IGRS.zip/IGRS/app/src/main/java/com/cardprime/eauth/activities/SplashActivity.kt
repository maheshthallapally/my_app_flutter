package com.cardprime.eauth.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.cardprime.eauth.R
import com.pos.foodservicespos.utils.ApplicationPreferences
import com.pos.foodservicespos.utils.Utilities

class SplashActivity : ParentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)


        Utilities.logI("getToken: ${ApplicationPreferences.getToken(thisActivity)?.length} getLoginTime: "+ApplicationPreferences.getLoginTime(thisActivity))

        if(ApplicationPreferences.getToken(thisActivity) == ""){
            openLogin()
        }else {
            var timeDiffInMinutes = ApplicationPreferences.getLoginTime(thisActivity)
            Utilities.logI("getToken timeDiffInMinutes: ${timeDiffInMinutes}")
            if (timeDiffInMinutes != null) {
                if (timeDiffInMinutes < 15) { // Auto logout after 12 hours
                    // QR is still valid
                    openMashboard()
                } else {
                    // QR expired
                    openLogin()
                }
            } else {
                openLogin()
            }
        }

    }

    fun openLogin(){
        // Delay for 3 seconds before navigating to MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }, 3000)
    }

    fun openMashboard(){
        // Delay for 3 seconds before navigating to MainActivity
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, SelectServiceActivity::class.java))
            finish()
        }, 3000)
    }

}
