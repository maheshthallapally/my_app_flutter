package com.pos.foodservicespos.utils

import android.app.Activity
import android.app.Dialog
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import com.cardprime.eauth.R

object MessageProgress {
    var lblTitle: TextView? = null
    var title = "Loading ..."
    var dialog: Dialog? = null

    fun startLoading(thisActivity: Activity, loadinText: String): Dialog? {
        thisActivity.runOnUiThread {
            if (dialog != null && dialog!!.isShowing) {
                // Fix: Use a local variable to prevent smart cast issue
                val titleView = lblTitle
                if (titleView != null) {
                    titleView.text = if (loadinText.isEmpty()) title else loadinText
                }
            } else {
                dialog = Dialog(thisActivity, R.style.NoPaddingDialogue)
                dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog!!.setCancelable(false)
                dialog!!.window?.apply {
                    addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                    setBackgroundDrawable(
                        ColorDrawable(Utilities.getColor(thisActivity, R.color.black_trans1))
                    )
                    attributes = attributes.apply {
                        width = WindowManager.LayoutParams.MATCH_PARENT
                        height = WindowManager.LayoutParams.MATCH_PARENT
                        gravity = Gravity.CENTER
                    }
                }

                val view: View = LayoutInflater.from(thisActivity)
                    .inflate(R.layout.dialogue_message_progress_loading, null)

                lblTitle = view.findViewById(R.id.lblTitle)

                // Fix: Use a local variable to prevent smart cast issue
                val titleView = lblTitle
                if (titleView != null) {
                    titleView.text = if (loadinText.isEmpty()) title else loadinText
                }

                dialog!!.setContentView(view)
                dialog!!.setOnKeyListener { _, keyCode, _ ->
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        // Prevent dialog from closing on back press
                    }
                    true
                }

                if (!thisActivity.isDestroyed) {
                    try {
                        dialog!!.show()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
        return dialog
    }

    fun endLoading(thisActivity: Activity) {
        thisActivity.runOnUiThread {
            try {
                if (dialog?.isShowing == true) {
                    dialog?.dismiss()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
