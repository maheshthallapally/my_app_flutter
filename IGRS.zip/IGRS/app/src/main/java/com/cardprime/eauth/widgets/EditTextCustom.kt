package com.pos.foodservicespos.widgets


import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.inputmethod.InputMethodManager
import com.cardprime.eauth.R
import com.pos.foodservicespos.utils.Utilities

class EditTextCustom @JvmOverloads constructor(
    private val mContext: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : androidx.appcompat.widget.AppCompatEditText(mContext, attrs, defStyle) {

    init {
        applyAttributes(context, attrs)
    }

    private fun applyAttributes(context: Context, attrs: AttributeSet?) {
        attrs?.let {
            val typedArray = context.obtainStyledAttributes(it, R.styleable.CustomTextView)
            for (i in 0 until typedArray.indexCount) {
                when (val attr = typedArray.getIndex(i)) {
                    R.styleable.CustomTextView_typeface -> {
                        try {
                            setTypeface(getTypeFace(context, "fonts/" + typedArray.getString(attr)))
                        } catch (e: RuntimeException) {
                            e.printStackTrace()
                        }
                    }
                }
            }
            typedArray.recycle()
        }
    }

    private fun getTypeFace(context: Context, fileName: String): Typeface {
        return Utilities.sTypeFaces[fileName] ?: run {
            /*Utilities.logEwithoutLogStore("Font path: $fileName")*/
            val typeface = Typeface.createFromAsset(resources.assets, fileName)
            Utilities.sTypeFaces[fileName] = typeface
            typeface
        }
    }

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // Hide keyboard
            val inputMethodManager =
                mContext.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(this.windowToken, 0)

            // Broadcast event
            try {
                val intent = Intent("DeviceDetails.KeyboardCloseEvent").apply {
                    setPackage("com.motosyncplus.mobile")
                }
                mContext.sendBroadcast(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Lose focus
            this.clearFocus()
            return true
        }
        return super.onKeyPreIme(keyCode, event)
    }
}
