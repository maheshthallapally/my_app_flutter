package com.cardprime.eauth.apiservice.apis

import com.cardprime.eauth.apiservice.models.esign.ESignXMLDataResponse
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDRequest
import com.cardprime.eauth.apiservice.models.aadharekycwithfacialpid.AadharEKYCWithFacialPIDResponse
import com.cardprime.eauth.apiservice.models.esign.ESignSaveTxnRequest
import com.cardprime.eauth.apiservice.models.esign.ESignSaveTxnResponse
import com.cardprime.eauth.apiservice.models.esign.ESignXMLvalidateRequest
import com.cardprime.eauth.apiservice.models.esign.ESignXMLvalidateResponse
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesRequest
import com.cardprime.eauth.apiservice.models.saveparties.SavePartiesResponse
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeDocumentHandoverRequest
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeESignRequest
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeRequest
import com.cardprime.eauth.apiservice.models.validateQRCode.ValidateQrCodeResponse
import com.pos.foodservicespos.apiservice.models.login.EncryptedPasswordResponse
import com.pos.foodservicespos.apiservice.models.login.LoginRequest
import com.pos.foodservicespos.apiservice.models.login.LoginResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarEmployeeListResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarEmployeeListResponseDecrypt
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarListResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @POST("emp/loginPwd")
    fun login(
        @Body loginRequest: LoginRequest
    ): Call<LoginResponse>

    @POST("aadharEKYCWithFacialPID")
    fun aadharEKYCWithFacialPID(
        @Body aadharEKYCWithFacialPIDrequest: AadharEKYCWithFacialPIDRequest
    ): Call<AadharEKYCWithFacialPIDResponse>

    @GET("srolist/getSroList")
    fun getSROOfficesList(): Call<SubRegistrarListResponse>

    @GET("emp/getEmployees")
    fun getSROEmployeesList(@Query("srCode") srCode: String): Call<SubRegistrarEmployeeListResponse>

    @GET("encryption/encryptPassword/{input}")
    fun getEncryptedPassword(@Path("input") input: String): Call<EncryptedPasswordResponse>

    @GET("encryption/encryptValue/{input}")
    fun getEncryptedValue(@Path("input") input: String): Call<EncryptedPasswordResponse>

    /*@GET("encryption/decryptValue/{input}")
    fun getSROListDecrypt(@Path("input") input: String): Call<SubRegistrarListResponseDecrypt>*/

    @GET("encryption/decryptValue/{input}")
    fun getEmployeeListDecrypt(@Path("input") input: String): Call<SubRegistrarEmployeeListResponseDecrypt>

    @GET("encryption/decryptValue/{input}")
    fun getDecryptedAadharNo(@Path("input") input: String): Call<EncryptedPasswordResponse>

    @POST("ekyc/GetValidateQrData")
    fun validateEKycQRCode(
        @Body validateQRCodeRequest: ValidateQrCodeRequest
    ): Call<ValidateQrCodeResponse>

    @POST("ekyc/saveParties")
    //@POST("ekyc/savePartiess")
    fun saveParties(
        @Body aadharEKYCWithFacialPIDrequest: List<SavePartiesRequest>
    ): Call<SavePartiesResponse>

    @POST("ekyc/savePartiesrefusal")
    fun savePartiesForRefusal(
        @Body aadharEKYCWithFacialPIDrequest: List<SavePartiesRequest>
    ): Call<SavePartiesResponse>


    @POST("esign/GetValidateQrData")
    fun validateESignQRCode(
        @Body validateQRCodeRequest: ValidateQrCodeESignRequest
    ): Call<ValidateQrCodeResponse>

    @POST("esign/GetValidateQrDataRefusal")
    fun validateESignQRCodeForRefusal(
        @Body validateQRCodeRequest: ValidateQrCodeESignRequest
    ): Call<ValidateQrCodeResponse>

    @POST("igrs-esign-service/generateEsignXmlByTransID")
    fun getXMLFileforESign(@Query("transactionId") transactionId: String): Call<ESignXMLDataResponse>

    @POST("igrs-esign-service/processESignResponse")
    fun validateESignResponseXML(
        @Body eSignXMLvalidateRequest: ESignXMLvalidateRequest
    ): Call<ESignXMLvalidateResponse>

    @POST("esign/endorsement/status")
    fun saveESignTxn(
        @Body eSignSaveTxnRequest: ESignSaveTxnRequest
    ): Call<ESignSaveTxnResponse>

    @POST("esign/refusalCor/status")
    fun saveESignTxnForRefusal(
        @Body eSignSaveTxnRequest: ESignSaveTxnRequest
    ): Call<ESignSaveTxnResponse>




    @GET("docHandover/getValidateNomineeQr")
    fun getValidateDocumentHandoverQr(
        @Query("SR_CODE") srCode: Int,
        @Query("BOOK_NO") bookNo: Int,
        @Query("REG_YEAR") regYear: Int,
        @Query("DOCT_NO") doctNo: Int,
        @Query("AADHAR") aadhar: String,
        @Query("EMPL_NAME") emplName: String
    ): Call<ValidateQrCodeResponse>

    @PUT("docHandover/saveHandover")
    fun saveHandOver(
        @Query("sr_code") srCode: Int,
        @Query("book_no") bookNo: Int,
        @Query("doct_no") regYear: Int,
        @Query("reg_year") doctNo: Int,
    ): Call<ESignSaveTxnResponse>


    @GET("emp/logout")
    fun logoutAccount(): Call<EncryptedPasswordResponse>

}
