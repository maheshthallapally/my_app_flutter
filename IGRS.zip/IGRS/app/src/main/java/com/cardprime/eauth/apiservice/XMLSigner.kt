package com.cardprime.eauth.apiservice

import org.apache.xml.security.Init
import org.apache.xml.security.signature.XMLSignature
import org.apache.xml.security.transforms.Transforms
import org.w3c.dom.Document
import java.io.ByteArrayInputStream
import java.io.StringWriter
import java.nio.charset.StandardCharsets
import java.security.PrivateKey
import java.security.cert.X509Certificate
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

object XMLSigner {
    fun signXml(xml: String, privateKey: PrivateKey, cert: X509Certificate): String {
        Init.init()
        val dbf = DocumentBuilderFactory.newInstance()
        dbf.isNamespaceAware = true
        val doc: Document = dbf.newDocumentBuilder()
            .parse(ByteArrayInputStream(xml.toByteArray(StandardCharsets.UTF_8)))

        val signature = XMLSignature(doc, "", XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1)
        val root = doc.documentElement
        root.appendChild(signature.element)

        val transforms = Transforms(doc)
        transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE)
        signature.addDocument("", transforms, "http://www.w3.org/2000/09/xmldsig#sha1")

        signature.addKeyInfo(cert)
        signature.addKeyInfo(cert.publicKey)
        signature.sign(privateKey)

        val trans = TransformerFactory.newInstance().newTransformer()
        val writer = StringWriter()
        trans.transform(DOMSource(doc), StreamResult(writer))
        return writer.toString()
    }
}