package com.pos.foodservicespos.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.pos.foodservicespos.apiservice.models.login.LoginResponse
import com.pos.foodservicespos.apiservice.models.subregistrarlist.SubRegistrarData


object ApplicationPreferences {

    private const val SHAREDPREFERENCE_KEY = "sharedpreference_key" // Persistent across logout
    private const val PREFERENCE_KEY = "preference_key" // Cleared on logout

    private const val SET_THEME_MODE = "set_theme_mode"
    private const val BEARER_TOKEN = "bearer_token"
    private const val LOGIN_TIMESTAMP = "login_timestamp"
    private const val AADHAR_NUMBER = "AADHAR_NUMBER"
    private const val SRO_CODE = "SRO_CODE"
    private const val EMPL_NAME = "EMPL_NAME"
    private const val QR_DATA = "QR_DATA"
    private const val LOG = "logger "
    private const val LONGITUDE = "longitude"
    private const val LATITUDE = "latitude"

    const val PREFS_FILE: String = "secure_prefs"
    const val TOKEN_KEY: String = "auth_token"
    private var sharedPreferences: SharedPreferences? = null

    /*fun setThemeMode(mActivity: Context, mode: String?): Boolean {
        val editor = mActivity.getSharedPreferences(SHAREDPREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(SET_THEME_MODE, mode)
        return editor.commit()
    }*/

    fun getThemeMode(mActivity: Context): String? {
        val userPref = mActivity.getSharedPreferences(SHAREDPREFERENCE_KEY, Context.MODE_PRIVATE)
        return userPref.getString(SET_THEME_MODE, "cool")
    }

    fun setToken(mActivity: Context, token: String?): Boolean {

        getSharedPreference(mActivity)!!.edit().putString(TOKEN_KEY, token).apply();
        return true

        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(BEARER_TOKEN, token)
        return editor.commit()*/
    }

    fun getToken(mActivity: Context): String? {

        return getSharedPreference(mActivity)!!.getString(TOKEN_KEY, "");

//        val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
//        return userPref.getString(BEARER_TOKEN, "")

//        return userPref.getString(BEARER_TOKEN, "Bearer 9083|xJnAypDXU0Qb2KvNXVpsDMkOXrCn7DF1Jzq4bJLV64f4382d")
    }

    fun setLoginTime(mActivity: Context, time: Long): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putLong(LOGIN_TIMESTAMP, time) // ⏱ store current time
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putLong(LOGIN_TIMESTAMP, time).apply()
        return true
    }

    fun getLoginTime(mActivity: Context): Long? {
        /*val prefs = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        val savedTime = prefs.getLong(LOGIN_TIMESTAMP, 0)*/

        val savedTime = getSharedPreference(mActivity)!!.getLong(LOGIN_TIMESTAMP, 0)

        val currentTime = System.currentTimeMillis()
        Utilities.logI("getToken currentTime: $currentTime")
        val timeDiffInMinutes = (currentTime - savedTime) / (60 * 1000) // ⏱ time diff in minutes
        Utilities.logI("getToken timeDiffInMinutes: $timeDiffInMinutes")
        return timeDiffInMinutes
    }

    fun setAadharNumber(mActivity: Context, token: String?): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(AADHAR_NUMBER, token)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(AADHAR_NUMBER, token).apply()
        return true;

    }

    fun getAadharNumber(mActivity: Context): String? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return userPref.getString(AADHAR_NUMBER, "858633410612")*/
        return getSharedPreference(mActivity)!!.getString(AADHAR_NUMBER, "")
    }

    fun saveLoginResponse(mActivity: Context, loginResponse: LoginResponse) {
        val gson = Gson()
        val json = gson.toJson(loginResponse)

        getSharedPreference(mActivity)!!.edit().putString("login_response", json).apply();
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString("login_response", json)
        editor.apply()*/
    }

    fun getLoginResponse(mActivity: Context): LoginResponse? {
//        val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
//        val json = userPref.getString("login_response", null)

        val gson = Gson()
        val json = getSharedPreference(mActivity)!!.getString("login_response", "");

        return if (json != null) gson.fromJson(json, LoginResponse::class.java) else null
    }



    /*fun setLog(mContext: Context, log: Boolean): Boolean {
        val editor =
            mContext.getSharedPreferences(SHAREDPREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putBoolean(ApplicationPreferences.LOG, log)
        return editor.commit()
    }


    fun getLog(mContext: Context): Boolean {
        return try {
            val user_pref =
                mContext.getSharedPreferences(SHAREDPREFERENCE_KEY, Context.MODE_PRIVATE)
            user_pref.getBoolean(ApplicationPreferences.LOG, false)
        } catch (e: Exception) {
            true
        }
    }*/


    fun saveSubRegistrarList(mActivity: Context, list: List<SubRegistrarData>) {
        try {

            val gson = Gson()
            val json = gson.toJson(list)

            /*val editor = context.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
            editor.putString("sub_registrar_list", json)
            editor.apply()*/

            getSharedPreference(mActivity)!!.edit().putString("sub_registrar_list", json).apply();

        }catch (e:Exception){
            e.printStackTrace()
        }
    }


    fun getSubRegistrarList(mActivity: Context): List<SubRegistrarData> {
        try {
            /*val prefs = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
            val json = prefs.getString("sub_registrar_list", null)*/
            val json = getSharedPreference(mActivity)!!.getString("sub_registrar_list", "");
            return if (json != null) {
                val type = object : TypeToken<List<SubRegistrarData>>() {}.type
                Gson().fromJson(json, type)
            } else {
                emptyList()
            }
        }catch (e:Exception){
            e.printStackTrace()
            return emptyList()
        }
    }

    fun setSROCode(mActivity: Context, token: String?): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(SRO_CODE, token)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(SRO_CODE, token).apply();
        return true
    }

    fun getSROCode(mActivity: Context): String? {
//        val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
//        return userPref.getString(SRO_CODE, "0")
        return getSharedPreference(mActivity)!!.getString(SRO_CODE, "");
    }


    fun setEmployeeName(mActivity: Context, token: String?): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(EMPL_NAME, token)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(EMPL_NAME, token).apply()
        return true
    }

    fun getEmployeeName(mActivity: Context): String? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return userPref.getString(EMPL_NAME, "")*/

        return getSharedPreference(mActivity)!!.getString(EMPL_NAME, "")
    }


    fun setQRData(mActivity: Context, token: String?): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(QR_DATA, token)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(QR_DATA, token).apply()
        return true
    }

    fun getQRData(mActivity: Context): String? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return userPref.getString(QR_DATA, "")*/

        return getSharedPreference(mActivity)!!.getString(QR_DATA, "")
    }

    fun setLongitude(mActivity: Context, longitude: String): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(LONGITUDE, longitude)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(LONGITUDE, longitude).apply()
        return true
    }

    fun getLongitude(mActivity: Context): Double? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return ((userPref.getString(LONGITUDE, "0.00"))?.replace(",",""))?.toDouble()*/
        return ((getSharedPreference(mActivity)!!.getString(LONGITUDE, "0.00")?.replace(",",""))?.toDouble())
    }

    fun setLatitude(mActivity: Context, latitude: String): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString(LATITUDE, latitude)
        return editor.commit()*/

        getSharedPreference(mActivity)!!.edit().putString(LATITUDE, latitude).apply()
        return true
    }

    fun getLatitude(mActivity: Context): Double? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return ((userPref.getString(LATITUDE, "0.00"))?.replace(",",""))?.toDouble()*/
        return ((getSharedPreference(mActivity)!!.getString(LATITUDE, "0.00")?.replace(",",""))?.toDouble())
    }


    fun setLogsData(mActivity: Context, logs: String): Boolean {
        /*val editor = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE).edit()
        editor.putString("logs", logs)
        return editor.commit()*/
        getSharedPreference(mActivity)!!.edit().putString("logs", logs).apply()
        return true
    }

    fun getLogsData(mActivity: Context): String? {
        /*val userPref = mActivity.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)
        return userPref.getString("logs", "")*/
        return (getSharedPreference(mActivity)!!.getString("logs", ""))
    }

    fun getSharedPreference(mActivity: Context): SharedPreferences? {
        val masterKey = MasterKey.Builder(mActivity)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        sharedPreferences = EncryptedSharedPreferences.create(
            mActivity,
            PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        return sharedPreferences
    }


}
