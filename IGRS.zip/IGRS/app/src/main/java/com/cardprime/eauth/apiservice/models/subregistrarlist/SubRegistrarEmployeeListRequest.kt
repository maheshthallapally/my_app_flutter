package com.pos.foodservicespos.apiservice.models.subregistrarlist

import com.google.gson.annotations.SerializedName

data class SubRegistrarEmployeeListRequest(
    @SerializedName("status") val status: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("code") val code: String,
    @SerializedName("data") val data: List<EmployeeData>
)
